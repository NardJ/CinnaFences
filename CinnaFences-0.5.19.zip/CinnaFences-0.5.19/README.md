# CinnaFences v0.5.19 — Performance & About

Gerichte onderhoudsversie op basis van de werkende v0.5.18. Bestaande
Fence-bestanden, configuraties, Nemo-acties en bestandslogica zijn ongemoeid gelaten.

## Nieuwe About-tab

In **CinnaFences Settings → About** staan live waarden voor:

| Cinna­mon-proces | Hele computer |
|---|---|
| CPU (%) — 100% is één core | Totale CPU-belasting (%) |
| Geheugen, RSS (MiB) | RAM gebruikt / totaal (GiB) |
| Disk reads en writes (B/s, KiB/s, MiB/s) | Gebruikte en vrije schijfruimte (GiB) |
| Proces-ID | |

**Deze waarden zijn nadrukkelijk NIET exclusief aan CinnaFences toe te
schrijven.** Het Cinnamon-proces omvat ook compositor en andere extensies.
Disk I/O van het proces is de werkelijke OS-read/write-meter; gegevens uit caches
kunnen 0 B/s opleveren. Diskruimte is capaciteit, niet de bezettingsgraad
van de opslagcontroller.

De About-tab leest Linux `/proc`, heeft geen extra Python-pakket nodig en
ververst slechts iedere twee seconden **wanneer die tab actief is**. Bij het
verlaten of sluiten van het venster stopt de meting; er is geen daemon.

## Gerichte optimalisaties

1. Extra X11-inputregiocontrole door muisbewegingen gebeurt uitsluitend wanneer
   de pointer boven een zichtbare Fence staat. Venstercreatie, focuswissels,
   geometriewijzigingen en werkruimtewissels blijven altijd de inputregio's
   actualiseren. Zo blijft de belangrijke Nemo-overlapcorrectie aanwezig.
2. Het icoonlettertype wordt per Fence-verversing eenmaal via Pango verwerkt,
   in plaats van per afzonderlijk icoon.
3. Buiten Fences wordt een reeds inactieve hoverstatus niet steeds opnieuw
   bijgewerkt; het verlaten van een actieve Fence maakt de hoverstatus wel vrij.

Deze optimalisaties reduceren overbodig werk, maar de daadwerkelijke CPU-winst
moet nog op de Mint-desktop gemeten worden.

## Installatie / upgrade

Schakel CinnaFences eerst uit onder **System Settings → Extensions** en sluit
het instellingenvenster. Pak de ZIP uit onder `~/Downloads`:

```bash
cd ~/Downloads
unzip CinnaFences-0.5.19.zip
cd CinnaFences-0.5.19
bash upgrade.sh
```

Schakel CinnaFences weer in. De upgrade maakt een back-up van de vorige extensie
en past bestaande Desktop-bestanden of `.cinnafence.json`-bestanden niet aan.

## Testen

1. Open Settings → **About** en wacht twee seconden op de CPU- en I/O-waarden.
2. Wissel van About naar een andere tab en terug; de meting hoort dan opnieuw
   te beginnen zonder doorlopend te blijven meten.
3. Leg Nemo gedeeltelijk over een Fence en controleer dat alle Nemo-onderdelen
   direct klikbaar blijven.
4. Controleer drag-and-drop, Rolodex en tonen/verbergen met de sneltoets.
5. Meet de idle CPU-tijd nogmaals met dezelfde 45-secondenprocedure als bij
   v0.5.18, zowel ingeschakeld als uitgeschakeld.

De automatische tests controleren de `/proc`-berekening, de timerlevensduur,
het overslaan van off-Fence muiswerk en de bestaande functionaliteit.
De nieuwe GTK-tab en de werkelijk gemeten besparing vereisen nog validatie
op Linux Mint Cinnamon 6.6.9.
