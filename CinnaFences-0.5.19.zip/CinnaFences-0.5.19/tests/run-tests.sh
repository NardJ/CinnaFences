#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if command -v node >/dev/null 2>&1; then
    node --check cinnafences@local/extension.js
    node tests/test-core.js
    node tests/test-performance.js
    node tests/test-sections.js
    node tests/test-section-grid.js
    node tests/test-refresh-trash.js
    node tests/test-unassigned.js
else
    echo 'Node.js ontbreekt: optionele JS-ontwikkelaarstests overgeslagen (niet vereist voor CinnaFences).'
fi
python3 tests/test-performance.py
python3 tests/test-config.py
python3 tests/test-unassigned.py
bash -n install.sh uninstall.sh upgrade.sh install-nemo-actions.sh uninstall-nemo-actions.sh install-settings-launcher.sh uninstall-settings-launcher.sh
python3 -m py_compile tools/cinnafences-config.py nemo-actions/dispatch.py nemo-actions/create-shortcut.py nemo-actions/create-launcher.py
python3 tests/test-nemo.py
python3 tests/test-transfer.py
python3 tests/test-shortcuts.py
python3 tests/test-launcher.py
python3 tests/test-desktop-mode.py
python3 tests/test-settings-ui.py
python3 tests/test-settings-launcher.py
python3 tests/test-fence-settings.py
python3 tests/test-global-settings.py
python3 tests/test-general-parity.py
python3 tests/test-layout-profiles.py
python3 tests/test-views.py
python3 tests/test-manage-rename.py
python3 -m py_compile cinnafences@local/settings.py cinnafences@local/tools/cinnafences-config.py
