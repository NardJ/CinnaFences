#!/usr/bin/python3
"""CinnaFences 0.5.19: English, on-demand GTK3 configuration window.

No background service. General style defaults are stored in ~/.config/cinnafences;
existing Fences keep their appearance until the user opts in to inheritance.
"""
import contextlib
import importlib.util
import io
from pathlib import Path
import re
import sys

# Import beside settings.py even when GTK tests load this module by file path.
_PERF_SPEC = importlib.util.spec_from_file_location(
    'cinnafences_performance', Path(__file__).resolve().with_name('performance.py'))
_perf = importlib.util.module_from_spec(_PERF_SPEC)
_PERF_SPEC.loader.exec_module(_perf)
PerformanceSampler, format_rate = _perf.PerformanceSampler, _perf.format_rate

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib

STYLE_KEYS = (
    'appearance.background', 'appearance.labelColor',
    'appearance.backgroundOpacity', 'appearance.hoverOpacity',
    'appearance.iconOpacity', 'appearance.labelOpacity',
    'appearance.radius', 'appearance.hoverEnabled',
    'appearance.borderEnabled', 'appearance.borderColor',
    'appearance.borderWidth', 'appearance.borderOpacity',
    'icons.size', 'icons.gridWidth', 'icons.gridHeight',
    'icons.showLabels', 'icons.labelFont', 'icons.labelFontSize',
)
PERCENT_KEYS = {'appearance.backgroundOpacity', 'appearance.hoverOpacity',
                'appearance.iconOpacity', 'appearance.labelOpacity',
                'appearance.borderOpacity'}
TOGGLES = {'appearance.hoverEnabled', 'appearance.borderEnabled', 'icons.showLabels'}
COLORS = {'appearance.background', 'appearance.labelColor', 'appearance.borderColor'}
SNAP_KEYS = tuple(('snapping.enabled', 'snapping.fences', 'snapping.screen',
                   'snapping.grid', 'snapping.distance', 'snapping.gridX', 'snapping.gridY'))
SNAP_TOGGLES = set(SNAP_KEYS[:4])
HOTKEY_KEYS = ('hotkeys.enabled', 'hotkeys.toggle')


def load_config():
    path = Path(__file__).resolve().parent / 'tools' / 'cinnafences-config.py'
    spec = importlib.util.spec_from_file_location('cinnafences_config_helper', path)
    if not spec or not spec.loader:
        raise RuntimeError('CinnaFences configuration helper is missing')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def rgba_from_hex(color):
    rgba = Gdk.RGBA()
    if not rgba.parse(color):
        raise ValueError('Invalid color: ' + color)
    return rgba


def hex_from_rgba(rgba):
    return '#%02x%02x%02x' % tuple(round(min(1, max(0, v)) * 255)
                                  for v in (rgba.red, rgba.green, rgba.blue))


def font_family(name):
    return re.sub(r'\s+\d+(?:\.\d+)?$', '', name).strip()


APP_CLASS = 'cinnafences-settings'
APP_TITLE = 'CinnaFences Settings'


def configure_application_identity():
    # Set before creating any GTK window. Match the installed desktop entry
    # exactly, so Cinnamon/CinnaDock can identify this window as CinnaFences,
    # rather than associating a generic Python process with another app.
    GLib.set_prgname(APP_CLASS)
    GLib.set_application_name(APP_TITLE)
    Gdk.set_program_class(APP_CLASS)


class SettingsWindow(Gtk.Window):
    def __init__(self, config, requested_folder=None):
        super().__init__(title=APP_TITLE)
        self.config = config
        self._refreshing = False
        self._loading_fence = False
        self._loaded_fields = None
        self._loaded_global = None
        self._folder_names = []
        self._section_choice_group = Gtk.SizeGroup.new(Gtk.SizeGroupMode.HORIZONTAL)
        # Match the desktop-file ID and StartupWMClass. GTK normally uses
        # Gdk.set_program_class(), but the window hint helps older Cinnamon.
        self.set_wmclass(APP_CLASS, APP_CLASS)
        icon_path = Path(__file__).resolve().parent / 'cinnafences-icon.svg'
        if icon_path.is_file():
            try:
                self.set_icon_from_file(str(icon_path))
            except Exception as exc:
                print('CinnaFences: custom window icon unavailable:', exc, file=sys.stderr)
        self.set_border_width(14)
        self.set_default_size(770, 690)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.connect('destroy', Gtk.main_quit)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(outer)
        self.tabs = Gtk.Notebook()
        outer.pack_start(self.tabs, True, True, 0)
        self._build_general()
        self._build_per_fence()
        self._build_layout_profiles()
        self._build_manage_fences()
        self._build_about()
        close = Gtk.Button.new_with_label('Close')
        close.connect('clicked', lambda *_: self.destroy())
        outer.pack_end(close, False, False, 0)
        self._refresh()
        self.switch.connect('notify::active', self._changed)
        self._reload_global()
        self._reload_fence_list(requested_folder)
        self._reload_layout_profiles()
        self._reload_managed_fences()
        self.connect('focus-in-event', self._on_focus)
        self.tabs.connect('switch-page', self._about_switch_page)
        self.connect('destroy', self._stop_about)

    @staticmethod
    def _heading(message):
        label = Gtk.Label(label=message)
        label.set_xalign(0)
        return label

    @staticmethod
    def _notice(message):
        label = Gtk.Label(label=message)
        label.set_xalign(0)
        label.set_line_wrap(True)
        return label

    @staticmethod
    def _scroll_grid(container):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        container.pack_start(scroll, True, True, 0)
        grid = Gtk.Grid(column_spacing=18, row_spacing=10)
        grid.set_border_width(2)
        scroll.add(grid)
        return grid

    @staticmethod
    def _spin(low, high):
        spin = Gtk.SpinButton.new_with_range(low, high, 1)
        spin.set_numeric(True)
        spin.set_width_chars(6)
        return spin

    def _style_controls(self, grid, only=None):
        controls = {}
        specs = [
            ('Background color', 'appearance.background', Gtk.ColorButton()),
            ('Idle background opacity (%)', 'appearance.backgroundOpacity', self._spin(0, 100)),
            ('Hover background opacity (%)', 'appearance.hoverOpacity', self._spin(0, 100)),
            ('Idle icon opacity (%)', 'appearance.iconOpacity', self._spin(10, 100)),
            ('Idle icon label opacity (%)', 'appearance.labelOpacity', self._spin(10, 100)),
            ('Hover effect', 'appearance.hoverEnabled', Gtk.CheckButton()),
            ('Corner radius (px)', 'appearance.radius', self._spin(0, 28)),
            ('Show Fence border', 'appearance.borderEnabled', Gtk.CheckButton()),
            ('Border color', 'appearance.borderColor', Gtk.ColorButton()),
            ('Border width (px)', 'appearance.borderWidth', self._spin(1, 8)),
            ('Border opacity (%)', 'appearance.borderOpacity', self._spin(0, 100)),
            ('Icon size (px)', 'icons.size', self._spin(20, 96)),
            ('Grid cell width (px)', 'icons.gridWidth', self._spin(48, 150)),
            ('Grid cell height (px)', 'icons.gridHeight', self._spin(52, 170)),
            ('Show icon labels', 'icons.showLabels', Gtk.CheckButton()),
            ('Icon label color', 'appearance.labelColor', Gtk.ColorButton()),
            ('Icon label font', 'icons.labelFont', Gtk.FontButton()),
            ('Icon label font size (pt)', 'icons.labelFontSize', self._spin(6, 24)),
        ]
        filtered=[spec for spec in specs if only is None or spec[1] in only]
        for idx, (label_text, key, widget) in enumerate(filtered):
            label = self._heading(label_text)
            grid.attach(label, 0, idx, 1, 1)
            # Never stretch switches across an entire column like a scrollbar.
            widget.set_hexpand(False)
            widget.set_halign(Gtk.Align.START)
            if isinstance(widget, (Gtk.SpinButton, Gtk.ComboBoxText, Gtk.FontButton)):
                widget.set_size_request(158,-1)
            if key == 'icons.labelFont':
                widget.set_show_size(False)
                widget.set_use_font(True)
            if key in COLORS:
                widget.set_use_alpha(False)
                widget.set_title('Choose ' + label_text.lower())
            grid.attach(widget, 1, idx, 1, 1)
            controls[key] = widget
        return controls

    @staticmethod
    def _style_set(controls, fields):
        for key in controls:
            value = fields[key]
            widget = controls[key]
            if key in COLORS:
                widget.set_rgba(rgba_from_hex(value))
            elif key in TOGGLES:
                widget.set_active(value)
            elif key in PERCENT_KEYS:
                widget.set_value(round(100 * value))
            elif key == 'icons.labelFont':
                widget.set_font_name(value + ' 10')
            else:
                widget.set_value(value)

    @staticmethod
    def _style_get(controls):
        result = {}
        for key in controls:
            widget = controls[key]
            if key in COLORS:
                value = hex_from_rgba(widget.get_rgba())
            elif key in TOGGLES:
                value = widget.get_active()
            elif key in PERCENT_KEYS:
                value = widget.get_value_as_int() / 100.0
            elif key == 'icons.labelFont':
                value = font_family(widget.get_font_name())
            else:
                value = widget.get_value_as_int()
            result[key] = value
        return result

    @staticmethod
    def _category(notebook, title):
        # All nested pages (General and Per Fence) need identical interior
        # padding. Keeping the padding on the page instead of only the Grid
        # also correctly aligns explanatory text and non-grid controls.
        pane=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=10)
        pane.set_border_width(12)
        notebook.append_page(pane,Gtk.Label(label=title))
        return pane

    @staticmethod
    def _section_heading(message):
        label=Gtk.Label(label=message)
        label.set_xalign(0)
        label.set_markup('<b>'+message+'</b>')
        return label

    def _build_manage_fences(self):
        # Use one label/control/action grid for each group.  Both grids have
        # matching column widths, so the selector, status, buttons and text
        # entry form two aligned columns instead of wandering across the page.
        pane=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=11)
        pane.set_border_width(16)
        self.manage_page=pane
        self.tabs.append_page(pane,Gtk.Label(label='Manage Fences'))

        pane.pack_start(self._section_heading('Manage existing Fences'),False,False,0)
        grid=Gtk.Grid(column_spacing=12,row_spacing=9)
        self.manage_selector_grid=grid
        pane.pack_start(grid,False,False,0)
        label=self._heading('Fence')
        label.set_size_request(86,-1)
        grid.attach(label,0,0,1,1)
        self.manage_picker=Gtk.ComboBoxText()
        self.manage_picker.set_size_request(280,-1)
        self.manage_picker.set_hexpand(False)
        self.manage_picker.connect('changed',lambda *_:self._update_manage_actions())
        grid.attach(self.manage_picker,1,0,1,1)
        refresh=Gtk.Button.new_with_label('Refresh')
        refresh.connect('clicked',lambda *_:self._reload_managed_fences())
        grid.attach(refresh,2,0,1,1)

        self.manage_details=self._notice('')
        self.manage_details.set_max_width_chars(49)
        grid.attach(self.manage_details,1,1,2,1)
        actions=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
        self.manage_rename_button=Gtk.Button.new_with_label('Rename…')
        self.manage_rename_button.connect('clicked',self._manage_rename)
        actions.pack_start(self.manage_rename_button,False,False,0)
        self.manage_visibility_button=Gtk.Button.new_with_label('Hide')
        self.manage_visibility_button.connect('clicked',self._manage_toggle_hidden)
        actions.pack_start(self.manage_visibility_button,False,False,0)
        self.manage_lifecycle_button=Gtk.Button.new_with_label('Remove from Desktop…')
        self.manage_lifecycle_button.connect('clicked',self._manage_lifecycle)
        actions.pack_start(self.manage_lifecycle_button,False,False,0)
        grid.attach(actions,1,2,2,1)

        pane.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL),False,False,9)
        pane.pack_start(self._section_heading('Create a Fence'),False,False,0)
        create=Gtk.Grid(column_spacing=12,row_spacing=9)
        self.manage_create_grid=create
        pane.pack_start(create,False,False,0)
        label=self._heading('Folder name')
        label.set_size_request(86,-1)
        create.attach(label,0,0,1,1)
        self.manage_new_name=Gtk.Entry()
        self.manage_new_name.set_size_request(280,-1)
        self.manage_new_name.set_hexpand(False)
        self.manage_new_name.set_placeholder_text('e.g. Coding')
        create.attach(self.manage_new_name,1,0,1,1)
        new=Gtk.Button.new_with_label('Create Fence')
        new.connect('clicked',self._manage_create)
        create.attach(new,2,0,1,1)
        self.manage_existing=Gtk.CheckButton(label='Use existing Desktop folder (keep its contents)')
        create.attach(self.manage_existing,1,1,2,1)
        self.manage_status=self._notice('')
        self.manage_status.set_max_width_chars(49)
        create.attach(self.manage_status,1,2,2,1)
        self._manage_folders=[]
        self._manage_config={}

    def _build_about(self):
        # Only render metrics while the About tab is selected. This UI itself
        # must not become a new permanent source of CPU wakeups.
        pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=13)
        pane.set_border_width(18)
        self.about_page = pane
        self.tabs.append_page(pane, Gtk.Label(label='About'))
        title = self._section_heading('CinnaFences 0.5.19')
        pane.pack_start(title, False, False, 0)
        pane.pack_start(self._notice('Linux Mint Cinnamon desktop organizer'), False, False, 0)
        pane.pack_start(self._notice('Live measurements, updated every 2 seconds while this tab is open.'), False, False, 0)
        self.about_values = {}
        for name, rows in (
            ('Cinnamon process (includes all extensions)', [
                ('pid', 'Process ID'), ('cpu', 'CPU (one core = 100%)'),
                ('rss', 'Memory (RSS)'), ('read', 'Disk reads'), ('write', 'Disk writes')]),
            ('Entire computer', [
                ('system_cpu', 'CPU usage'), ('ram', 'Memory usage'),
                ('disk', 'Disk space used'), ('free', 'Disk space available')]),
        ):
            pane.pack_start(self._section_heading(name), False, False, 0)
            grid = Gtk.Grid(column_spacing=22, row_spacing=8)
            pane.pack_start(grid, False, False, 0)
            for row, (key, caption) in enumerate(rows):
                label = self._heading(caption)
                label.set_size_request(180, -1)
                value = self._heading('—')
                grid.attach(label, 0, row, 1, 1)
                grid.attach(value, 1, row, 1, 1)
                self.about_values[key] = value
        pane.pack_start(self._notice('Cinnamon metrics are for the entire Cinnamon process, '
            'not an isolated CinnaFences measurement. Disk reads/writes reflect '
            'actual process I/O, not total disk activity; cached operations may show 0.'),
            False, False, 0)
        self._about_sampler = None
        self._about_timer = 0

    def _update_about(self):
        try:
            metrics = self._about_sampler.sample()
        except Exception:
            # /proc may be temporarily inaccessible (process exit or session change).
            return True
        def number(key, unit='', digits=1):
            value = metrics.get(key)
            return '—' if value is None else f'{value:.{digits}f}{unit}'
        def rate(key):
            return format_rate(metrics[key]) if metrics.get('pid') is not None else '—'
        text = {
            'pid': str(metrics['pid']) if metrics['pid'] is not None else 'Not running',
            'cpu': number('cpu', '%'), 'rss': number('rss_mib', ' MiB'),
            'read': rate('disk_read_rate'), 'write': rate('disk_write_rate'),
            'system_cpu': number('system_cpu', '%'),
            'ram': ('—' if metrics['ram_used_mib'] is None else
                    f"{metrics['ram_used_mib'] / 1024:.2f} / {metrics['ram_total_mib'] / 1024:.2f} GiB"),
            'disk': ('—' if metrics['disk_used_gib'] is None else
                     f"{metrics['disk_used_gib']:.1f} / {metrics['disk_total_gib']:.1f} GiB"),
            'free': number('disk_free_gib', ' GiB')
        }
        for key, value in text.items():
            self.about_values[key].set_text(value)
        return True

    def _stop_about(self, *_args):
        if getattr(self, '_about_timer', 0):
            GLib.source_remove(self._about_timer)
            self._about_timer = 0
        self._about_sampler = None

    def _about_switch_page(self, _notebook, _page, index):
        if index != self.tabs.page_num(self.about_page):
            self._stop_about()
            return
        self._stop_about()
        self._about_sampler = PerformanceSampler()
        self._update_about()  # first sample primes the delta counters
        self._about_timer = GLib.timeout_add_seconds(2, self._update_about)

    def _reload_managed_fences(self,selected=None):
        previous=selected or self._manage_selected()
        self.manage_picker.remove_all()
        self._manage_folders=[]
        self._manage_config={}
        for folder,cfg in self.config.managed_fences():
            self._manage_folders.append(folder)
            self._manage_config[folder]=cfg
            # The selected Fence status is displayed separately, instead of
            # making the combobox too wide with long title/path/state strings.
            name=cfg.get('title') or folder.name
            self.manage_picker.append_text(name[:34]+'…' if len(name)>35 else name)
        if self._manage_folders:
            self.manage_picker.set_active(self._manage_folders.index(previous)
                if previous in self._manage_folders else 0)
        self._update_manage_actions()
        self._reload_fence_list()

    def _update_manage_actions(self):
        folder=self._manage_selected()
        cfg=self._manage_config.get(folder,{}) if folder else {}
        removed=cfg.get('enabled') is False
        hidden=bool(cfg.get('hidden'))
        self.manage_rename_button.set_sensitive(folder is not None)
        self.manage_visibility_button.set_sensitive(folder is not None and not removed)
        self.manage_lifecycle_button.set_sensitive(folder is not None)
        self.manage_visibility_button.set_label('Show' if hidden else 'Hide')
        self.manage_lifecycle_button.set_label('Reactivate Fence' if removed else 'Remove from Desktop…')
        if folder is None:
            self.manage_details.set_text('No Fences found. Create one below.')
        else:
            state='Removed' if removed else ('Hidden' if hidden else 'Visible')
            detail=('Files preserved; use Reactivate Fence.' if removed else
                    'Temporarily hidden; use Show.' if hidden else
                    'Shown on desktop.')
            self.manage_details.set_text(f'{state}  ·  Folder: {folder.name}')
            self.manage_details.set_tooltip_text(detail)

    def _manage_selected(self):
        if not hasattr(self,'manage_picker'): return None
        n=self.manage_picker.get_active()
        return self._manage_folders[n] if 0<=n<len(self._manage_folders) else None

    def _manage_create(self,*_):
        try:
            folder=self.config.create_managed_fence(self.manage_new_name.get_text(),
                self.manage_existing.get_active())
            self._reload_managed_fences(folder)
            self.manage_status.set_text('Fence created. Folder and files remain yours.')
        except Exception as exc: self._error('Unable to create Fence',exc)

    def _manage_rename(self,*_):
        folder=self._manage_selected()
        if not folder:return
        data=dict(self.config.managed_fences())[folder]
        dialog=Gtk.Dialog(title='Rename Fence',transient_for=self,flags=Gtk.DialogFlags.MODAL)
        dialog.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Rename',Gtk.ResponseType.OK)
        entry=Gtk.Entry(text=data.get('title') or folder.name)
        entry.set_margin_top(12); entry.set_margin_bottom(12)
        entry.set_margin_start(12);entry.set_margin_end(12)
        dialog.get_content_area().pack_start(entry,False,False,0)
        dialog.show_all()
        try:
            if dialog.run()==Gtk.ResponseType.OK:
                self.config.change_managed_fence(folder,title=entry.get_text())
                self._reload_managed_fences(folder)
        except Exception as exc: self._error('Unable to rename Fence',exc)
        finally:dialog.destroy()

    def _manage_toggle_hidden(self,*_):
        folder=self._manage_selected()
        if folder is None:return
        try:
            cfg=dict(self.config.managed_fences())[folder]
            if cfg.get('enabled') is False: raise ValueError('Enable the Fence first.')
            self.config.change_managed_fence(folder,hidden=not cfg.get('hidden',False))
            self._reload_managed_fences(folder)
        except Exception as exc: self._error('Unable to change visibility',exc)

    def _manage_remove(self,*_):
        folder=self._manage_selected()
        if folder is None:return
        dialog=Gtk.MessageDialog(transient_for=self,flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.QUESTION,buttons=Gtk.ButtonsType.YES_NO,
            text='Remove this Fence from the desktop?')
        dialog.format_secondary_text('Only the Fence is disabled. The folder, files and its '
            'settings are kept. You can enable it again here.')
        try:
            if dialog.run()==Gtk.ResponseType.YES:
                self.config.change_managed_fence(folder,enabled=False)
                self._reload_managed_fences(folder)
        except Exception as exc:self._error('Unable to remove Fence',exc)
        finally:dialog.destroy()

    def _manage_lifecycle(self,*_):
        folder=self._manage_selected()
        if folder is None:return
        cfg=self._manage_config.get(folder,{})
        if cfg.get('enabled') is False:
            self._manage_enable()
        else:
            self._manage_remove()

    def _manage_enable(self,*_):
        folder=self._manage_selected()
        if folder is None:return
        try:
            self.config.change_managed_fence(folder,enabled=True,hidden=False)
            self._reload_managed_fences(folder)
        except Exception as exc:self._error('Unable to enable Fence',exc)

    def _build_general(self):
        pane=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=9)
        pane.set_border_width(8)
        self.tabs.append_page(pane,Gtk.Label(label='General'))
        self.general_detail_tabs=Gtk.Notebook()
        pane.pack_start(self.general_detail_tabs,True,True,0)
        desktop=self._category(self.general_detail_tabs,'Desktop')
        desktop.pack_start(self._section_heading('Desktop icons'),False,False,0)
        self.switch=Gtk.CheckButton(label='Hide regular desktop icons (Nemo)')
        desktop.pack_start(self.switch,False,False,0)
        desktop.pack_start(self._notice('Only the icons drawn on your desktop disappear. '
            'Your files remain in the Desktop folder and are still accessible in Fences and Nemo.'),
            False,False,0)
        self.status=self._notice('')
        desktop.pack_start(self.status,False,False,0)
        self.restore_desktop_button=Gtk.Button.new_with_label('Restore previous desktop icon layout')
        self.restore_desktop_button.set_tooltip_text('Restore the Nemo icon layout saved when CinnaFences hid the icons.')
        self.restore_desktop_button.set_halign(Gtk.Align.START)
        self.restore_desktop_button.connect('clicked',self._restore)
        desktop.pack_start(self.restore_desktop_button,False,False,0)
        desktop.pack_start(self._section_heading('Loose desktop items'),False,False,0)
        self.unassigned_switch=Gtk.CheckButton(label='Show loose desktop items in Desktop / Unassigned Fence')
        desktop.pack_start(self.unassigned_switch,False,False,0)
        desktop.pack_start(self._notice('Shows files and ordinary folders stored directly in ~/Desktop, '
            'excluding managed Fence folders. Nothing is moved. Drag items from this '
            'Fence into another Fence to organize them. Click Apply General defaults below.'),False,False,0)

        appearance=self._category(self.general_detail_tabs,'Appearance')
        appearance.pack_start(self._notice('Defaults apply to new Fences and to Fences using General style.'),False,False,0)
        iconpage=self._category(self.general_detail_tabs,'Icons & Labels')
        appearance_keys=[k for k in STYLE_KEYS if k.startswith('appearance.')]
        icon_keys=[k for k in STYLE_KEYS if k.startswith('icons.')]
        # Label color is an icon-label property even though its stored path is appearance.
        appearance_keys.remove('appearance.labelColor')
        icon_keys.append('appearance.labelColor')
        self.global_controls={}
        self.global_controls.update(self._style_controls(self._scroll_grid(appearance),appearance_keys))
        self.global_controls.update(self._style_controls(self._scroll_grid(iconpage),icon_keys))
        headerpage=self._category(self.general_detail_tabs,'Header')
        headerpage.pack_start(self._notice('Defaults for the titlebar, inherited only by Fences that opt in to General Header & Sections.'),False,False,0)
        self.global_header_controls=self._bar_controls(self._scroll_grid(headerpage),self._header_specs())
        folderpage=self._category(self.general_detail_tabs,'Folders & Sections')
        folderpage.pack_start(self._notice('Choose a default view for NEW Fences. Existing Fences retain their selected Icons, Tabs or Rolodex mode.'),False,False,0)
        foldergrid=self._scroll_grid(folderpage)
        foldergrid.attach(self._heading('Default folder view (new Fences)'),0,0,1,1)
        self.global_view_mode=Gtk.ComboBoxText()
        self.global_view_mode.set_halign(Gtk.Align.START)
        self.global_view_mode.set_size_request(158,-1)
        self._section_choice_group.add_widget(self.global_view_mode)
        for label in ('Icons (original)','Tabs','Rolodex (accordion)'):
            self.global_view_mode.append_text(label)
        foldergrid.attach(self.global_view_mode,1,0,1,1)
        folderpage.pack_start(self._notice('Other options below are inherited only by Fences using General Header & Sections.'),False,False,0)
        self.global_section_controls=self._bar_controls(foldergrid,self._section_specs(),2)
        # Same presentation-category order as Per Fence.
        self.general_detail_tabs.reorder_child(headerpage,1)
        self.general_detail_tabs.reorder_child(appearance,2)
        self.general_detail_tabs.reorder_child(folderpage,3)
        self.general_detail_tabs.reorder_child(iconpage,4)
        positioning=self._category(self.general_detail_tabs,'Positioning')
        positioning.pack_start(self._notice('Snap settings. Hold Alt while dragging to bypass snapping.'),False,False,0)
        grid=self._scroll_grid(positioning)
        self.snap_controls={}
        specs=[('Enable snapping','snapping.enabled',Gtk.CheckButton()),
               ('Snap to other Fences','snapping.fences',Gtk.CheckButton()),
               ('Snap to monitor edges','snapping.screen',Gtk.CheckButton()),
               ('Snap to desktop grid','snapping.grid',Gtk.CheckButton()),
               ('Snap distance (px)','snapping.distance',self._spin(2,40)),
               ('Grid width (px)','snapping.gridX',self._spin(8,200)),
               ('Grid height (px)','snapping.gridY',self._spin(8,200))]
        for idx,(label,key,widget) in enumerate(specs):
            widget.set_hexpand(False)
            widget.set_halign(Gtk.Align.START)
            grid.attach(self._heading(label),0,idx,1,1)
            grid.attach(widget,1,idx,1,1)
            self.snap_controls[key]=widget
        shortcuts=self._category(self.general_detail_tabs,'Shortcuts')
        shortcuts.pack_start(self._notice('Optional shortcut for showing or hiding all Fences. '
            'If Cinnamon already uses it, registration may fail.'),False,False,0)
        keygrid=self._scroll_grid(shortcuts)
        self.hotkey_enable=Gtk.CheckButton()
        keygrid.attach(self._heading('Enable show/hide shortcut'),0,0,1,1)
        keygrid.attach(self.hotkey_enable,1,0,1,1)
        self.hotkey_toggle=Gtk.Entry()
        self.hotkey_toggle.set_width_chars(20)
        self.hotkey_toggle.set_max_length(48)
        self.hotkey_toggle.set_hexpand(False)
        self.hotkey_toggle.set_tooltip_text('Example: <Super>f or <Control><Alt>f')
        keygrid.attach(self._heading('Show / hide all Fences'),0,1,1,1)
        keygrid.attach(self.hotkey_toggle,1,1,1,1)
        self.global_status=self._notice('')
        pane.pack_start(self.global_status,False,False,0)
        btns=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
        apply=Gtk.Button.new_with_label('Apply General defaults')
        apply.connect('clicked',self._apply_general)
        btns.pack_start(apply,False,False,0)
        revert=Gtk.Button.new_with_label('Revert Changes')
        revert.connect('clicked',lambda *_:self._reload_global())
        btns.pack_start(revert,False,False,0)
        reset=Gtk.Button.new_with_label('Reset to factory defaults')
        reset.connect('clicked',self._reset_general)
        btns.pack_start(reset,False,False,0)
        pane.pack_start(btns,False,False,0)

    def _build_per_fence(self):
        pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        pane.set_border_width(12)
        self.tabs.append_page(pane, Gtk.Label(label='Per Fence'))
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.pack_start(self._heading('Fence:'), False, False, 0)
        self.fence_picker = Gtk.ComboBoxText()
        self.fence_picker.set_hexpand(True)
        self.fence_picker.connect('changed', self._on_fence_changed)
        row.pack_start(self.fence_picker, True, True, 0)
        refresh = Gtk.Button.new_with_label('Refresh list')
        refresh.connect('clicked', lambda *_: self._reload_fence_list())
        row.pack_start(refresh, False, False, 0)
        pane.pack_start(row, False, False, 0)
        pane.pack_start(self._notice('Changes are saved only with Apply. Switching Fences '
                                     'discards unapplied edits.'), False, False, 0)
        self.inherit_globals = Gtk.CheckButton(label='Use General Appearance & Icons for this Fence')
        self.inherit_globals.connect('toggled', self._inherit_toggled)
        pane.pack_start(self.inherit_globals, False, False, 0)
        self.inherit_advanced = Gtk.CheckButton(label='Use General Header & Sections for this Fence')
        self.inherit_advanced.connect('toggled', self._inherit_toggled)
        pane.pack_start(self.inherit_advanced, False, False, 0)
        self.fence_detail_tabs = Gtk.Notebook()
        pane.pack_start(self.fence_detail_tabs, True, True, 0)
        layout_page=self._category(self.fence_detail_tabs,'Fence & Layout')
        layout_page.pack_start(self._notice('Name, manual size and position lock. Auto-fit in Rolodex '
            'uses the manual height again when disabled.'),False,False,0)
        title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        title_row.pack_start(self._heading('Fence title:'), False, False, 0)
        self.fence_title = Gtk.Entry()
        title_row.pack_start(self.fence_title, True, True, 0)
        layout_page.pack_start(title_row, False, False, 0)
        size_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        size_row.pack_start(self._heading('Fence width (px):'), False, False, 0)
        self.fence_width = self._spin(172, 2400)
        size_row.pack_start(self.fence_width, False, False, 0)
        size_row.pack_start(self._heading('Height (px):'), False, False, 0)
        self.fence_height = self._spin(108, 1600)
        size_row.pack_start(self.fence_height, False, False, 0)
        layout_page.pack_start(size_row, False, False, 0)
        self.lock_geometry = Gtk.CheckButton(label='Lock position and size')
        layout_page.pack_start(self.lock_geometry, False, False, 0)
        # Logical order: Fence & Layout, Header, Appearance, Folders, Icons.
        self._build_view_options()
        appearance=self._category(self.fence_detail_tabs,'Appearance')
        iconpage=self._category(self.fence_detail_tabs,'Icons & Labels')
        appearance_keys=[k for k in STYLE_KEYS if k.startswith('appearance.')]
        icon_keys=[k for k in STYLE_KEYS if k.startswith('icons.')]
        appearance_keys.remove('appearance.labelColor')
        icon_keys.append('appearance.labelColor')
        self.fence_controls={}
        self.fence_controls.update(self._style_controls(self._scroll_grid(appearance),appearance_keys))
        self.fence_controls.update(self._style_controls(self._scroll_grid(iconpage),icon_keys))
        # The view builder creates Folders & Sections followed by Header; reorder
        # the notebook pages without reconstructing widgets or their signals.
        self.fence_detail_tabs.reorder_child(self._header_page,1)
        self.fence_detail_tabs.reorder_child(appearance,2)
        self.fence_status = self._notice('')
        pane.pack_start(self.fence_status, False, False, 0)
        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        apply = Gtk.Button.new_with_label('Apply Fence settings')
        apply.connect('clicked', self._apply_fence)
        btns.pack_start(apply, False, False, 0)
        copy = Gtk.Button.new_with_label('Copy General style as starting point')
        copy.connect('clicked', self._copy_general_to_fence)
        btns.pack_start(copy, False, False, 0)
        reload = Gtk.Button.new_with_label('Revert Changes')
        reload.connect('clicked', lambda *_: self._on_fence_changed())
        btns.pack_start(reload, False, False, 0)
        pane.pack_start(btns, False, False, 0)

    def _build_view_options(self):
        pane=self._category(self.fence_detail_tabs,'Folders & Sections')
        pane.pack_start(self._notice('View direct subfolders as tabs or a single-open Rolodex. '
            'Arrange icons within a section; drop onto another tab or section to move files (Ctrl to copy). Section bar height is '
            'the height of EACH row; it does not depend on the Fence height.'),False,False,0)
        grid=self._scroll_grid(pane)
        grid.attach(self._heading('Folder view'),0,0,1,1)
        self.view_mode=Gtk.ComboBoxText()
        self.view_mode.set_halign(Gtk.Align.START)
        self.view_mode.set_size_request(158,-1)
        self._section_choice_group.add_widget(self.view_mode)
        for label in ('Icons (original)','Tabs','Rolodex (accordion)'):
            self.view_mode.append_text(label)
        grid.attach(self.view_mode,1,0,1,1)
        self.section_controls=self._bar_controls(grid,self._section_specs(),2)
        head=self._category(self.fence_detail_tabs,'Header')
        self._header_page=head
        head.pack_start(self._notice('The header and Fence share the same compositing rules; their colors and opacity are independent.'),False,False,0)
        self.header_controls=self._bar_controls(self._scroll_grid(head),self._header_specs())

    def _section_specs(self):
        return [
            ('Show tabs in titlebar (when they fit)','view.tabsInHeader',Gtk.CheckButton()),
            ('Auto-fit height in Rolodex','view.autoFitHeight',Gtk.CheckButton()),
            ('Maximum auto-fit height (px)','view.autoFitMaxHeight',self._spin(160,1600)),
            ('Idle background color','sections.background',Gtk.ColorButton()),
            ('Idle background opacity (%)','sections.opacity',self._spin(0,100)),
            ('Hover background color','sections.hoverBackground',Gtk.ColorButton()),
            ('Hover background opacity (%)','sections.hoverOpacity',self._spin(0,100)),
            ('Idle text color','sections.textColor',Gtk.ColorButton()),
            ('Hover text color','sections.hoverTextColor',Gtk.ColorButton()),
            ('Font family','sections.fontFamily',Gtk.FontButton()),
            ('Font size (pt)','sections.fontSize',self._spin(7,20)),
            ('Section alignment','sections.alignment',Gtk.ComboBoxText()),
            ('Show expand/collapse arrow','sections.showCollapseButton',Gtk.CheckButton()),
            ('Section bar height (px)','sections.height',self._spin(24,55)),
        ]

    def _header_specs(self):
        return [
            ('Show titlebar','header.show',Gtk.CheckButton()),
            ('Idle background color','header.background',Gtk.ColorButton()),
            ('Idle background opacity (%)','header.opacity',self._spin(0,100)),
            ('Hover background color','header.hoverBackground',Gtk.ColorButton()),
            ('Hover background opacity (%)','header.hoverOpacity',self._spin(0,100)),
            ('Idle text color','header.textColor',Gtk.ColorButton()),
            ('Hover text color','header.hoverTextColor',Gtk.ColorButton()),
            ('Font family','header.fontFamily',Gtk.FontButton()),
            ('Font size (pt)','header.fontSize',self._spin(7,22)),
            ('Header height (px)','header.height',self._spin(24,64)),
            ('Show collapse button','header.showCollapseButton',Gtk.CheckButton()),
        ]

    def _bar_controls(self,grid,specs,row=0):
        controls={}
        for idx,(label,key,widget) in enumerate(specs,row):
            grid.attach(self._heading(label),0,idx,1,1)
            widget.set_hexpand(False)
            widget.set_halign(Gtk.Align.START)
            if isinstance(widget, (Gtk.SpinButton, Gtk.ComboBoxText, Gtk.FontButton)):
                widget.set_size_request(158,-1)
                self._section_choice_group.add_widget(widget)
            if key.endswith(('background','Background','textColor','TextColor')):
                widget.set_use_alpha(False)
                widget.set_title('Choose '+label.lower())
            elif key.endswith('fontFamily'):
                widget.set_show_size(False)
                widget.set_use_font(True)
            elif key=='sections.alignment':
                for choice in ('Left','Center','Right'):
                    widget.append_text(choice)
            grid.attach(widget,1,idx,1,1)
            controls[key]=widget
        return controls

    @staticmethod
    def _bar_set(controls,fields):
        for key,widget in controls.items():
            value=fields[key]
            if key.endswith(('background','Background','textColor','TextColor')):
                widget.set_rgba(rgba_from_hex(value))
            elif key.endswith('fontFamily'):
                widget.set_font_name(value+' 10')
            elif key=='sections.alignment':
                widget.set_active(('left','center','right').index(value))
            elif isinstance(value,bool):
                widget.set_active(value)
            elif key.endswith(('opacity','Opacity')):
                widget.set_value(round(value*100))
            else:
                widget.set_value(value)

    @staticmethod
    def _bar_get(controls):
        result={}
        for key,widget in controls.items():
            if key.endswith(('background','Background','textColor','TextColor')):
                result[key]=hex_from_rgba(widget.get_rgba())
            elif key.endswith('fontFamily'):
                result[key]=font_family(widget.get_font_name())
            elif key=='sections.alignment':
                result[key]=('left','center','right')[max(0,widget.get_active())]
            elif key in ('header.show','header.showCollapseButton','sections.showCollapseButton','view.tabsInHeader','view.autoFitHeight'):
                result[key]=widget.get_active()
            elif key.endswith(('opacity','Opacity')):
                result[key]=widget.get_value_as_int()/100.0
            else:
                result[key]=widget.get_value_as_int()
        return result

    @staticmethod
    def _current_monitor_layout():
        # GTK/GDK screen coordinates match Cinnamon's logical X11 layout.
        # Query only when the user explicitly saves/restores: no polling.
        screen = Gdk.Screen.get_default()
        if screen is None:
            raise RuntimeError('No active display is available')
        result=[]
        for index in range(screen.get_n_monitors()):
            r = screen.get_monitor_geometry(index)
            result.append({'x':int(r.x),'y':int(r.y),
                           'width':int(r.width),'height':int(r.height)})
        if not result:
            raise RuntimeError('No monitors reported by GTK')
        return result

    def _build_layout_profiles(self):
        # One aligned form instead of several unrelated rows of controls.
        # All operations are still explicit user actions; a display change
        # never auto-saves or restores any profile.
        pane=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12)
        pane.set_border_width(16)
        self.tabs.append_page(pane,Gtk.Label(label='Monitor Layouts'))
        pane.pack_start(self._section_heading('Fence position profiles'),False,False,0)
        pane.pack_start(self._notice('Save and restore the positions and sizes of your Fences. '
            'Files, icon order and appearance are not changed. Profiles are restored manually.'),
            False,False,0)
        self.layout_monitor_status=self._notice('')
        pane.pack_start(self.layout_monitor_status,False,False,0)

        form=Gtk.Grid(column_spacing=14,row_spacing=11)
        self.layout_form=form
        pane.pack_start(form,False,False,0)
        form.attach(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL),0,0,3,1)
        form.attach(self._section_heading('Restore a saved layout'),0,1,3,1)
        form.attach(self._heading('Saved layout'),0,2,1,1)
        self.layout_picker=Gtk.ComboBoxText()
        self.layout_picker.set_hexpand(True)
        form.attach(self.layout_picker,1,2,1,1)
        refresh=Gtk.Button.new_with_label('Refresh list')
        refresh.connect('clicked',self._reload_layout_profiles)
        form.attach(refresh,2,2,1,1)
        saved_actions=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
        restore=Gtk.Button.new_with_label('Restore selected layout')
        restore.connect('clicked',self._restore_layout_profile)
        saved_actions.pack_start(restore,False,False,0)
        undo=Gtk.Button.new_with_label('Undo last restore')
        undo.connect('clicked',self._undo_layout_restore)
        saved_actions.pack_start(undo,False,False,0)
        delete=Gtk.Button.new_with_label('Delete selected profile')
        delete.connect('clicked',self._delete_layout_profile)
        saved_actions.pack_start(delete,False,False,0)
        form.attach(saved_actions,1,3,2,1)

        form.attach(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL),0,4,3,1)
        form.attach(self._section_heading('Save the current layout'),0,5,3,1)
        form.attach(self._heading('Profile name'),0,6,1,1)
        self.layout_name=Gtk.Entry()
        self.layout_name.set_hexpand(True)
        self.layout_name.set_max_length(48)
        self.layout_name.set_placeholder_text('e.g. Default or Working layout')
        form.attach(self.layout_name,1,6,2,1)
        save=Gtk.Button.new_with_label('Save current layout')
        save.set_halign(Gtk.Align.START)
        save.connect('clicked',self._save_layout_profile)
        form.attach(save,1,7,1,1)
        self.layout_status=self._notice('')
        pane.pack_start(self.layout_status,False,False,0)

    def _selected_layout(self):
        index=self.layout_picker.get_active()
        return self.layout_names[index] if 0 <= index < len(self.layout_names) else None

    def _reload_layout_profiles(self, *_):
        try:
            try:
                monitors=self._current_monitor_layout()
                monitor_text=f'{len(monitors)} monitor' + ('s' if len(monitors) != 1 else '')
            except Exception:
                monitor_text='Monitor geometry will be checked when saving/restoring.'
            self.layout_monitor_status.set_text('Current setup: '+monitor_text)
            prior=getattr(self, 'layout_names', [])
            prior_name = self._selected_layout() if prior else None
            profiles = self.config.list_layout_profiles()
            self.layout_names = [p['name'] for p in profiles]
            self.layout_picker.remove_all()
            for p in profiles:
                self.layout_picker.append_text(
                    f"{p['name']}  —  {p['monitors']} " + ('monitor' if p['monitors']==1 else 'monitors') +
                    f", {p['fences']} " + ('Fence' if p['fences']==1 else 'Fences'))
            if profiles:
                index=self.layout_names.index(prior_name) if prior_name in self.layout_names else 0
                self.layout_picker.set_active(index)
            else:
                self.layout_picker.set_active(-1)
            self.layout_status.set_text(f"{len(profiles)} saved "+('layout.' if len(profiles)==1 else 'layouts.'))
        except Exception as exc:
            self.layout_status.set_text(f'Could not list profiles: {exc}')

    def _confirm_layout_action(self, title, details):
        dialog = Gtk.MessageDialog(transient_for=self, flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.QUESTION, buttons=Gtk.ButtonsType.YES_NO, text=title)
        dialog.format_secondary_text(details)
        response=dialog.run()
        dialog.destroy()
        return response==Gtk.ResponseType.YES

    def _save_layout_profile(self, *_):
        try:
            name=self.layout_name.get_text().strip()
            known=[p['name'] for p in self.config.list_layout_profiles()]
            if name in known and not self._confirm_layout_action('Replace saved layout?',
                        f'The saved profile “{name}” will be replaced with current Fence positions.'):
                return
            count=self.config.save_layout_profile(name, self._current_monitor_layout())
            self._reload_layout_profiles()
            self.layout_picker.set_active(self.layout_names.index(name))
            self.layout_status.set_text(f'Saved “{name}” with {count} Fence(s).')
        except Exception as exc:
            self._error('Unable to save monitor layout', exc)

    def _restore_layout_profile(self, *_):
        name=self._selected_layout()
        if not name:
            self.layout_status.set_text('Select a saved layout first.')
            return
        if not self._confirm_layout_action('Restore Fence layout?',
                f'Apply the stored positions and sizes from “{name}”? This is undoable.'):
            return
        try:
            count=self.config.restore_layout_profile(name,self._current_monitor_layout())
            self.layout_status.set_text(f'Restored {count} Fence(s) from “{name}”. Undo last restore is available.')
            self._reload_fence_list()
        except Exception as exc:
            self._error('Unable to restore layout',exc)

    def _undo_layout_restore(self, *_):
        try:
            count=self.config.undo_layout_restore(self._current_monitor_layout())
            self.layout_status.set_text(f'Undid the last restore for {count} Fence(s).')
            self._reload_fence_list()
        except Exception as exc:
            self._error('Unable to undo layout restore',exc)

    def _delete_layout_profile(self, *_):
        name=self._selected_layout()
        if not name:
            self.layout_status.set_text('Select a saved layout first.')
            return
        if not self._confirm_layout_action('Delete saved layout?',
                f'The profile “{name}” will be deleted. Current Fence positions will stay unchanged.'):
            return
        try:
            self.config.delete_layout_profile(name)
            self._reload_layout_profiles()
            self.layout_status.set_text(f'Deleted saved layout “{name}”.')
        except Exception as exc:
            self._error('Unable to delete profile',exc)

    def _inherit_toggled(self, *_):
        appearance_local = not self.inherit_globals.get_active()
        advanced_local = not self.inherit_advanced.get_active()
        for widget in self.fence_controls.values():
            widget.set_sensitive(appearance_local)
        for widget in list(self.header_controls.values())+list(self.section_controls.values()):
            widget.set_sensitive(advanced_local)
        # View mode is structural and always belongs to the individual Fence.
        self.view_mode.set_sensitive(self._selected_folder() != getattr(self.config, 'DESKTOP', Path.home() / 'Desktop'))
        if self._loaded_fields is None:
            return
        try:
            values=self.config.read_global_settings()
            self._style_set(self.fence_controls, self._loaded_fields if appearance_local else values)
            show_fields=self._loaded_fields if advanced_local else values
            self._bar_set(self.header_controls,show_fields)
            self._bar_set(self.section_controls,show_fields)
        except Exception:
            pass

    def _state(self):
        state = self.config.desktop_mode_state()
        layout = self.config.nemo_layout()
        return (state is not None and layout == self.config.HIDDEN_LAYOUT, state, layout)

    def _refresh(self):
        enabled, state, layout = self._state()
        self._refreshing = True
        try:
            self.switch.set_active(enabled)
        finally:
            self._refreshing = False
        if enabled:
            message='Desktop icons are hidden by CinnaFences.'
        elif state is not None:
            message='Desktop icons were changed outside CinnaFences. Your current choice is preserved.'
        elif layout == self.config.HIDDEN_LAYOUT:
            message='Desktop icons are already hidden in Nemo settings.'
        else:
            message='Desktop icons are visible.'
        self.status.set_text(message)
        self.restore_desktop_button.set_sensitive(state is not None)

    def _error(self, message, exception):
        dialog = Gtk.MessageDialog(transient_for=self, flags=Gtk.DialogFlags.MODAL,
                                   message_type=Gtk.MessageType.ERROR,
                                   buttons=Gtk.ButtonsType.OK, text=message)
        dialog.format_secondary_text(str(exception))
        dialog.run()
        dialog.destroy()

    def _apply(self, mode):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                self.config.desktop_mode(mode)
        except Exception as exc:
            self._error('Unable to change Nemo desktop setting', exc)
        finally:
            try:
                self._refresh()
            except Exception as exc:
                self.status.set_text(f'Unable to read status: {exc}')

    def _changed(self, _switch, _property):
        if not self._refreshing:
            self._apply('on' if self.switch.get_active() else 'off')

    def _restore(self, _button):
        self._apply('restore')

    def _on_focus(self, *_):
        if not self._refreshing:
            try:
                self._refresh()
            except Exception:
                pass
        return False

    def _reset_general(self, *_):
        """Show factory presentation values for review; Apply is required.

        Never reset Nemo's Hide desktop icons choice here. It is independent
        from General presentation defaults and has its own Restore control.
        """
        try:
            factory=self.config.default_style()
            self._style_set(self.global_controls, factory)
            self._bar_set(self.global_header_controls,factory)
            self._bar_set(self.global_section_controls,factory)
            self.global_view_mode.set_active(('icons','tabs','rolodex').index(factory['view.mode']))
            self._set_snapping(self.config.default_snapping())
            self.global_status.set_text('Factory defaults loaded. Click Apply General defaults to save.')
        except Exception as exc:
            self._error('Unable to load factory defaults', exc)

    def _copy_general_to_fence(self, *_):
        """Snapshot General into editable local fields; nothing saved yet.

        Unlike Use General style, the copied values are independent and may
        be modified immediately. Switching inherit off restores old fields,
        so the copy must happen AFTER changing the inheritance toggle.
        """
        if self._selected_folder() is None or self._loaded_fields is None:
            self.fence_status.set_text('Select an active Fence first.')
            return
        try:
            values = self.config.read_global_settings()
            self.inherit_globals.set_active(False)
            self.inherit_advanced.set_active(False)
            self._style_set(self.fence_controls, values)
            self._bar_set(self.header_controls, values)
            self._bar_set(self.section_controls, values)
            # Never copy General's default view.mode over a working Rolodex.
            self.fence_status.set_text('General presentation copied into editable fields. Click Apply Fence settings to save.')
        except Exception as exc:
            self._error('Unable to copy General style', exc)

    def _set_snapping(self, values):
        for key in SNAP_KEYS:
            widget=self.snap_controls[key]
            if key in SNAP_TOGGLES:
                widget.set_active(values[key])
            else:
                widget.set_value(values[key])

    def _get_snapping(self):
        return {key: (self.snap_controls[key].get_active() if key in SNAP_TOGGLES
                      else self.snap_controls[key].get_value_as_int()) for key in SNAP_KEYS}

    def _reload_global(self):
        try:
            fields = self.config.read_global_settings()
            snapping = self.config.read_snapping_settings()
            hotkeys = self.config.read_hotkey_settings()
            self._loaded_global = {**fields, **snapping, **hotkeys, 'unassigned.enabled':self.config.read_unassigned_enabled()}
            self._style_set(self.global_controls, fields)
            self._bar_set(self.global_header_controls, fields)
            self._bar_set(self.global_section_controls, fields)
            self.global_view_mode.set_active(('icons','tabs','rolodex').index(fields['view.mode']))
            self._set_snapping(snapping)
            self.hotkey_enable.set_active(hotkeys['hotkeys.enabled'])
            self.hotkey_toggle.set_text(hotkeys['hotkeys.toggle'])
            self.unassigned_switch.set_active(self._loaded_global['unassigned.enabled'])
            self.global_status.set_text('General defaults loaded.')
        except Exception as exc:
            self._loaded_global = None
            self.global_status.set_text(f'Unable to load General defaults: {exc}')

    def _apply_general(self, *_):
        if self._loaded_global is None:
            return
        current = {**self._style_get(self.global_controls),
                   **self._bar_get(self.global_header_controls),
                   **self._bar_get(self.global_section_controls),
                   'view.mode':('icons','tabs','rolodex')[max(0,self.global_view_mode.get_active())],
                   **self._get_snapping(),
                   'hotkeys.enabled': self.hotkey_enable.get_active(),
                   'hotkeys.toggle': self.hotkey_toggle.get_text().strip(),
                   'unassigned.enabled':self.unassigned_switch.get_active()}
        changes = {key: val for key, val in current.items() if val != self._loaded_global[key]}
        if not changes:
            self.global_status.set_text('No changes to save.')
            return
        try:
            self.config.update_general_settings(changes)
            self._reload_global()
            self.global_status.set_text('General defaults saved. Shortcut takes effect immediately if available.')
            self._inherit_toggled()
        except Exception as exc:
            self._error('Unable to save General defaults', exc)
            self.global_status.set_text('Save failed; no changes were applied.')

    def _fence_form_has_edits(self):
        if self._loaded_fields is None or self._loading_fence:
            return False
        try:
            fields=self._loaded_fields
            current={'title':self.fence_title.get_text(),
                     'geometry.width':self.fence_width.get_value_as_int(),
                     'geometry.height':self.fence_height.get_value_as_int(),
                     'geometryLocked':self.lock_geometry.get_active(),
                     'inheritGlobals':self.inherit_globals.get_active(),
                     'inheritAdvancedGlobals':self.inherit_advanced.get_active(),
                     'view.mode':('icons','tabs','rolodex')[max(0,self.view_mode.get_active())]}
            if not current['inheritGlobals']:
                current.update(self._style_get(self.fence_controls))
            if not current['inheritAdvancedGlobals']:
                current.update(self._bar_get(self.header_controls))
                current.update(self._bar_get(self.section_controls))
            return any(value!=fields.get(key) for key,value in current.items())
        except (ValueError,AttributeError,KeyError):
            return False

    def _reload_fence_list(self, requested=None):
        current = requested or self._selected_folder()
        previous=self._selected_folder()
        keep_edits=(previous is not None and self._fence_form_has_edits())
        active = self.config.active_fence_folders()
        self._folder_names = active
        self._loading_fence = True
        try:
            self.fence_picker.remove_all()
            for folder in active:
                # The user-visible Fence title is independent of the folder
                # name.  Show the title in Per Fence just as Manage Fences and
                # the Cinnamon desktop do. Retain the folder identity when
                # the title differs to distinguish similarly named Fences.
                virtual=folder == getattr(self.config, 'DESKTOP', Path.home() / 'Desktop')
                original='Desktop / Unassigned' if virtual else folder.name
                try:
                    actual=self.config.read_fence_settings(folder).get('title') or original
                except (ValueError,OSError,KeyError,TypeError):
                    actual=original
                label=actual if actual == original else f'{actual}  [{original}]'
                self.fence_picker.append_text(label)
            if active:
                index = next((i for i, folder in enumerate(active) if str(folder) == str(current)), 0)
                self.fence_picker.set_active(index)
            else:
                self.fence_picker.set_active(-1)
        finally:
            self._loading_fence = False
        if active:
            if keep_edits and previous == self._selected_folder():
                # Never discard pending edits merely because Manage Fences
                # refreshed or renamed a Fence.  If the user did not edit the
                # title locally, synchronize the renamed title immediately.
                latest=self._fields(self.config.read_fence_settings(previous), previous)['title']
                if self.fence_title.get_text()==self._loaded_fields['title']:
                    self.fence_title.set_text(latest)
                    self._loaded_fields['title']=latest
                self.fence_status.set_text('Unapplied edits kept. Click Apply or Revert Changes.')
            else:
                self._on_fence_changed()
        else:
            self._loaded_fields = None
            self.fence_status.set_text('No active Fences. Create one from Nemo first.')

    def _selected_folder(self):
        index = self.fence_picker.get_active()
        if 0 <= index < len(self._folder_names):
            return self._folder_names[index]
        return None

    @staticmethod
    def _fields(data, folder):
        a, i = data.get('appearance', {}), data.get('icons', {})
        default = {
            'title': data.get('title') or folder.name,
            'geometryLocked': data.get('geometryLocked', False),
            'geometry.width': data.get('geometry', {}).get('width', 350),
            'geometry.height': data.get('geometry', {}).get('height', 270),
            'inheritGlobals': data.get('inheritGlobals', False),
            'inheritAdvancedGlobals': data.get('inheritAdvancedGlobals', False),
            'appearance.background': a.get('background', '#202733'),
            'appearance.labelColor': a.get('labelColor', '#ffffff'),
            'appearance.backgroundOpacity': a.get('backgroundOpacity', 0.27),
            'appearance.hoverOpacity': a.get('hoverOpacity', 0.75),
            'appearance.iconOpacity': a.get('iconOpacity', 0.45),
            'appearance.labelOpacity': a.get('labelOpacity', 0.60),
            'appearance.hoverEnabled': a.get('hoverEnabled', True),
            'appearance.radius': a.get('radius', 12),
            'appearance.borderEnabled': a.get('borderEnabled', True),
            'appearance.borderColor': a.get('borderColor', '#f0f5ff'),
            'appearance.borderWidth': a.get('borderWidth', 1),
            'appearance.borderOpacity': a.get('borderOpacity', 0.16),
            'icons.size': i.get('size', 48),
            'icons.gridWidth': i.get('gridWidth', 86),
            'icons.gridHeight': i.get('gridHeight', 88),
            'icons.showLabels': i.get('showLabels', True),
            'icons.labelFont': i.get('labelFont', 'Sans'),
            'icons.labelFontSize': i.get('labelFontSize', 9),
            'view.mode': data.get('view',{}).get('mode','icons'),
            'view.tabsInHeader': data.get('view',{}).get('tabsInHeader',False),
            'view.autoFitHeight': data.get('view',{}).get('autoFitHeight',False),
            'view.autoFitMaxHeight': data.get('view',{}).get('autoFitMaxHeight',720),
            'header.show': data.get('header',{}).get('show',True),
            'header.background': data.get('header',{}).get('background','#0c1017'),
            'header.opacity': data.get('header',{}).get('opacity',0.20),
            'header.hoverBackground': data.get('header',{}).get('hoverBackground',data.get('header',{}).get('background','#0c1017')),
            'header.hoverOpacity': data.get('header',{}).get('hoverOpacity',data.get('header',{}).get('opacity',0.20)),
            'header.hoverTextColor': data.get('header',{}).get('hoverTextColor',data.get('header',{}).get('textColor','#ffffff')),
            'header.fontFamily': data.get('header',{}).get('fontFamily','Sans'),
            'header.textColor': data.get('header',{}).get('textColor','#ffffff'),
            'header.fontSize': data.get('header',{}).get('fontSize',11),
            'header.height': data.get('header',{}).get('height',32),
            'header.showCollapseButton': data.get('header',{}).get('showCollapseButton',True),
            'sections.background': data.get('sections',{}).get('background','#344052'),
            'sections.opacity': data.get('sections',{}).get('opacity',0.80),
            'sections.hoverBackground': data.get('sections',{}).get('hoverBackground',data.get('sections',{}).get('background','#344052')),
            'sections.hoverOpacity': data.get('sections',{}).get('hoverOpacity',data.get('sections',{}).get('opacity',0.80)),
            'sections.hoverTextColor': data.get('sections',{}).get('hoverTextColor',data.get('sections',{}).get('textColor','#ffffff')),
            'sections.fontFamily': data.get('sections',{}).get('fontFamily','Sans'),
            'sections.alignment': data.get('sections',{}).get('alignment','center'),
            'sections.showCollapseButton': data.get('sections',{}).get('showCollapseButton',True),
            'sections.textColor': data.get('sections',{}).get('textColor','#ffffff'),
            'sections.fontSize': data.get('sections',{}).get('fontSize',10),
            'sections.height': data.get('sections',{}).get('height',30),
        }
        return default

    def _on_fence_changed(self, *_):
        if self._loading_fence:
            return
        folder = self._selected_folder()
        if folder is None:
            self._loaded_fields = None
            return
        try:
            fields = self._fields(self.config.read_fence_settings(folder), folder)
            self._loaded_fields = fields
            self.fence_title.set_text(fields['title'])
            self.fence_width.set_value(fields['geometry.width'])
            self.fence_height.set_value(fields['geometry.height'])
            self.lock_geometry.set_active(fields['geometryLocked'])
            self.inherit_globals.set_active(fields['inheritGlobals'])
            self.inherit_advanced.set_active(fields['inheritAdvancedGlobals'])
            self.view_mode.set_active(('icons','tabs','rolodex').index(fields['view.mode']))
            # Desktop / Unassigned is virtual, not a container of Fence folders.
            self.view_mode.set_sensitive(folder != getattr(self.config, 'DESKTOP', Path.home() / 'Desktop'))
            self.view_mode.set_tooltip_text('Unassigned is an Icons-only view of loose Desktop items' if folder == getattr(self.config, 'DESKTOP', Path.home() / 'Desktop') else None)
            self._inherit_toggled()
            self.fence_status.set_text(f'{folder.name}: settings loaded. Click Apply to save.')
        except Exception as exc:
            self._loaded_fields = None
            self.fence_status.set_text(f'Unable to load Fence: {exc}')

    def _apply_fence(self, *_):
        folder = self._selected_folder()
        if folder is None or self._loaded_fields is None:
            self.fence_status.set_text('No active Fence selected.')
            return
        current = {'title': self.fence_title.get_text(),
                   'geometry.width': self.fence_width.get_value_as_int(),
                   'geometry.height': self.fence_height.get_value_as_int(),
                   'geometryLocked': self.lock_geometry.get_active(),
                   'inheritGlobals': self.inherit_globals.get_active(),
                   'inheritAdvancedGlobals': self.inherit_advanced.get_active()}
        current['view.mode']=('icons','tabs','rolodex')[max(0,self.view_mode.get_active())]
        if not current['inheritAdvancedGlobals']:
            current.update(self._bar_get(self.header_controls))
            current.update(self._bar_get(self.section_controls))
        if not current['inheritGlobals']:
            current.update(self._style_get(self.fence_controls))
        changes = {key: value for key, value in current.items()
                   if value != self._loaded_fields.get(key)}
        if not changes:
            self.fence_status.set_text('No changes to save.')
            return
        try:
            self.config.update_fence_settings(folder, changes)
            self._on_fence_changed()
            # A title edited in Per Fence is also used by Manage Fences.
            # Keep both selectors synchronized without requiring Refresh.
            self._reload_managed_fences()
            self.fence_status.set_text(f'{folder.name}: changes saved.')
        except Exception as exc:
            self._error('Unable to save Fence settings', exc)
            self.fence_status.set_text('Save failed; settings were not changed.')


def _show_icon_rename(config, path):
    window=Gtk.Dialog(title='Rename',flags=Gtk.DialogFlags.MODAL)
    window.set_default_size(400,-1)
    window.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Rename',Gtk.ResponseType.OK)
    box=window.get_content_area()
    box.set_spacing(10)
    box.set_border_width(14)
    label=Gtk.Label(label='New name for '+path.name)
    label.set_xalign(0)
    box.pack_start(label,False,False,0)
    entry=Gtk.Entry(text=path.name)
    entry.set_activates_default(True)
    box.pack_start(entry,False,False,0)
    window.set_default_response(Gtk.ResponseType.OK)
    window.show_all()
    while True:
        response=window.run()
        if response!=Gtk.ResponseType.OK:break
        try:
            config.rename_icon_file(path,entry.get_text())
            break
        except Exception as exc:
            error=Gtk.MessageDialog(transient_for=window,flags=Gtk.DialogFlags.MODAL,
                message_type=Gtk.MessageType.ERROR,buttons=Gtk.ButtonsType.OK,
                text='Unable to rename file')
            error.format_secondary_text(str(exc))
            error.run();error.destroy()
    window.destroy()


def main():
    configure_application_identity()
    config = load_config()
    if len(sys.argv)==3 and sys.argv[1]=='--rename-icon':
        _show_icon_rename(config,Path(sys.argv[2]))
        return
    manage = '--manage-fences' in sys.argv[1:]
    folder_args=[arg for arg in sys.argv[1:] if arg!='--manage-fences']
    selected = Path(folder_args[0]).expanduser() if folder_args else None
    window = SettingsWindow(config, selected)
    if manage:
        window.tabs.set_current_page(window.tabs.page_num(window.manage_page))
        window._reload_managed_fences(selected)
    window.show_all()
    Gtk.main()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('CinnaFences settings:', exc, file=sys.stderr)
        raise SystemExit(1)
