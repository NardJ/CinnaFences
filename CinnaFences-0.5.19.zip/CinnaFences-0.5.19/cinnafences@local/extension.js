/* CinnaFences v0.5.19 - a cautious, opt-in Cinnamon extension.
 * Copyright (c) 2026. MIT license, see LICENSE.
 * One manager, one actor per folder, no external daemon or polling.
 * Cinnamon's desklet layer is used directly, not the always-on-top chrome.
 */
const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const Cinnamon = imports.gi.Cinnamon;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Pango = imports.gi.Pango;
const Meta = imports.gi.Meta;
const ByteArray = imports.byteArray;
const Main = imports.ui.main;
const PopupMenu = imports.ui.popupMenu;

// Open the same on-demand GTK window that Cinnamon Extensions provides via
// its Configure button. No extra process exists while the dialog is closed.
function openCinnaFencesSettings(folder=null, manage=false) {
    const script = pathJoin(pathJoin(pathJoin(pathJoin(GLib.get_user_data_dir(),
        'cinnamon'), 'extensions'), 'cinnafences@local'), 'settings.py');
    try {
        if (!fileExists(script)) throw new Error('Settings file is missing');
        const cmd = ['/usr/bin/python3', script];
        if (manage) cmd.push('--manage-fences');
        if (folder) cmd.push(folder);
        Gio.Subprocess.new(cmd, Gio.SubprocessFlags.NONE);
    } catch (e) {
        safeError('Open settings', e);
        Main.notify('CinnaFences', 'Settings could not be opened.');
    }
}
const CONFIG_NAME = '.cinnafence.json';
const GLOBAL_NAME = 'defaults.json';
const UNASSIGNED_NAME = 'unassigned.json';
const GLOBAL_DIR = pathJoin(GLib.get_user_config_dir(), 'cinnafences');
const DESKTOP_MODE_LAYOUT = 'false::false';
// Opt-in; state is written by the CLI before Nemo icons are hidden.
// No extra process, no file watcher, no periodic polling.
function syncNemoDesktopMode(activate) {
    const statePath = pathJoin(pathJoin(GLib.get_user_config_dir(), 'cinnafences'), 'desktop-mode.json');
    if (!fileExists(statePath)) return;
    try {
        const [ok, bytes] = Gio.File.new_for_path(statePath).load_contents(null);
        if (!ok) return;
        const state = JSON.parse(ByteArray.toString(bytes));
        if (!state || state.enabled !== true || typeof state.originalLayout !== 'string' ||
            !state.originalLayout.includes('::')) return;
        const settings = new Gio.Settings({schema_id: 'org.nemo.desktop'});
        const current = settings.get_string('desktop-layout');
        if (activate) {
            if (current === state.originalLayout && current !== DESKTOP_MODE_LAYOUT)
                settings.set_string('desktop-layout', DESKTOP_MODE_LAYOUT);
        } else {
            // Never override user adjustments made while the extension ran.
            if (current === DESKTOP_MODE_LAYOUT && state.originalLayout !== DESKTOP_MODE_LAYOUT)
                settings.set_string('desktop-layout', state.originalLayout);
        }
    } catch (e) { safeError('Nemo-desktopmodus', e); }
}
const HEADER_H = 32; // legacy default; runtime height comes from each Fence header
const SECTION_LIMIT = 48;
const PAD = 10;
const EDGE = 12;
const SCROLLBAR_W = 12; // reserved space, so grid cells never overlap the scrollbar
const MIN_W = 172;
const MIN_H = 108;
const WATCH_DELAY = 220;
const DRAG_WATCH_MS = 150; // only runs during an active pointer action
const MAX_FILES = 350; // guard against accidental huge folder renders

function clamp(x, min, max) { return Math.max(min, Math.min(max, x)); }
function finite(n, fallback, min, max) {
    return typeof n === 'number' && Number.isFinite(n) ? clamp(n, min, max) : fallback;
}
function fileExists(path) { return GLib.file_test(path, GLib.FileTest.EXISTS); }
function pathJoin(a, b) { return GLib.build_filenamev([a, b]); }
function safeError(message, error) {
    global.logError(new Error('[CinnaFences] ' + message + ': ' + String(error)));
}
function deepCopy(x) { return JSON.parse(JSON.stringify(x)); }

function normalizeConfig(input, folder, defaults=null) {
    if (!input || typeof input !== 'object' || Array.isArray(input))
        throw new Error('Configuratie moet een JSON-object zijn');
    if (input.version !== undefined && input.version !== 1)
        throw new Error('Onbekende configuratieversie: ' + input.version);
    const g = (input.geometry && typeof input.geometry === 'object') ? input.geometry : {};
    // Existing Fences retain their own styling unless explicitly opted in.
    // Legacy inheritance continues to cover appearance/icons. The new
    // Header/Sections inheritance is opt-in for existing configurations.
    // View mode and active section are ALWAYS per Fence, never inherited.
    const inherit = input.inheritGlobals === true;
    const inheritAdvanced = input.inheritAdvancedGlobals === true;
    const di = defaults && defaults.icons && typeof defaults.icons === 'object' ? defaults.icons : {};
    const da = defaults && defaults.appearance && typeof defaults.appearance === 'object' ? defaults.appearance : {};
    const i = Object.assign({}, input.icons && typeof input.icons === 'object' ? input.icons : {},
        inherit ? di : {});
    const a = Object.assign({}, input.appearance && typeof input.appearance === 'object' ? input.appearance : {},
        inherit ? da : {});
    const p = (i.positions && typeof i.positions === 'object' && !Array.isArray(i.positions)) ? i.positions : {};
    // Per-subfolder grid column counts. Legacy 0.5.6 positions remain readable,
    // but an unopened section has no committed manual grid and starts compact.
    const sectionColumns = {};
    const savedSectionCols = input.icons && input.icons.sectionLayoutColumns;
    if (savedSectionCols && typeof savedSectionCols === 'object' &&
        !Array.isArray(savedSectionCols)) {
        for (const [key, value] of Object.entries(savedSectionCols)) {
            if ((key==='/' || (key.length<=255 && key.length>0 &&
                key!=='.' && key!=='..' && !key.includes('/') && !key.includes('\\'))) &&
                Number.isInteger(value) && value>=1 && value<=50)
                sectionColumns[key]=value;
        }
    }
    // One-step undo for Sort / Compact. This is layout state, not presentation:
    // never inherited from General defaults. Older configs need no migration.
    const undo = input.icons && input.icons.undoArrangement;
    const validUndo = undo && typeof undo === 'object' && !Array.isArray(undo) &&
        undo.positions && typeof undo.positions === 'object' && !Array.isArray(undo.positions) &&
        Number.isInteger(undo.layoutColumns) && undo.layoutColumns >= 1 && undo.layoutColumns <= 50 &&
        Object.keys(undo.positions).length <= MAX_FILES &&
        Object.values(undo.positions).every(pos => Array.isArray(pos) && pos.length === 2 &&
            pos.every(v => Number.isInteger(v) && v >= 0 && v <= 9999)) &&
        (undo.sectionLayoutColumns === undefined || (undo.sectionLayoutColumns &&
            typeof undo.sectionLayoutColumns === 'object' &&
            !Array.isArray(undo.sectionLayoutColumns) &&
            Object.values(undo.sectionLayoutColumns).every(v =>
                Number.isInteger(v) && v>=1 && v<=50)));
    const name = GLib.path_get_basename(folder);
    const c = deepCopy(input);
    c.version = 1;
    c.enabled = input.enabled !== false && input.nofence !== true;
    c.title = (typeof input.title === 'string' && input.title.trim()) ? input.title : name;
    c.geometry = {
        x: finite(g.x, 50, -20000, 20000), y: finite(g.y, 80, -20000, 20000),
        width: finite(g.width, 350, MIN_W, 2400), height: finite(g.height, 270, MIN_H, 1600)
    };
    c.icons = {
        size: Math.round(finite(i.size, 48, 20, 96)),
        gridWidth: Math.round(finite(i.gridWidth, 86, 48, 150)),
        gridHeight: Math.round(finite(i.gridHeight, 88, 52, 170)),
        positions: p,
        sectionLayoutColumns: sectionColumns,
        undoArrangement: validUndo ? deepCopy(undo) : null,
        showLabels: i.showLabels !== false,
        labelFont: typeof i.labelFont === 'string' && /^[\p{L}\p{N} .,_+-]{1,80}$/u.test(i.labelFont) ? i.labelFont : 'Sans',
        labelFontSize: Math.round(finite(i.labelFontSize, 9, 6, 24)),
        layoutColumns: Math.round(finite(i.layoutColumns, 0, 0, 50))
    };
    c.icons.gridWidth = Math.max(c.icons.gridWidth, c.icons.size + 8);
    c.icons.gridHeight = Math.max(c.icons.gridHeight, c.icons.size + 21);
    c.appearance = {
        background: /^#[0-9a-f]{6}$/i.test(a.background || '') ? a.background : '#202733',
        backgroundOpacity: finite(a.backgroundOpacity, 0.27, 0, 1),
        hoverOpacity: finite(a.hoverOpacity, 0.75, 0, 1),
        iconOpacity: finite(a.iconOpacity, 0.45, 0.1, 1),
        labelOpacity: finite(a.labelOpacity, 0.60, 0.1, 1),
        labelColor: /^#[0-9a-f]{6}$/i.test(a.labelColor || '') ? a.labelColor : '#ffffff',
        hoverEnabled: a.hoverEnabled !== false, // opt-out fallback: always fully visible
        radius: finite(a.radius, 12, 0, 28),
        borderEnabled: a.borderEnabled !== false,
        borderColor: /^#[0-9a-f]{6}$/i.test(a.borderColor || '') ? a.borderColor : '#f0f5ff',
        borderWidth: Math.round(finite(a.borderWidth, 1, 1, 8)),
        borderOpacity: finite(a.borderOpacity, 0.16, 0, 1)
    };
    // Folder-driven views never move files. Relative names identify entries in
    // subdirectories; legacy plain names still identify root-level icons.
    const dv = defaults && defaults.view && typeof defaults.view === 'object' ? defaults.view : {};
    const v = Object.assign({}, input.view && typeof input.view === 'object' ? input.view : {},
        inheritAdvanced ? Object.fromEntries(Object.entries(dv).filter(([k]) =>
            k==='tabsInHeader' || k==='autoFitHeight' || k==='autoFitMaxHeight')) : {});
    c.view = {
        mode: ['icons','tabs','rolodex'].includes(v.mode) ? v.mode : 'icons',
        tabsInHeader: v.tabsInHeader === true,
        autoFitHeight: v.autoFitHeight === true,
        autoFitMaxHeight: Math.round(finite(v.autoFitMaxHeight, 720, 160, 1600)),
        active: typeof v.active === 'string' && v.active.length <= 256 ? v.active : null
    };
    const dh = defaults && defaults.header && typeof defaults.header === 'object' ? defaults.header : {};
    const dz = defaults && defaults.sections && typeof defaults.sections === 'object' ? defaults.sections : {};
    const h = Object.assign({}, input.header && typeof input.header === 'object' ? input.header : {},
        inheritAdvanced ? dh : {});
    const z = Object.assign({}, input.sections && typeof input.sections === 'object' ? input.sections : {},
        inheritAdvanced ? dz : {});
    const hex = (value,fallback) => /^#[0-9a-f]{6}$/i.test(value || '') ? value : fallback;
    c.header = {
        show: h.show !== false, background: hex(h.background,'#0c1017'),
        opacity: finite(h.opacity,0.20,0,1), textColor:hex(h.textColor,'#ffffff'),
        hoverBackground:hex(h.hoverBackground,hex(h.background,'#0c1017')),
        hoverOpacity:finite(h.hoverOpacity,finite(h.opacity,0.20,0,1),0,1),
        hoverTextColor:hex(h.hoverTextColor,hex(h.textColor,'#ffffff')),
        fontFamily:typeof h.fontFamily === 'string' && /^[\p{L}\p{N} .,_+-]{1,80}$/u.test(h.fontFamily) ? h.fontFamily : 'Sans',
        fontSize:Math.round(finite(h.fontSize,11,7,22)),
        height:Math.round(finite(h.height,32,24,64)),
        showCollapseButton:h.showCollapseButton !== false
    };
    c.sections = {
        background:hex(z.background,'#344052'),
        opacity:finite(z.opacity,0.80,0,1),
        hoverBackground:hex(z.hoverBackground,hex(z.background,'#344052')),
        hoverOpacity:finite(z.hoverOpacity,finite(z.opacity,0.80,0,1),0,1),
        textColor:hex(z.textColor,'#ffffff'),
        hoverTextColor:hex(z.hoverTextColor,hex(z.textColor,'#ffffff')),
        fontFamily:typeof z.fontFamily === 'string' && /^[\p{L}\p{N} .,_+-]{1,80}$/u.test(z.fontFamily) ? z.fontFamily : 'Sans',
        alignment:['left','center','right'].includes(z.alignment) ? z.alignment : 'center',
        showCollapseButton:z.showCollapseButton !== false,
        fontSize:Math.round(finite(z.fontSize,10,7,20)),
        height:Math.round(finite(z.height,30,24,55))
    };
    c.inheritGlobals = inherit;
    c.inheritAdvancedGlobals = inheritAdvanced;
    c.collapsed = input.collapsed === true;
    c.hidden = input.hidden === true;
    c.geometryLocked = input.geometryLocked === true;
    // Off by default; logs only state transitions for diagnosing live hover issues.
    c.debugHover = input.debugHover === true;
    return c;
}
function readGlobalSettings() {
    const path = pathJoin(GLOBAL_DIR, GLOBAL_NAME);
    if (!fileExists(path)) return {};
    try {
        const [ok, data] = Gio.File.new_for_path(path).load_contents(null);
        if (ok) {
            const obj = JSON.parse(ByteArray.toString(data));
            return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {};
        }
    } catch (e) { safeError('General defaults', e); }
    return {};
}
// Desktop / Unassigned is a virtual Fence. Its configuration belongs in
// ~/.config/cinnafences, never in ~/Desktop (which must remain a regular folder).
function isUnassignedFolder(folder) {
    return typeof GLib.get_home_dir === 'function' &&
        folder === pathJoin(GLib.get_home_dir(), 'Desktop');
}
function configPathFor(folder) {
    return isUnassignedFolder(folder) ? pathJoin(GLOBAL_DIR, UNASSIGNED_NAME) :
        pathJoin(folder, CONFIG_NAME);
}
function unassignedNames(desktop, names) {
    // All folders with a Fence config are excluded, even hidden/removed ones.
    // Never follow symbolic links when identifying managed directories.
    return names.filter(name => {
        if (name === CONFIG_NAME || name.endsWith('.tmp')) return false;
        const folder=pathJoin(desktop,name);
        try {
            // NOFOLLOW_SYMLINKS: a Desktop shortcut to a managed directory
            // is still the user's loose shortcut, not another Fence folder.
            if (Gio.File.new_for_path(folder).query_file_type(
                Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null) !== Gio.FileType.DIRECTORY)
                return true;
        } catch (_) { return true; }
        return !fileExists(pathJoin(folder,CONFIG_NAME));
    });
}
function readUnassignedConfig(globals) {
    const desktop=pathJoin(GLib.get_home_dir(),'Desktop');
    const existing=readConfig(desktop,globals);
    const seed={version:1,title:'Desktop / Unassigned',enabled:true,
        geometry:{x:60,y:410,width:350,height:270},inheritGlobals:true,
        inheritAdvancedGlobals:true,view:{mode:'icons'}};
    const config=existing || normalizeConfig(seed,desktop,globals);
    // This is a flat Desktop view, not another folder-driven Rolodex.
    config.view.mode='icons';
    return config;
}
function readConfig(folder, defaults=null) {
    const path = configPathFor(folder);
    if (!fileExists(path)) return null;
    try {
        const [ok, data] = Gio.File.new_for_path(path).load_contents(null);
        if (!ok) throw new Error('Lezen mislukt');
        const cfg = normalizeConfig(JSON.parse(ByteArray.toString(data)), folder, defaults);
        return cfg.enabled ? cfg : null;
    } catch (e) {
        safeError('Ongeldige ' + path + ' (map blijft gewone map)', e);
        return null;
    }
}
function writeConfig(folder, cfg, persistGeometryLock=false) {
    const target = Gio.File.new_for_path(configPathFor(folder));
    // Unique temporary file: two writers never share a fixed .tmp filename.
    const temp = Gio.File.new_for_path(configPathFor(folder) + '.' + GLib.uuid_string_random() + '.tmp');
    // Pointer actions only change layout/positions/collapse. Read the current
    // JSON first, preserving any per-Fence style that has been temporarily
    // overlaid by General defaults (and concurrent GTK setting edits).
    // Never persist inherited values back into a Fence's local appearance.
    let output = cfg;
    try {
        // Only the virtual Desktop Fence may be created without an existing
        // per-Fence file. Ordinary Fences still fail closed if their original
        // configuration has been removed or cannot be read.
        const firstVirtualSave = isUnassignedFolder(folder) && !fileExists(configPathFor(folder));
        const [ok, bytes] = firstVirtualSave ? [false,null] : target.load_contents(null);
        if (ok) {
            const existing = JSON.parse(ByteArray.toString(bytes));
            if (existing && typeof existing === 'object' && !Array.isArray(existing)) {
                existing.geometry = deepCopy(cfg.geometry);
                existing.collapsed = cfg.collapsed;
                // Only the Lock command is allowed to persist the lock flag.
                // Normal icon/geometry saves must preserve edits from GTK.
                if (persistGeometryLock) existing.geometryLocked = cfg.geometryLocked;
                if (!existing.icons || typeof existing.icons !== 'object' || Array.isArray(existing.icons))
                    existing.icons = {};
                existing.icons.positions = deepCopy(cfg.icons.positions);
                existing.icons.layoutColumns = cfg.icons.layoutColumns;
                existing.icons.sectionLayoutColumns = deepCopy(cfg.icons.sectionLayoutColumns || {});
                // Undo travels with an arrangement change, not with General
                // appearance overrides; preserve it across extension reloads.
                if (cfg.icons.undoArrangement)
                    existing.icons.undoArrangement = deepCopy(cfg.icons.undoArrangement);
                else
                    delete existing.icons.undoArrangement;
                output = existing;
            }
        }
    } catch (e) {
        // Corrupt/unreadable config: refuse to replace it with stale state.
        throw new Error('Cannot safely merge Fence state: ' + String(e));
    }
    GLib.file_set_contents(temp.get_path(), JSON.stringify(output, null, 2) + '\n');
    try {
        temp.move(target, Gio.FileCopyFlags.OVERWRITE, null, null);
    } catch (e) {
        try { temp.delete(null); } catch (_) {}
        throw e;
    }
}
function writeFenceView(folder, view) {
    const target=Gio.File.new_for_path(configPathFor(folder));
    const temp=Gio.File.new_for_path(configPathFor(folder)+'.'+GLib.uuid_string_random()+'.tmp');
    const [ok,bytes]=target.load_contents(null);
    if (!ok) throw new Error('Fence view could not be read');
    const data=JSON.parse(ByteArray.toString(bytes));
    if (!data || typeof data !== 'object' || Array.isArray(data))
        throw new Error('Invalid Fence configuration');
    data.view=Object.assign({},data.view && typeof data.view==='object' ? data.view : {},
        {mode:view.mode,active:view.active});
    GLib.file_set_contents(temp.get_path(),JSON.stringify(data,null,2)+'\n');
    try {temp.move(target,Gio.FileCopyFlags.OVERWRITE,null,null);}
    catch(e) {try {temp.delete(null);} catch(_) {} throw e;}
}
// Mint and other distributions normally install root-owned application launchers
// as non-executable .desktop files in /usr/share/applications. Only a symlink
// explicitly targeting a regular *root-owned* file in a trusted system app
// directory can bypass the existing executable-file check. Other downloaded
// or user-authored .desktop shortcuts retain the existing trust restriction.
function isTrustedSystemLauncherShortcut(path) {
    try {
        const link = Gio.File.new_for_path(path).query_info(
            'standard::type,standard::symlink-target',
            Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, null);
        if (link.get_file_type() !== Gio.FileType.SYMBOLIC_LINK) return false;
        const target = link.get_symlink_target();
        if (!target || !target.endsWith('.desktop') ||
            !['/usr/share/applications/', '/usr/local/share/applications/']
                .some(prefix => target.startsWith(prefix)) ||
            target.includes('/../') || target.includes('/./')) return false;
        const info = Gio.File.new_for_path(target).query_info(
            'standard::type,unix::uid', Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, null);
        return info.get_file_type() === Gio.FileType.REGULAR &&
            info.get_attribute_uint32('unix::uid') === 0;
    } catch (e) { return false; }
}

function directoryNames(folder, subdirectoriesOnly) {
    const names = [];
    let enumerator = null;
    try {
        enumerator = Gio.File.new_for_path(folder).enumerate_children(
            'standard::name,standard::type', Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, null);
        let info;
        while ((info = enumerator.next_file(null))) {
            const name = info.get_name();
            if (name.startsWith('.')) continue;
            if (subdirectoriesOnly && info.get_file_type() !== Gio.FileType.DIRECTORY) continue;
            names.push(name);
        }
    } catch (e) { safeError('Map lezen: ' + folder, e); }
    finally { if (enumerator) { try { enumerator.close(null); } catch (_) {} } }
    return names.sort((a, b) => a.localeCompare(b, 'nl', {sensitivity: 'base'}));
}
// Watch the direct real subfolders displayed by Tabs/Rolodex. A monitor on
// the Fence root does NOT report changes made *inside* its children.
// Never traverse links, nested folders or more folders than the UI can show.
function watchedSectionPaths(folder, mode, directNames) {
    if (mode!=='tabs' && mode!=='rolodex') return [];
    return directNames.slice(0, SECTION_LIMIT)
        .filter(name=>typeof name==='string' && !!name &&
            name!=='.' && name!=='..' && !name.startsWith('.') &&
            !name.includes('/') && !name.includes('\\'))
        .map(name=>pathJoin(folder,name));
}
// Derived height is never written into geometry.height: disabling auto-fit
// restores the exact manual height, including after an extension restart.
function rolodexFitHeight(headerHeight, navBottom, iconsBottom, limit, available) {
    const content = Math.max(navBottom, iconsBottom, 0) + 2;
    const wanted = Math.ceil(headerHeight + content + 1);
    return Math.max(24, Math.min(wanted, limit, available));
}
// Round exposed Rolodex bars where they actually meet the Fence outline.
// Fixed-height Fences do not round a section floating above their bottom edge.
function sectionCornerShape(mode, headerShown, index, y, height, viewportHeight,
                            scroll, radius) {
    if (mode !== 'rolodex' || radius <= 0) return 'border-radius:0px;';
    const r=Math.max(0,Math.round(radius)-1);
    const atTop=!headerShown && index===0 && scroll===0 && y===0;
    const atBottom=y+height >= viewportHeight-4 && y+height<=viewportHeight+4;
    if (atTop && atBottom) return `border-radius:${r}px;`;
    if (atTop) return `border-radius:${r}px ${r}px 0px 0px;`;
    if (atBottom) return `border-radius:0px 0px ${r}px ${r}px;`;
    return 'border-radius:0px;';
}
function columns(width, cellW) { return Math.max(1, Math.floor((width - PAD * 2 - SCROLLBAR_W) / cellW)); }
// Scroll in pixels, not whole rows: even a partly visible bottom row must
// be paintable and reachable. Zero for empty or fully visible content.
function maxScrollPixels(maxRow, contentHeight, gridHeight) {
    if (maxRow < 0) return 0;
    return Math.max(0, (maxRow + 1) * gridHeight - Math.max(0,contentHeight));
}
function gridRowAtPointer(stageY, fenceY, scrollPixels, gridHeight) {
    return Math.max(0, Math.floor((stageY - fenceY - HEADER_H - PAD + scrollPixels) / gridHeight));
}
const CURSOR_FOR_EDGE = {
    n: 'RESIZE_TOP', s: 'RESIZE_BOTTOM', e: 'RESIZE_RIGHT', w: 'RESIZE_LEFT',
    ne: 'RESIZE_TOP_RIGHT', nw: 'RESIZE_TOP_LEFT',
    se: 'RESIZE_BOTTOM_RIGHT', sw: 'RESIZE_BOTTOM_LEFT'
};
function canonicalOrder(files, positions, fallbackCols) {
    const used = new Set();
    const out = [];
    const later = [];
    files.forEach(name => {
        const p = positions[name];
        if (Array.isArray(p) && p.length === 2 && Number.isInteger(p[0]) &&
            Number.isInteger(p[1]) && p[0] >= 0 && p[1] >= 0 && p[0] < 200 && p[1] < 10000 &&
            !used.has(p[1] * 1000 + p[0])) {
            used.add(p[1] * 1000 + p[0]);
            out.push({name, col:p[0], row:p[1]});
        } else later.push(name);
    });
    // New icons are placed in first free canonical grid slot, never reshuffling old icons.
    later.forEach(name => {
        let index = 0;
        while (used.has(Math.floor(index / fallbackCols) * 1000 + index % fallbackCols)) index++;
        const col = index % fallbackCols, row = Math.floor(index / fallbackCols);
        used.add(row * 1000 + col);
        out.push({name, col, row});
    });
    return out.sort((a,b) => a.row-b.row || a.col-b.col || a.name.localeCompare(b.name));
}
function fromHex(hex) {
    const v = hex.replace('#','');
    return [parseInt(v.slice(0,2),16), parseInt(v.slice(2,4),16), parseInt(v.slice(4,6),16)];
}
function rgba(hex, alpha) {
    const [r,g,b] = fromHex(hex);
    return `rgba(${r},${g},${b},${Math.round(clamp(alpha,0,1)*1000)/1000})`;
}
// Keyboard bindings are opt-in: avoid stealing Super+F from another app.
const HOTKEY_NAME='cinnafences@local-toggle-all';
const HOTKEY_DEFAULTS=Object.freeze({enabled:false, toggle:'<Super>f'});
function normalizeHotkeySettings(value) {
    const v=value && typeof value==='object' && !Array.isArray(value) ? value : {};
    const accelerator=typeof v.toggle==='string' ? v.toggle : HOTKEY_DEFAULTS.toggle;
    // Require a modifier and one non-modifier key: never grab plain typing.
    const legal=/^(?:(?:<Super>|<Control>|<Alt>|<Shift>)){1,4}(?:[a-zA-Z0-9]|F(?:[1-9]|1[0-2]))$/;
    return {enabled:v.enabled===true, toggle:legal.test(accelerator) ? accelerator : HOTKEY_DEFAULTS.toggle};
}
// Keep a Fence's original on-disk monitor position even if its monitor is
// temporarily disconnected. Move the actor only, not its JSON geometry.
function recoverOffscreenFence(rect, areas) {
    if (!Array.isArray(areas) || !areas.length) return null;
    // The titlebar must remain reachable; don't relocate merely because the
    // bottom or right part of a Fence extends outside the monitor.
    const accessible=areas.some(a=>
        Math.min(rect.x+rect.width,a.x+a.width)-Math.max(rect.x,a.x)>=60 &&
        Math.min(rect.y+HEADER_H,a.y+a.height)-Math.max(rect.y,a.y)>=16);
    if (accessible) return null;
    const mx=rect.x+rect.width/2, my=rect.y+HEADER_H/2;
    const distance=a=>{
        const nx=clamp(mx,a.x,a.x+a.width), ny=clamp(my,a.y,a.y+a.height);
        return (mx-nx)*(mx-nx)+(my-ny)*(my-ny);
    };
    const area=areas.slice().sort((a,b)=>distance(a)-distance(b))[0];
    return {
        x:Math.round(clamp(rect.x,area.x,Math.max(area.x,area.x+area.width-Math.min(rect.width,area.width)))),
        y:Math.round(clamp(rect.y,area.y,Math.max(area.y,area.y+area.height-HEADER_H)))
    };
}
// Cinnamon 6.6.9 adds tracked DESKLET actors wholesale to the X11 stage
// input region, even if a normal application window is stacked above them.
// Newer Cinnamon versions subtract windows inside layout.js itself. Until then,
// only register the visible pieces of each Fence. No compositor monkey patch.
// General-only desktop snapping. Disabled on upgrade, preserving all existing
// Fence positions until enabled explicitly in the Settings window.
const SNAP_DEFAULTS = Object.freeze({enabled:false, fences:true, screen:true,
    grid:false, distance:14, gridX:20, gridY:20});
function normalizeSnapSettings(value) {
    const v=value && typeof value==='object' && !Array.isArray(value) ? value : {};
    return {
        enabled: v.enabled===true,
        fences: v.fences!==false,
        screen: v.screen!==false,
        grid: v.grid===true,
        distance: Math.round(finite(v.distance,SNAP_DEFAULTS.distance,2,40)),
        gridX: Math.round(finite(v.gridX,SNAP_DEFAULTS.gridX,8,200)),
        gridY: Math.round(finite(v.gridY,SNAP_DEFAULTS.gridY,8,200))
    };
}
function nearbyIntervals(aStart,aEnd,bStart,bEnd,margin) {
    return aEnd+margin>=bStart && bEnd+margin>=aStart;
}
function closestSnap(value,candidates,distance) {
    let best=value, gap=distance+1;
    for (const candidate of candidates) {
        const d=Math.abs(candidate-value);
        if (d<gap && d<=distance) {best=candidate;gap=d;}
    }
    return best;
}
function snapTargets(rect,area,others,options,axis,movingEdge=null) {
    const horizontal=axis==='x';
    const size=horizontal?rect.width:rect.height;
    const acrossStart=horizontal?rect.y:rect.x;
    const acrossEnd=acrossStart+(horizontal?rect.height:rect.width);
    const start=horizontal?area.x:area.y;
    const extent=horizontal?area.width:area.height;
    const result=[];
    if (options.screen) {
        if (movingEdge!=='end') result.push(start);
        if (movingEdge!=='start') result.push(start+extent-(movingEdge?0:size));
    }
    if (options.fences) {
        for (const other of others) {
            const a=horizontal?other.y:other.x;
            const b=a+(horizontal?other.height:other.width);
            if (!nearbyIntervals(acrossStart,acrossEnd,a,b,options.distance)) continue;
            const side=horizontal?other.x:other.y;
            const end=side+(horizontal?other.width:other.height);
            if (movingEdge==='start' || movingEdge==='end') result.push(side,end);
            else result.push(side,end,side-size,end-size);
        }
    }
    return result;
}
function snapMoveRect(rect,area,others,options,altDown=false) {
    const result={...rect};
    if (!options.enabled || altDown) return result;
    const x=snapTargets(rect,area,others,options,'x');
    const y=snapTargets(rect,area,others,options,'y');
    let nx=closestSnap(rect.x,x,options.distance);
    let ny=closestSnap(rect.y,y,options.distance);
    // Edges/Fences win over grid. Grid is anchored to the current monitor's
    // work area (not hardcoded desktop x=0), and snaps at every grid point.
    if (!x.some(v=>Math.abs(v-rect.x)<=options.distance) && options.grid)
        nx=area.x+Math.round((rect.x-area.x)/options.gridX)*options.gridX;
    if (!y.some(v=>Math.abs(v-rect.y)<=options.distance) && options.grid)
        ny=area.y+Math.round((rect.y-area.y)/options.gridY)*options.gridY;
    result.x=clamp(nx,area.x,Math.max(area.x,area.x+area.width-rect.width));
    result.y=clamp(ny,area.y,Math.max(area.y,area.y+area.height-rect.height));
    return result;
}
function snapResizeRect(rect,edge,area,others,options,altDown=false) {
    const result={...rect};
    if (!options.enabled || altDown) return result;
    for (const horizontal of [true,false]) {
        const startSide=horizontal?'w':'n', endSide=horizontal?'e':'s';
        if (!edge.includes(startSide) && !edge.includes(endSide)) continue;
        const isStart=edge.includes(startSide), axis=horizontal?'x':'y';
        const origin=rect[axis], width=rect[horizontal?'width':'height'];
        const raw=isStart?origin:origin+width;
        const min=horizontal?MIN_W:MIN_H,max=horizontal?2400:1600;
        const areaStart=area[axis],areaEnd=areaStart+area[horizontal?'width':'height'];
        const targets=snapTargets(rect,area,others,options,axis,isStart?'start':'end');
        const fixed=isStart?origin+width:origin;
        // Include grid only after closer Fence/screen edges fail.
        let value=closestSnap(raw,targets,options.distance);
        if (!targets.some(v=>Math.abs(v-raw)<=options.distance) && options.grid) {
            const step=horizontal?options.gridX:options.gridY;
            value=areaStart+Math.round((raw-areaStart)/step)*step;
        }
        const newSize=isStart?fixed-value:value-fixed;
        if (value>=areaStart && value<=areaEnd && newSize>=min && newSize<=max) {
            if (isStart) result[axis]=value;
            result[horizontal?'width':'height']=newSize;
        }
    }
    return result;
}
function registerFenceInput(actor) {
    Main.layoutManager.trackChrome(actor, {
        affectsInputRegion: true, affectsStruts: false
    });
}
function unregisterFenceInput(actor) {
    Main.layoutManager.untrackChrome(actor);
}
function subtractInputBox(box, obstruction) {
    const x1 = Math.max(box.x, obstruction.x);
    const y1 = Math.max(box.y, obstruction.y);
    const x2 = Math.min(box.x+box.width, obstruction.x+obstruction.width);
    const y2 = Math.min(box.y+box.height, obstruction.y+obstruction.height);
    if (x1 >= x2 || y1 >= y2) return [box];
    const right=box.x+box.width, bottom=box.y+box.height;
    const parts=[];
    if (box.y < y1) parts.push({x:box.x,y:box.y,width:box.width,height:y1-box.y});
    if (y2 < bottom) parts.push({x:box.x,y:y2,width:box.width,height:bottom-y2});
    if (box.x < x1) parts.push({x:box.x,y:y1,width:x1-box.x,height:y2-y1});
    if (x2 < right) parts.push({x:x2,y:y1,width:right-x2,height:y2-y1});
    return parts;
}
function visibleFenceInputBoxes(box, windows) {
    let pieces = [box];
    for (const window of windows) {
        pieces = pieces.reduce((all,p)=>all.concat(subtractInputBox(p,window)),[]);
        // Lots of narrow stacked windows: disable input for this Fence
        // instead of allocating unlimited actors or intercepting application clicks.
        if (pieces.length > 48) return [];
        if (!pieces.length) break;
    }
    return pieces;
}

// Transfers are real filesystem operations. This function is deliberately
// separate from Cinnamon pointer handling, so validation and rollback can be
// tested without a compositor. No implicit OVERWRITE, ever.
function fileFingerprint(file) {
    const info=file.query_info('standard::type,standard::size,time::modified,time::modified-usec,etag::value',
        Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, null);
    if (info.get_file_type() !== Gio.FileType.REGULAR) return null;
    return [String(info.get_size()), String(info.get_attribute_uint64('time::modified')),
        String(info.get_attribute_uint32('time::modified-usec')),
        String(info.get_attribute_string('etag::value') || '')].join(':');
}
function planFenceTransfer(folder, targetFolder, names, copy, allowLinkMove=false) {
    if (!Array.isArray(names) || !names.length || names.length > MAX_FILES || folder === targetFolder)
        throw new Error('Choose a different Fence and at least one item');
    if (names.length > 50) throw new Error('Select at most 50 items per transfer');
    if (copy && names.length > 16) throw new Error('Copy at most 16 files per transfer');
    const used=new Set(), entries=[];
    let copyBytes=0;
    for (const name of names) {
        if (typeof name !== 'string' || name === '.' || name === '..' ||
            name === CONFIG_NAME || name.startsWith('.') || name.includes('/') || name.includes('\\') ||
            used.has(name)) throw new Error('Invalid or repeated selection');
        used.add(name);
        const src=Gio.File.new_for_path(pathJoin(folder,name));
        const dst=Gio.File.new_for_path(pathJoin(targetFolder,name));
        // query_exists() follows the link and rejects a broken desktop
        // shortcut even though its directory entry exists. Check the entry
        // itself, not the linked target (and never traverse the link).
        const type=src.query_file_type(Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null);
        if (type === Gio.FileType.UNKNOWN) throw new Error('Source no longer exists: '+name);
        if (dst.query_exists(null) || dst.query_file_type(
            Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null)!==Gio.FileType.UNKNOWN)
            throw new Error('Name already exists in destination: '+name);
        if (type === Gio.FileType.SYMBOLIC_LINK && (!allowLinkMove || copy))
            throw new Error(copy ? 'Symbolic links cannot be copied; move the link instead' :
                'Symbolic links cannot be transferred');
        if (type === Gio.FileType.SYMBOLIC_LINK) {
            // A relative link changes its meaning when moved to another folder.
            // Never silently turn a working desktop shortcut into a broken one.
            const info=src.query_info('standard::symlink-target',
                Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null);
            const linkTarget=info.get_symlink_target();
            if (!linkTarget || !linkTarget.startsWith('/'))
                throw new Error('Relative symbolic link cannot be moved safely. Use Nemo to recreate an absolute shortcut.');
        }
        if (type !== Gio.FileType.REGULAR && type !== Gio.FileType.DIRECTORY &&
            type !== Gio.FileType.SYMBOLIC_LINK)
            throw new Error('Unsupported file type: '+name);
        if (copy && type !== Gio.FileType.REGULAR)
            throw new Error('Copying folders is not supported yet: '+name);
        if (copy) {
            // Gio.File.copy() is synchronous; cap the workload to avoid
            // freezing Cinnamon on huge files. Use Nemo for larger copies.
            const info=src.query_info('standard::size',Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null);
            const size=Number(info.get_size());
            if (!Number.isFinite(size) || size > 32*1024*1024 || (copyBytes+=size)>64*1024*1024)
                throw new Error('Copy too large for the desktop. Use Nemo for larger files.');
        }
        entries.push({name,src,dst,isSymlink:type===Gio.FileType.SYMBOLIC_LINK});
    }
    return entries;
}
// A transfer between views is a filesystem transfer between two *actual*
// directories, never an icon-label or virtual-tab operation. A relative icon
// name may have exactly one direct-subfolder prefix ("CAD/file.desktop").
// Reject anything ambiguous before handing files to the proven transfer core.
function planSectionTransfer(sourceRoot, destinationRoot, relativeNames, targetKey, copy) {
    if (!Array.isArray(relativeNames) || !relativeNames.length)
        throw new Error('Select at least one file');
    if (typeof targetKey !== 'string' || !targetKey || targetKey === '.' || targetKey === '..' ||
        targetKey.includes('/') && targetKey !== '/' || targetKey.includes('\\') ||
        targetKey.startsWith('.')) throw new Error('Invalid destination section');
    if (targetKey !== '/') {
        const target=Gio.File.new_for_path(pathJoin(destinationRoot,targetKey));
        if (target.query_file_type(Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null) !== Gio.FileType.DIRECTORY)
            throw new Error('Destination subfolder is missing or is a link');
    }
    const sourceParts=relativeNames.map(relative=>{
        if (typeof relative !== 'string' || relative.startsWith('/') || relative.startsWith('.') ||
            relative.includes('\\')) throw new Error('Invalid source selection');
        const parts=relative.split('/');
        if (parts.length>2 || parts.some(part=>!part || part==='.' || part==='..' || part.startsWith('.')))
            throw new Error('Only direct subfolder items may be transferred');
        return {relative,group:parts.length===1?'/':parts[0],leaf:parts[parts.length-1]};
    });
    const group=sourceParts[0].group;
    if (sourceParts.some(part=>part.group!==group))
        throw new Error('Items must be selected from the same section');
    const sourceDir=group==='/'?sourceRoot:pathJoin(sourceRoot,group);
    if (group!=='/' && Gio.File.new_for_path(sourceDir).query_file_type(
        Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null)!==Gio.FileType.DIRECTORY)
        throw new Error('Source subfolder is missing or is a link');
    const targetDir=targetKey==='/'?destinationRoot:pathJoin(destinationRoot,targetKey);
    // Moving a directory into itself or below itself can create a recursive
    // operation and must not be left to the filesystem implementation.
    for (const part of sourceParts) {
        const src=pathJoin(sourceDir,part.leaf);
        if (targetDir===src || targetDir.startsWith(src+'/'))
            throw new Error('Cannot move a folder into itself');
    }
    // Loose Desktop shortcuts are actual symlink directory entries. Moving one
    // must move only the link, never the external file/directory it points at.
    // Keep the existing no-symlink rule for ordinary Fence-to-Fence transfers.
    const result=planFenceTransfer(sourceDir,targetDir,sourceParts.map(p=>p.leaf),copy,
        isUnassignedFolder(sourceRoot));
    for (let i=0;i<result.length;i++) {
        result[i].sourceKey=sourceParts[i].relative;
        result[i].destKey=targetKey==='/'?sourceParts[i].leaf:targetKey+'/'+sourceParts[i].leaf;
    }
    return result;
}
function executeFenceTransfer(entries, copy) {
    const finished=[];
    let current=null;
    try {
        for (const entry of entries) {
            current=entry;
            if (copy) entry.src.copy(entry.dst,Gio.FileCopyFlags.NONE,null,null);
            else entry.src.move(entry.dst,entry.isSymlink ? Gio.FileCopyFlags.NOFOLLOW_SYMLINKS : Gio.FileCopyFlags.NONE,null,null);
            finished.push(entry);
            if (copy) {
                try { entry.fingerprint=fileFingerprint(entry.dst); }
                catch (_) {entry.fingerprint=null;} // Undo refused, copied data stays intact
            }
            current=null;
        }
        return {ok:true,entries:finished};
    } catch (error) {
        const rollbackErrors=[];
        // A failed copy may leave an incomplete target even though Gio threw.
        // Do not delete it blindly: another process may have raced us. Warn
        // explicitly so both locations can be inspected by the user.
        if (current && !finished.includes(current)) {
            try {
                if (current.dst.query_exists(null))
                    rollbackErrors.push('Check potentially incomplete file: '+current.dst.get_path());
            } catch (_) {rollbackErrors.push('Check destination for '+current.name);}
        }
        for (const entry of finished.slice().reverse()) {
            try {
                if (copy) entry.dst.trash(null); // recoverable, no permanent delete
                else if (!transferEntryExists(entry.src,entry.isSymlink))
                    entry.dst.move(entry.src,entry.isSymlink ? Gio.FileCopyFlags.NOFOLLOW_SYMLINKS : Gio.FileCopyFlags.NONE,null,null);
                else throw new Error('Original path already exists');
            } catch (e) { rollbackErrors.push(entry.name+': '+String(e)); }
        }
        return {ok:false,error,rollbackErrors};
    }
}
function transferEntryExists(file, symlink=false) {
    if (!symlink) return file.query_exists(null);
    // query_exists() follows the link and treats a dangling link as absent.
    // Undo must preserve the *link itself*, not attempt to overwrite its path.
    return file.query_file_type(Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,null) !==
        Gio.FileType.UNKNOWN;
}
function undoFenceTransfer(record) {
    // For copies Undo moves our newly created files to Trash; check they
    // haven't been edited/replaced since copying before any action.
    for (const entry of record.entries) {
        if (!transferEntryExists(entry.dst,entry.isSymlink)) throw new Error('Destination disappeared: '+entry.name);
        if (record.copy) {
            if (!entry.fingerprint || fileFingerprint(entry.dst) !== entry.fingerprint)
                throw new Error('Copy changed since creation: '+entry.name);
        } else if (transferEntryExists(entry.src,entry.isSymlink))
            throw new Error('Original location occupied: '+entry.name);
    }
    const undone=[];
    try {
        for (const entry of record.entries.slice().reverse()) {
            if (record.copy) entry.dst.trash(null);
            else entry.dst.move(entry.src,entry.isSymlink ? Gio.FileCopyFlags.NOFOLLOW_SYMLINKS : Gio.FileCopyFlags.NONE,null,null);
            undone.push(entry);
        }
        return {ok:true};
    } catch (error) {
        // Moving items back can be reversed safely; moving copied files to
        // Trash cannot, but those files are recoverable from the Trash UI.
        const rollbackErrors=[];
        if (!record.copy) for (const entry of undone.slice().reverse()) {
            try { entry.src.move(entry.dst,entry.isSymlink ? Gio.FileCopyFlags.NOFOLLOW_SYMLINKS : Gio.FileCopyFlags.NONE,null,null); }
            catch (e) {rollbackErrors.push(entry.name+': '+String(e));}
        }
        return {ok:false,error,rollbackErrors,partialTrash:record.copy && undone.length>0};
    }
}

class Fence {
    constructor(manager, folder, config) {
        this.manager = manager;
        this.folder = folder;
        this.isUnassigned = isUnassignedFolder(folder);
        this.config = config;
        this.items = [];
        this._navButtons=[];
        this._navStyleSignature=null;
        this._sections=[];
        this._activeSection=null;
        this._gridOriginY=0;
        this._contentLength=0;
        this._autoHeightPixels=null;
        this.cells = new Map();
        this.hovered = false;
        this.scroll = 0;
        this._dragEventId = 0;
        this._dragDevice = null;
        this._modalActor = null;
        this._modalActive = false;
        this._dragSafetyTimer = 0;
        this._dragWatchId = 0;
        this._hoverRecoveryId = 0;
        this._missingReleaseChecks = 0;
        this._cursorName = null;
        this._drag = null;
        this._maxScroll = 0; // pixels
        this.selectedItem = null;
        this._selectionAnchor = null;
        this._disposed = false;
        this._inputPieces = [];
        this._inputRegionKey = '';
        this._showingMenu = false;
        this._itemContext = false;
        this._contextPending = null;
        this._contextOpenIdle = 0;
        this.actor = new St.Widget({
            reactive: true, track_hover: true, layout_manager: new Clutter.FixedLayout(),
            style_class: 'cinnafence-root'
        });
        this.actor.set_position(config.geometry.x, config.geometry.y);
        this.actor.set_size(config.geometry.width, config.geometry.height);
        this.background = new St.Widget({reactive: false});
        this.actor.add_child(this.background);
        this.header = new St.Widget({
            reactive: true, track_hover: true, layout_manager: new Clutter.FixedLayout()
        });
        this.actor.add_child(this.header);
        this.title = new St.Label({style_class:'cinnafence-header-label', text:config.title});
        this.header.add_child(this.title);
        this.arrowIcon = new St.Icon({icon_name:'pan-down-symbolic', icon_size:14});
        this.arrow = new St.Button({reactive:true, track_hover:true, can_focus:true,
            style_class:'cinnafence-collapse-button', child:this.arrowIcon});
        this.arrow.connect('clicked', () => this.toggleCollapsed());
        this.header.add_child(this.arrow);
        this.content = new St.Widget({
            reactive:true, track_hover:true, layout_manager:new Clutter.FixedLayout()
        });
        this.content.set_clip_to_allocation(true);
        this.actor.add_child(this.content);
        this.scrollTrack = new St.Widget({reactive:true, track_hover:true,
            style_class:'cinnafence-scroll-track', layout_manager:new Clutter.FixedLayout()});
        this.scrollThumb = new St.Widget({reactive:false, style_class:'cinnafence-scroll-thumb'});
        this.scrollTrack.add_child(this.scrollThumb);
        this.scrollTrack.connect('button-press-event', (_a,e) => this._scrollTrackClick(e));
        this.scrollTrack.connect('scroll-event', (_a,e) => this._scroll(e));
        this.actor.add_child(this.scrollTrack);
        // Mouse crossings can target child actors or the desktop surface.
        // Read stage coordinates only: a source-based / stage-pick-based test is
        // unstable across child transitions and input grabs under Cinnamon/X11.
        // Geometry and all stage/crossing events use the SAME single predicate.
        const crossing = (_actor, event) => {
            if (!this._drag) {
                const [x, y] = global.get_pointer();
                this._syncHoverFromPointer(x, y, 'crossing');
            }
            return Clutter.EVENT_PROPAGATE;
        };
        this.actor.connect('enter-event', crossing);
        this.actor.connect('leave-event', crossing);
        // Capture border presses before icons/header consume them.
        this.actor.connect('captured-event', (_a,e) => {
            const result=this._contextCapture(e);
            return result===Clutter.EVENT_STOP ? result : this._boundaryCapture(e);
        });
        this.actor.connect('button-press-event', (_a,e) => this._edgeDown(e));
        this.actor.connect('motion-event', (_a,e) => this._edgeHover(e));
        this.actor.connect('scroll-event', (_a,e) => this._scroll(e));
        this.header.connect('button-press-event', (_a,e) => this._headerDown(e));
        this.header.connect('motion-event', (_a,e) => this._edgeHover(e));
        this.content.connect('motion-event', (_a,e) => this._edgeHover(e));
        // Handle on content too; events from St.Icon or St.Label sometimes stop at
        // the nearest scroll-aware actor, depending on Cinnamon version.
        this.content.connect('scroll-event', (_a,e) => this._scroll(e));
        this.content.connect('button-press-event', (_a,e) => {
            if (e.get_button() === 3) return this._contextDown(e);
            if (e.get_source() === this.content && e.get_button() === 1)
                this._clearItemStates();
            return Clutter.EVENT_PROPAGATE;
        });
        this._createMenu();
        this._renderColumns = columns(config.geometry.width, config.icons.gridWidth);
        // Keep the rendered Fence in the DESKLET layer, underneath windows.
        // Do not track its entire rectangle: Cinnamon 6.6.9 would steal clicks
        // from windows drawn above the Fence. Track only uncovered fragments.
        global.desklet_container.add_child(this.actor);
        this._allocationChangedId = this.actor.connect('notify::allocation',
            () => this.manager.queueInputRegions());
        try {
            this.rebuild();
            this.manager.queueInputRegions();
        } catch (e) {
            this.destroy();
            throw e;
        }
    }
    _clearInputPieces() {
        for (const piece of this._inputPieces) {
            try { unregisterFenceInput(piece); } catch (e) { safeError('Untrack Fence region',e); }
            try { piece.destroy(); } catch (_) {}
        }
        this._inputPieces = [];
        this._inputRegionKey = '';
    }
    updateInputRegions(windowBoxes) {
        if (this._disposed || !this.actor) return;
        if ((this.manager && !this.manager.fencesVisible) || (this.config && this.config.hidden) || this.actor.visible===false) {
            this._clearInputPieces();
            return;
        }
        const [x,y]=this.actor.get_transformed_position();
        const width=this.actor.width, height=this.actor.height;
        if (![x,y,width,height].every(Number.isFinite) || width<=0 || height<=0) {
            this._clearInputPieces();
            return;
        }
        // Use integer coordinates, as Cinnamon does for its X11 input region.
        const base={x:Math.round(x),y:Math.round(y),
            width:Math.round(width),height:Math.round(height)};
        const visible=visibleFenceInputBoxes(base,windowBoxes);
        const key=visible.map(b=>`${b.x}:${b.y}:${b.width}:${b.height}`).join(';');
        if (key===this._inputRegionKey) return;
        this._clearInputPieces();
        try {
            for (const rect of visible) {
                const child=new St.Widget({reactive:false, visible:true});
                this.actor.add_child(child);
                child.set_position(rect.x-base.x, rect.y-base.y);
                child.set_size(rect.width, rect.height);
                // Only this inert child is tracked; the rendered Fence root
                // remains underneath application windows.
                registerFenceInput(child);
                this._inputPieces.push(child);
            }
            this._inputRegionKey=key;
        } catch(e) {
            // Fail closed: window clicks have priority even if X11 registration
            // fails on this Cinnamon version.
            this._clearInputPieces();
            safeError('Fence input region could not be updated',e);
        }
    }
    _createMenu() {
        // Cinnamon 6.x PopupMenu takes (sourceActor, orientation), not the
        // obsolete 3-argument signature. Use an invisible *pointer anchor*
        // in uiGroup: a header source would attach the menu to its edge,
        // instead of at the actual right-click position.
        this._menuAnchor = new St.Widget({reactive: false, width: 1, height: 1});
        Main.uiGroup.add_child(this._menuAnchor);
        // LEFT means: the menu appears to the RIGHT of the anchor, unless
        // near the screen edge, in which case Cinnamon flips/clamps it.
        this.menu = new PopupMenu.PopupMenu(this._menuAnchor, St.Side.LEFT);
        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menuManager.addMenu(this.menu);
        Main.uiGroup.add_child(this.menu.actor);
        this.menu.actor.hide();
        this.menu.addAction('Open in Nemo', () => this.openFolder());
        this._trashItemMenuItem = this.menu.addAction('Move to Trash', () => this._trashSelectedItems());
        this._renameItemMenuItem = this.menu.addAction('Rename…', () => this._renameSelectedItem());
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Sort by Name', () => this.sortAlphabetically());
        this.menu.addAction('Compact Icons', () => this.compactIcons());
        this._undoMenuItem = this.menu.addAction('Undo Arrangement', () => this.restoreArrangement());
        this._fileUndoMenuItem = this.menu.addAction('Undo File Transfer', () => this.manager.undoLastTransfer());
        this._clearSelectionMenuItem = this.menu.addAction('Clear Selection', () => this._clearItemStates());
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._lockMenuItem = this.menu.addAction('Lock Position and Size', () => this.toggleGeometryLock());
        this._collapseMenuItem = this.menu.addAction('Collapse', () => this.toggleCollapsed());
        this._viewMenuItem = new PopupMenu.PopupSubMenuMenuItem('View As');
        this.menu.addMenuItem(this._viewMenuItem);
        this._viewModeItems = {
            icons: this._viewMenuItem.menu.addAction('Icons', () => this.setViewMode('icons')),
            tabs: this._viewMenuItem.menu.addAction('Tabs', () => this.setViewMode('tabs')),
            rolodex: this._viewMenuItem.menu.addAction('Rolodex', () => this.setViewMode('rolodex'))
        };
        this.menu.addAction('Refresh', () => this.rebuild());
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        if (!this.isUnassigned) {
            this.menu.addAction('Rename Fence…', () => openCinnaFencesSettings(this.folder));
            this.menu.addAction('Hide Fence', () => this._hideThisFence());
            this.menu.addAction('Create / Manage Fences…', () => openCinnaFencesSettings(null,true));
            this.menu.addAction('Remove Fence…', () => openCinnaFencesSettings(this.folder,true));
            this.menu.addAction('Fence Settings…', () => openCinnaFencesSettings(this.folder));
        } else {
            this.menu.addAction('Fence Settings…', () => openCinnaFencesSettings(this.folder));
        }
    }
    _hideThisFence() {
        if (this._drag || this._disposed) return;
        try {
            const target=Gio.File.new_for_path(configPathFor(this.folder));
            const [ok, bytes]=target.load_contents(null);
            if (!ok) throw new Error('Cannot read Fence settings');
            const settings=JSON.parse(ByteArray.toString(bytes));
            if (!settings || typeof settings!=='object') throw new Error('Invalid Fence configuration');
            settings.hidden=true;
            // Do not use _save(), which intentionally saves geometry only.
            const tmp=Gio.File.new_for_path(configPathFor(this.folder)+'.'+GLib.uuid_string_random()+'.tmp');
            try {
                // Same tested atomic-write pattern used by writeConfig().
                GLib.file_set_contents(tmp.get_path(),JSON.stringify(settings,null,2)+'\n');
                tmp.move(target,Gio.FileCopyFlags.OVERWRITE,null,null);
            } finally { try { if (tmp.query_exists(null)) tmp.delete(null); } catch (_) {} }
            this.config.hidden=true;
            this._clearInputPieces(); this.actor.hide();
            this.manager.queueInputRegions();
            Main.notify('CinnaFences','Fence hidden. Show it again in Settings → Manage Fences.');
        } catch(e) { safeError('Hide Fence',e); Main.notify('CinnaFences','Could not hide Fence.'); }
    }
    _renameSelectedItem() {
        if (this._disposed || this._drag || !this._itemContext) return;
        const chosen=this.items.filter(it=>it.selected && it.path);
        if (chosen.length!==1) return;
        // Reuse the same on-demand GTK helper as the settings window.
        // Its Gio.File.move(NO_OVERWRITE) prevents replacing existing files.
        const script=pathJoin(pathJoin(pathJoin(pathJoin(GLib.get_user_data_dir(),
            'cinnamon'),'extensions'),'cinnafences@local'),'settings.py');
        try {
            Gio.Subprocess.new(['/usr/bin/python3',script,'--rename-icon',chosen[0].path],
                Gio.SubprocessFlags.NONE);
        } catch(e) { safeError('Rename icon',e);Main.notify('CinnaFences','Cannot open Rename dialog.'); }
    }
    _trashSelectedItems() {
        if (this._disposed || this._drag || !this._itemContext) return false;
        // Only paths from currently rendered icons; never accept paths from a
        // command line, a config field or a symbolic-link target.
        const chosen=this.items.filter(it=>it.selected && it.path);
        if (!chosen.length) return false;
        const failed=[];
        let success=0;
        for (const item of chosen) {
            try {
                // Gio.File.trash() acts on the link/launcher itself. It does
                // not follow a symbolic link to an external target.
                Gio.File.new_for_path(item.path).trash(null);
                delete this.config.icons.positions[item.name];
                success++;
            } catch (e) { failed.push(item.name+': '+String(e.message||e)); }
        }
        if (success) {
            this.config.icons.undoArrangement=null;
            this._save();
            this._clearItemStates();
            this._itemContext=false;
            this.manager.queueScan(this.folder);
        }
        if (failed.length) {
            safeError('Move to Trash',new Error(failed.join('; ')));
            Main.notify('CinnaFences', `${success} moved to Trash; ${failed.length} failed. Check the Cinnamon log.`);
        } else if (success) {
            Main.notify('CinnaFences', `${success} icon(s) moved to Trash (recoverable in Nemo).`);
        }
        return failed.length===0;
    }
    _refreshMenuActions() {
        if (this._renameItemMenuItem) {
            this._renameItemMenuItem.actor.visible=!!this._itemContext;
            if(this._renameItemMenuItem.setSensitive) this._renameItemMenuItem.setSensitive(this._itemContext && this.items.filter(it=>it.selected).length===1);
        }
        if (this._trashItemMenuItem) {
            // Nemo shows file actions only in an item context, not on empty space.
            this._trashItemMenuItem.actor.visible=!!this._itemContext;
            if (this._trashItemMenuItem.setSensitive)
                this._trashItemMenuItem.setSensitive(this._itemContext &&
                    this.items.some(it=>it.selected));
        }
        if (this._undoMenuItem && this._undoMenuItem.setSensitive)
            this._undoMenuItem.setSensitive(!!this.config.icons.undoArrangement);
        if (this._fileUndoMenuItem && this._fileUndoMenuItem.setSensitive)
            this._fileUndoMenuItem.setSensitive(!!this.manager.lastTransfer);
        if (this._fileUndoMenuItem && this._fileUndoMenuItem.label)
            this._fileUndoMenuItem.label.set_text(this.manager.lastTransfer ?
                (this.manager.lastTransfer.copy ? 'Undo Copy' : 'Undo Move') : 'Undo File Transfer');
        if (this._clearSelectionMenuItem && this._clearSelectionMenuItem.setSensitive)
            this._clearSelectionMenuItem.setSensitive(this.items.some(it=>it.selected));
        if (this._lockMenuItem && this._lockMenuItem.label)
            this._lockMenuItem.label.set_text(this.config.geometryLocked ?
                'Unlock Position and Size' : 'Lock Position and Size');
        if (this._collapseMenuItem && this._collapseMenuItem.label)
            this._collapseMenuItem.label.set_text(this.config.collapsed ? 'Expand' : 'Collapse');
        if (this.isUnassigned && this._viewMenuItem)
            this._viewMenuItem.actor.visible=false;
        if (this._viewModeItems)
            for (const mode of ['icons','tabs','rolodex']) {
                const entry=this._viewModeItems[mode];
                if (entry && entry.setShowDot)
                    entry.setShowDot(this.config.view.mode===mode);
            }
    }
    _contextDown(event, itemContext=false) {
        if (this._drag || this._disposed) return Clutter.EVENT_STOP;
        const [x,y]=event.get_coords();
        // Remember item vs blank-Fence context while the right button is held.
        // On X11 the originating actor may keep an implicit grab until release;
        // opening a PopupMenu here can swallow the release intended for it.
        this._contextPending={x,y,itemContext:!!itemContext};
        return Clutter.EVENT_STOP;
    }
    _contextCapture(event) {
        if (!this._contextPending || event.type()!==Clutter.EventType.BUTTON_RELEASE ||
            event.get_button()!==3) return Clutter.EVENT_PROPAGATE;
        const pending=this._contextPending;
        this._contextPending=null;
        const [x,y]=event.get_coords();
        // A right-button drag should not create a menu at an unrelated point.
        if (Math.abs(x-pending.x)>12 || Math.abs(y-pending.y)>12)
            return Clutter.EVENT_STOP;
        if (this._contextOpenIdle) GLib.source_remove(this._contextOpenIdle);
        // Let Clutter finish the button release and implicit pointer grab before
        // Cinnamon's PopupMenuManager takes its own menu modal grab.
        this._contextOpenIdle=GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._contextOpenIdle=0;
            if (!this._disposed && !this._drag)
                this.openMenu({get_coords:()=>[x,y]},pending.itemContext);
            return GLib.SOURCE_REMOVE;
        });
        return Clutter.EVENT_STOP;
    }
    openMenu(event, itemContext=false) {
        this._itemContext=!!itemContext;
        if (this.menu.isOpen) { this.menu.close(false); return; }
        this._refreshMenuActions();
        const [x, y] = event ? event.get_coords() : global.get_pointer();
        this._menuAnchor.set_position(Math.round(x), Math.round(y));
        this.menu.open(false);
    }
    openFolder() { this._launchPath(this.folder, false); }
    _launchPath(path, desktop) {
        try {
            if (desktop) {
                if (!GLib.file_test(path, GLib.FileTest.IS_EXECUTABLE) &&
                    !isTrustedSystemLauncherShortcut(path)) {
                    Main.notify('CinnaFences', 'Launcher niet uitvoerbaar. Maak het .desktop-bestand eerst vertrouwd/uitvoerbaar in Nemo.');
                    return;
                }
                const launcher = Gio.DesktopAppInfo.new_from_filename(path);
                if (!launcher) throw new Error('Kan .desktop-bestand niet laden');
                launcher.launch([], global.create_app_launch_context());
            } else {
                Gio.app_info_launch_default_for_uri(Gio.File.new_for_path(path).get_uri(), global.create_app_launch_context());
            }
        } catch (e) { safeError('Openen: ' + path, e); Main.notify('CinnaFences', 'Openen mislukt: ' + GLib.path_get_basename(path)); }
    }
    _style(hover) {
        const a = this.config.appearance;
        const k = hover ? a.hoverOpacity : a.backgroundOpacity;
        const h = this.config.header;
        const radius = a.radius;
        // The header and the body are SIBLINGS on the wallpaper, not stacked
        // transparent surfaces. Equal colors/alpha now yield equal pixels.
        const edge = a.borderEnabled ?
            `${a.borderWidth}px solid ${rgba(a.borderColor, a.borderOpacity)}` : '0px solid transparent';
        const bodyBorder = h.show ?
            `border:${edge};border-top:0px;`+
                `border-radius:0px 0px ${radius}px ${radius}px;` :
            `border:${edge};border-radius:${radius}px;`;
        this.background.set_style(`background-color:${rgba(a.background, k)};`+bodyBorder);
        this.header.set_style(h.show ?
            `background-color:${rgba(hover ? h.hoverBackground : h.background,
                hover ? h.hoverOpacity : h.opacity)};`+
            `border:${edge};border-bottom:0px;`+
            `border-radius:${radius}px ${radius}px 0px 0px;` :
            'background-color:rgba(0,0,0,0);');
        this.title.set_style(`color:${hover ? h.hoverTextColor : h.textColor};`+
            `font-family:'${h.fontFamily}';font-size:${h.fontSize}pt;font-weight:bold;`);
        for (const entry of (this._navButtons || [])) {
            const z = this.config.sections;
            const hot = entry.hover === true;
            const inHeader = entry.inHeader === true;
            const active = entry.key === this._activeSection;
            const backgroundColor = inHeader ? (active ? 'rgba(255,255,255,0.14)' :
                (hot ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0)')) :
                rgba(hot ? z.hoverBackground : z.background, hot ? z.hoverOpacity : z.opacity);
            const shape = inHeader ? 'border-radius:6px 6px 0px 0px;' :
                (this.config.view.mode === 'rolodex' ? sectionCornerShape(
                    'rolodex', h.show, this._navButtons.indexOf(entry),
                    entry.y - this.scroll, entry.height, this.content.height,
                    this.scroll, radius) : 'border-radius:4px;');
            entry.actor.set_style('background-color:'+backgroundColor+';'+
                'color:'+(hot ? z.hoverTextColor : z.textColor)+';'+
                'font-family:\''+z.fontFamily+'\';font-size:'+z.fontSize+'pt;'+shape+
                (inHeader ? (active ? 'border-bottom:2px solid rgba(255,255,255,0.82);' :
                    'border-bottom:2px solid rgba(0,0,0,0);') : '')+'padding:0px 5px;');
            if (entry.label && entry.label.set_style)
                entry.label.set_style('color:'+(hot ? z.hoverTextColor : z.textColor)+';'+
                    'font-family:\''+z.fontFamily+'\';font-size:'+z.fontSize+'pt;');
        }
        for (const it of this.items) {
            it.icon.opacity = Math.round(255 * (hover ? 1 : a.iconOpacity));
            it.label.opacity = Math.round(255 * (hover ? 1 : a.labelOpacity));
        }
    }
    _headerHeight() {
        // Zero reserved pixels when hidden. Alt+drag moves a headerless Fence.
        return this.config.header.show ? this.config.header.height : 0;
    }
    _sizeActors() {
        const g = this.config.geometry;
        const hh = this._headerHeight();
        const width = g.width;
        const autoFit = this.config.view.mode === 'rolodex' && this.config.view.autoFitHeight;
        const height = this.config.collapsed ? Math.max(hh, 24) :
            (autoFit && this._autoHeightPixels !== null ? this._autoHeightPixels : g.height);
        this.actor.set_size(width,height);
        // Never overlap translucent header and body background layers.
        this.background.set_position(0,hh);
        this.background.set_size(width,Math.max(0,height-hh));
        this.header.set_position(0,0);
        this.header.set_size(width,hh);
        this.header.visible=this.config.header.show;
        this.title.visible=this.config.header.show;
        this.arrow.visible=this.config.header.show && this.config.header.showCollapseButton;
        this.title.set_position(12,Math.max(0,Math.floor((hh-this.config.header.fontSize*1.4)/2)));
        this.title.set_width(Math.max(40,width-(this.arrow.visible?45:20)));
        this.arrow.set_position(width-32,Math.max(0,Math.floor((hh-28)/2)));
        this.arrow.set_size(30,Math.min(hh,28));
        this.arrowIcon.icon_name=this.config.collapsed?'pan-end-symbolic':'pan-down-symbolic';
        const fullBleed=this.config.view.mode==='rolodex';
        this.content.set_position(fullBleed ? 1 : PAD,hh+(fullBleed ? 0 : PAD));
        this.content.set_size(Math.max(1,width-(fullBleed?2:2*PAD+SCROLLBAR_W)),
            Math.max(0,height-hh-(fullBleed?1:2*PAD)));
        this.content.visible=!this.config.collapsed;
        this.scrollTrack.set_position(width-PAD-SCROLLBAR_W+2,hh+PAD);
        this.scrollTrack.set_size(SCROLLBAR_W-2,Math.max(0,height-hh-2*PAD));
        this._placeScrollbar();
        this._style(!this.config.appearance.hoverEnabled || this.hovered);
    }
    _limitAutoHeight() {
        const limit=this.config.view.autoFitMaxHeight;
        try {
            const [x,y]=this.actor.get_transformed_position();
            const area=this._workAreaForPointer(x+this.actor.width/2,y+10);
            return Math.max(24, Math.min(limit,Math.max(24,area.y+area.height-y)));
        } catch (_) { return limit; }
    }
    _readItems() {
        let base=directoryNames(this.folder,false).filter(x=>x!==CONFIG_NAME && !x.endsWith('.tmp'));
        if (this.isUnassigned) base=unassignedNames(this.folder,base);
        if (this.config.view.mode==='icons') {
            this._sections=[];
            this._activeSection=null;
            return base.slice(0,MAX_FILES).map(name=>({name,path:pathJoin(this.folder,name),label:name}));
        }
        const dirs=directoryNames(this.folder,true).slice(0,SECTION_LIMIT);
        const regular=base.filter(name=>!dirs.includes(name) &&
            !GLib.file_test(pathJoin(this.folder,name),GLib.FileTest.IS_DIR));
        this._sections=[];
        if (regular.length || !dirs.length) this._sections.push({key:'/',title:'Main',folder:this.folder,root:true});
        for (const name of dirs) this._sections.push({key:name,title:name,folder:pathJoin(this.folder,name),root:false});
        let active=this.config.view.active;
        if (active===null || (active!=='' && !this._sections.some(s=>s.key===active)))
            active=this._sections.length?this._sections[0].key:null;
        if (this.config.view.mode==='tabs' && active==='') active=this._sections.length?this._sections[0].key:null;
        this._activeSection=active;
        const group=this._sections.find(s=>s.key===active);
        if (!group) return [];
        const names=group.root ? regular : directoryNames(group.folder,false);
        return names.slice(0,MAX_FILES).map(name=>({
            name:group.root ? name : group.key+'/'+name,
            path:pathJoin(group.folder,name),label:name
        }));
    }
    setViewMode(mode) {
        if (!['icons','tabs','rolodex'].includes(mode) || this.isUnassigned || this._disposed || this._drag) return;
        if (this.config.view.mode===mode) return;
        this.config.view.mode=mode;
        this.config.view.active=mode==='rolodex'?'':null;
        this.scroll=0;
        this.rebuild();
        this._saveView();
    }
    _activateSection(key) {
        if (this._disposed || this._drag) return;
        const next=this.config.view.mode==='rolodex' && this._activeSection===key ? '' : key;
        if (this._activeSection===next) return;
        this.config.view.active=next;
        this.scroll=0;
        this.rebuild();
        this._saveView();
    }
    _saveView() {
        try {writeFenceView(this.folder,this.config.view);}
        catch(e) {safeError('View opslaan: '+this.folder,e);Main.notify('CinnaFences','Could not save view selection');}
    }
    _rebuildNavigation() {
        for (const entry of (this._navButtons || [])) entry.actor.destroy();
        this._navButtons=[];
        this._navStyleSignature=null;
        if (this.config.view.mode==='icons') return;
        for (const section of this._sections) {
            const active=section.key===this._activeSection;
            const marker=this.config.sections.showCollapseButton && this.config.view.mode==='rolodex' ?
                (active?'▾  ':'▸  ') : '';
            const caption=marker+section.title;
            // St.Button (a St.Bin) may allocate only the label's natural width;
            // x-align on that label alone cannot align it within a wide section.
            // Give its child a full-width BoxLayout and distribute real free space.
            const align=this.config.sections.alignment;
            const label=new St.Label({text:caption,y_align:Clutter.ActorAlign.CENTER});
            const before=new St.Widget({x_expand:align!=='left'});
            const after=new St.Widget({x_expand:align!=='right'});
            const barLayout=new St.BoxLayout({x_expand:true,y_align:Clutter.ActorAlign.CENTER});
            barLayout.add_child(before);
            barLayout.add_child(label);
            barLayout.add_child(after);
            const button=new St.Button({child:barLayout,x_fill:true,reactive:true,
                track_hover:true,can_focus:true});
            button.connect('clicked',()=>this._activateSection(section.key));
            button.connect('button-press-event',(_a,event)=>{
                if (event.get_button()===3) return this._contextDown(event);
                return Clutter.EVENT_PROPAGATE;
            });
            // Tabs can be reparented into the header by _layoutNavigation().
            this.content.add_child(button);
            const entry={key:section.key,actor:button,label,hover:false,x:0,y:0,width:0,height:0};
            button.connect('enter-event',()=>{entry.hover=true;this._style(!this.config.appearance.hoverEnabled||this.hovered);return Clutter.EVENT_PROPAGATE;});
            button.connect('leave-event',()=>{entry.hover=false;this._style(!this.config.appearance.hoverEnabled||this.hovered);return Clutter.EVENT_PROPAGATE;});
            this._navButtons.push(entry);
        }
    }
    _layoutNavigation() {
        if (this.config.view.mode==='icons') {this._gridOriginY=0;this._contentLength=0;return;}
        const z=this.config.sections;
        const width=Math.max(1,this.content.width);
        if (this.config.view.mode==='tabs') {
            const names=this._navButtons.map(e=>this._sections.find(s=>s.key===e.key).title);
            const widths=names.map(name=>Math.max(45,Math.round(name.length*z.fontSize*0.60)+18));
            const total=widths.reduce((a,b)=>a+b,0)+Math.max(0,widths.length-1)*2;
            // Only move tabs into the titlebar when ALL tabs are reachable.
            // The content strip remains visible when the titlebar is hidden or narrow.
            const headerWidth=this.config.geometry.width-
                (this.arrow.visible?38:8)-Math.max(72,Math.min(180,Math.round(this.config.title.length*this.config.header.fontSize*0.6)+18))-12;
            const inHeader=this.config.view.tabsInHeader && this.config.header.show &&
                total<=headerWidth && widths.length>0 && this._headerHeight()>=26;
            if (inHeader) {
                let x=this.config.geometry.width-(this.arrow.visible?37:7)-total;
                for (let i=0;i<this._navButtons.length;i++) {
                    const entry=this._navButtons[i];
                    if (entry.actor.get_parent()!==this.header) {
                        entry.actor.get_parent().remove_child(entry.actor);
                        this.header.add_child(entry.actor);
                    }
                    const tabHeight=Math.max(20,this._headerHeight()-5);
                    Object.assign(entry,{x,y:this._headerHeight()-tabHeight,
                        width:widths[i],height:tabHeight,inHeader:true});
                    x+=widths[i]+2;
                }
                this.title.set_width(Math.max(40,
                    this._navButtons[0].x-20));
                this._gridOriginY=4;
                return;
            }
            let x=0,y=0;
            for (let i=0;i<this._navButtons.length;i++) {
                const entry=this._navButtons[i];
                if (entry.actor.get_parent()!==this.content) {
                    entry.actor.get_parent().remove_child(entry.actor);
                    this.content.add_child(entry.actor);
                }
                const w=Math.min(width,widths[i]);
                if (x && x+w>width) {x=0;y+=z.height+3;}
                Object.assign(entry,{x,y,width:w,height:z.height,inHeader:false});
                x+=w+3;
            }
            this.title.set_width(Math.max(40,this.config.geometry.width-(this.arrow.visible?45:20)));
            this._gridOriginY=y+z.height+6;
            return;
        }
        // Full-bleed Rolodex bars. Only 2px between adjacent closed bars;
        // opened section icons retain their own subtle left inset.
        let y=0;
        const maxRow=this.items.reduce((m,it)=>Math.max(m,it.row),-1);
        const iconHeight=(maxRow+1)*this.config.icons.gridHeight;
        for (const entry of this._navButtons) {
            Object.assign(entry,{x:0,y,width,height:z.height,inHeader:false});
            y+=z.height+2;
            if (entry.key===this._activeSection) {this._gridOriginY=y+3;y+=iconHeight+5;}
        }
        if (!this._navButtons.some(e=>e.key===this._activeSection)) this._gridOriginY=0;
    }
    rebuild() {
        if (this._disposed || this._drag) return;
        this._sizeActors();
        const entries = this._readItems().map(entry=>typeof entry==='string' ?
            {name:entry,path:pathJoin(this.folder,entry),label:entry} : entry);
        this._names = entries.map(entry=>entry.name);
        for (const item of this.items) item.actor.destroy();
        this.items = [];
        this._rebuildNavigation();
        const iconSize = this.config.icons.size;
        const cw = this.config.icons.gridWidth, ch = this.config.icons.gridHeight;
        // All icon labels in a Fence use the same font. Parse it once per
        // rebuild rather than constructing a Pango description per file.
        const labelFont = Pango.FontDescription.from_string(
            `${this.config.icons.labelFont} ${this.config.icons.labelFontSize}`);
        const labelFamily = (labelFont.get_family() || 'Sans').replace(/'/g, '');
        const labelWeight = labelFont.get_weight();
        const labelItalic = labelFont.get_style() === Pango.Style.NORMAL ? 'normal' : 'italic';
        const labelCss = `color:${this.config.appearance.labelColor};`+
            `font-family:'${labelFamily}';font-size:${this.config.icons.labelFontSize}pt;`+
            `font-weight:${labelWeight};font-style:${labelItalic};text-align:center;`;
        for (const entry of entries) {
            const name=entry.name, path=entry.path;
            const wrapper = new St.Widget({reactive:true,track_hover:true,layout_manager:new Clutter.FixedLayout(),
                style_class:'cinnafence-icon-cell'});
            wrapper.set_size(cw,ch);
            let labelText = entry.label;
            let gicon = null;
            if (entry.label.endsWith('.desktop')) {
                try {
                    const app = Gio.DesktopAppInfo.new_from_filename(path);
                    if (app) { labelText = app.get_name() || name; gicon = app.get_icon(); }
                } catch (e) { /* show fallback icon */ }
            }
            if (!gicon) {
                try {
                    const f = Gio.File.new_for_path(path);
                    const info = f.query_info('standard::icon,standard::display-name',
                        Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, null);
                    gicon = info.get_icon();
                    if (!entry.label.endsWith('.desktop')) labelText = info.get_display_name() || entry.label;
                } catch (e) { /* transient deleted file: fallback */ }
            }
            const icon = gicon ? new St.Icon({gicon,icon_size:iconSize}) :
                new St.Icon({icon_name:'text-x-generic',icon_size:iconSize});
            icon.set_position(Math.round((cw-iconSize)/2),2);
            const label = new St.Label({text:labelText, style_class:'cinnafence-icon-label'});
            label.visible = this.config.icons.showLabels;
            // Gtk.FontButton returns a Pango description, possibly including
            // "Bold" or "Italic", NOT a CSS font-family name. Feed the same
            // description to Pango (and the family/style to the theme), so
            // selecting a font really changes the rendered glyphs.
            label.set_style(labelCss);
            label.clutter_text.set_ellipsize(Pango.EllipsizeMode.END);
            label.clutter_text.set_line_alignment(Pango.Alignment.CENTER);
            // Explicit Pango font on ClutterText also covers Cinnamon themes
            // that override St.Label's CSS font properties. Set the font before
            // measuring the preferred width, otherwise non-default fonts drift.
            label.clutter_text.set_font_description(labelFont);
            wrapper.add_child(icon); wrapper.add_child(label);
            // Center the LABEL ACTOR using its actual preferred text width.
            // Merely centering wrapped text inside a full-width St.Label does
            // not center single-line labels under their icons in Cinnamon.
            const [, naturalWidth] = label.get_preferred_width(-1);
            const labelWidth = Math.max(1, Math.min(cw - 4, Math.ceil(naturalWidth)));
            label.set_width(labelWidth);
            label.set_position(Math.round((cw - labelWidth) / 2), iconSize + 6);
            this.content.add_child(wrapper);
            const item = {name, path, actor:wrapper, icon, label, col:0, row:0,
                selected:false, hover:false};
            wrapper.connect('button-press-event', (_a,e) => this._itemDown(item,e));
            wrapper.connect('scroll-event', (_a,e) => this._scroll(e));
            wrapper.connect('enter-event', () => { item.hover=true; this._paintItem(item); });
            wrapper.connect('leave-event', () => { item.hover=false; this._paintItem(item); });
            this.items.push(item);
        }
        this.selectedItem=null;
        this._selectionAnchor=null;
        this._renderColumns = columns(this.config.geometry.width, this.config.icons.gridWidth);
        this._layoutItems();
        this._style(!this.config.appearance.hoverEnabled || this.hovered); // Newly created icons must get their idle opacity too.
    }
    _paintItem(item) {
        if (!item.actor) return;
        const color = item.selected ? 'rgba(255,255,255,0.22)' :
            item.hover ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0)';
        item.actor.set_style('background-color:' + color + ';');
    }
    _selectItem(item) {
        this.selectedItem=item;
        this._selectionAnchor=item;
        for (const it of this.items) {
            it.selected=(it===item);
            this._paintItem(it);
        }
    }
    _toggleSelectedItem(item) {
        item.selected=!item.selected;
        this.selectedItem=item.selected?item:(this.items.find(it=>it.selected)||null);
        this._selectionAnchor=this.selectedItem;
        this._paintItem(item);
    }
    _selectRangeTo(item, additive=false) {
        const ordered=[...this.items].sort((a,b)=>a.row-b.row||a.col-b.col);
        const anchor=ordered.indexOf(this._selectionAnchor);
        const end=ordered.indexOf(item);
        if (anchor<0 || end<0) {this._selectItem(item);return;}
        const lo=Math.min(anchor,end),hi=Math.max(anchor,end);
        for (let i=0;i<ordered.length;i++) {
            ordered[i].selected=(additive && ordered[i].selected) || (i>=lo && i<=hi);
            this._paintItem(ordered[i]);
        }
        this.selectedItem=item;
    }
    _clearItemStates() {
        this.selectedItem=null;
        this._selectionAnchor=null;
        for (const it of this.items) {
            it.selected=false; it.hover=false;
            this._paintItem(it);
        }
    }
    _layoutItems() {
        const conf = this.config.icons;
        const cols = columns(this.config.geometry.width, conf.gridWidth);
        const sectionMode=this.config.view.mode!=='icons';
        const sectionKey=sectionMode ? this._activeSection : null;
        const ownCols=sectionMode ? (conf.sectionLayoutColumns || {})[sectionKey] : conf.layoutColumns;
        const canonicalCols = ownCols || cols;
        const ordered = canonicalOrder(this._names, conf.positions, canonicalCols);
        const hasOverflow = ordered.some(it => it.col >= cols);
        // Legacy Rolodex layouts did not have independent section grids. Start
        // those sections compact instead of inheriting sparse classic icon cells.
        // Once manually arranged, respect each section's intentional gaps.
        const reflow = (sectionMode && !ownCols) || cols !== canonicalCols || hasOverflow;
        const byName = new Map();
        ordered.forEach((it,index) => byName.set(it.name, reflow ?
            [index%cols, Math.floor(index/cols)] : [it.col,it.row]));
        this.cells.clear();
        for (const it of this.items) {
            const [col,row] = byName.get(it.name);
            it.col = col; it.row = row;
            this.cells.set(row*1000+col,it);
        }
        this._placeItems();
    }
    _placeItems() {
        if (this.config && this.config.view && this.config.view.mode!=='icons') {
            const conf=this.config.icons;
            this._layoutNavigation();
            const maxRow=this.items.reduce((m,it)=>Math.max(m,it.row),-1);
            const iconsEnd=this._gridOriginY+(maxRow+1)*conf.gridHeight;
            let navEnd=0;
            for (const nav of this._navButtons) if (!nav.inHeader) navEnd=Math.max(navEnd,nav.y+nav.height);
            const totalHeight=Math.max(navEnd,iconsEnd)+
                (this.config.view.mode==='rolodex' && this.config.view.autoFitHeight ? 2 : 8);
            if (this.config.view.mode==='rolodex' && this.config.view.autoFitHeight && !this.config.collapsed) {
                const wanted=rolodexFitHeight(this._headerHeight(),navEnd,iconsEnd,
                    this.config.view.autoFitMaxHeight,this._limitAutoHeight());
                if (wanted!==this._autoHeightPixels) {
                    this._autoHeightPixels=wanted;
                    this._sizeActors();
                }
            }
            const viewportH=Math.max(0,this.content.height);
            this._maxScroll=Math.max(0,totalHeight-viewportH);
            this.scroll=clamp(this.scroll,0,this._maxScroll);
            for (const nav of this._navButtons) {
                const y=nav.inHeader ? nav.y : nav.y-this.scroll;
                nav.actor.set_position(nav.x,y);
                nav.actor.set_size(nav.width,nav.height);
                nav.actor.visible=!this.config.collapsed && (nav.inHeader || (y<viewportH && y+nav.height>0));
            }
            for (const it of this.items) {
                const y=this._gridOriginY+it.row*conf.gridHeight-this.scroll;
                it.actor.set_position((this.config.view.mode==='rolodex'?8:0)+it.col*conf.gridWidth,y);
                it.actor.visible=!this.config.collapsed && y<viewportH && y+conf.gridHeight>0;
            }
            this._placeScrollbar();
            // Corner shape depends on the FINAL viewport after auto-fit. Only
            // re-style when a corner changes; scrolling must remain inexpensive.
            if (this.background && this.header) {
                const signature=this._navButtons.map((nav,i)=>nav.inHeader?'tab':
                    sectionCornerShape(this.config.view.mode,this.config.header.show,i,
                        nav.y-this.scroll,nav.height,viewportH,this.scroll,
                        this.config.appearance.radius)).join('|');
                if (signature!==this._navStyleSignature) {
                    this._navStyleSignature=signature;
                    this._style(!this.config.appearance.hoverEnabled || this.hovered);
                }
            }
            return;
        }
        const conf = this.config.icons;
        const viewportH = Math.max(0, this.content.height);
        const maxRow = this.items.reduce((m,it)=>Math.max(m,it.row), -1);
        this._maxScroll = maxScrollPixels(maxRow, viewportH, conf.gridHeight);
        this.scroll = clamp(this.scroll, 0, this._maxScroll);
        for (const it of this.items) {
            const y = it.row * conf.gridHeight - this.scroll;
            it.actor.set_position(it.col * conf.gridWidth, y);
            // Clip by the content viewport, but never hide a partially visible
            // row completely; it must remain reachable with the mouse wheel.
            it.actor.visible = !this.config.collapsed &&
                y < viewportH && y + conf.gridHeight > 0;
        }
        this._placeScrollbar();
    }
    _placeScrollbar() {
        if (!this.scrollTrack) return;
        const height = Math.max(0,this.scrollTrack.height);
        this.scrollTrack.visible = !this.config.collapsed && this._maxScroll > 0 && height > 0;
        if (!this.scrollTrack.visible) return;
        const viewportH = Math.max(1, this.content.height);
        const totalH = viewportH + this._maxScroll;
        const thumbH = Math.min(height, Math.max(24, Math.round(height * viewportH / totalH)));
        this.scrollThumb.set_position(1, Math.round((height-thumbH) * this.scroll / this._maxScroll));
        this.scrollThumb.set_size(Math.max(3,this.scrollTrack.width-2), thumbH);
    }
    _scrollTrackClick(e) {
        if (e.get_button() !== 1 || this._maxScroll === 0) return Clutter.EVENT_PROPAGATE;
        const [,sy] = e.get_coords();
        const [,top] = this.scrollTrack.get_transformed_position();
        const rel = clamp((sy-top)/Math.max(1,this.scrollTrack.height),0,1);
        this.scroll = Math.round(rel * this._maxScroll);
        this._placeItems();
        return Clutter.EVENT_STOP;
    }
    _scroll(e) {
        if (this.config.collapsed || this._maxScroll === 0)
            return Clutter.EVENT_PROPAGATE;
        const direction = e.get_scroll_direction();
        const notch = Math.max(24, Math.round(this.config.icons.gridHeight * 0.55));
        let delta=0;
        if (direction === Clutter.ScrollDirection.DOWN) delta=notch;
        else if (direction === Clutter.ScrollDirection.UP) delta=-notch;
        else if (direction === Clutter.ScrollDirection.SMOOTH) {
            const [,dy] = e.get_scroll_delta();
            if (Number.isFinite(dy)) delta = dy * notch;
        } else return Clutter.EVENT_PROPAGATE;
        if (delta !== 0) {
            this.scroll = clamp(this.scroll+delta,0,this._maxScroll);
            this._placeItems();
        }
        return Clutter.EVENT_STOP;
    }
    _setCursor(name) {
        if (this._cursorName === name) return;
        this._cursorName = name;
        try {
            if (name && Cinnamon.Cursor[name] !== undefined) global.set_cursor(Cinnamon.Cursor[name]);
            else global.unset_cursor();
        } catch (e) { /* Cursor support differs by Cinnamon version */ }
    }
    _clearCursor() { this._setCursor(null); }
    _pointerInside(x, y) {
        if (!this.actor || !this.actor.visible) return false;
        const [ax, ay] = this.actor.get_transformed_position();
        return x >= ax && y >= ay && x < ax + this.actor.width && y < ay + this.actor.height;
    }
    _setHovered(inside, reason) {
        if (this._disposed || this._drag) return;
        // A persistent fallback keeps the Fence usable if hover is problematic
        // on a particular Cinnamon/graphics configuration.
        if (this.hovered === inside) return;
        this.hovered = inside;
        const active = this.config.appearance.hoverEnabled ? inside : true;
        this._style(active);
        if (this.config && this.config.debugHover)
            global.log(`[CinnaFences hover] ${this.folder}: ${active ? 'ACTIVE' : 'IDLE'} (${reason})`);
        if (!inside) {
            this._clearCursor();
            this._clearItemStates();
        }
    }
    _syncHoverFromPointer(x, y, reason='pointer') {
        if (this._disposed || this._drag) return;
        this._setHovered(this._pointerInside(x, y), reason);
    }
    _startDragWatchdog() {
        this._missingReleaseChecks = 0;
        // Clutter can occasionally lose BUTTON_RELEASE on X11. The pointer
        // modifier mask independently tells us whether button 1 is still held.
        // Unlike the old 30-second safety stop this recovers within ~300 ms.
        this._dragWatchId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, DRAG_WATCH_MS, () => {
            if (this._disposed || !this._drag) {
                this._dragWatchId = 0;
                return GLib.SOURCE_REMOVE;
            }
            try {
                const pointer = global.get_pointer();
                const mask = Clutter.ModifierType.BUTTON1_MASK;
                if (typeof pointer[2] === 'number' && mask !== undefined) {
                    if ((pointer[2] & mask) === 0) this._missingReleaseChecks++;
                    else this._missingReleaseChecks = 0;
                    if (this._missingReleaseChecks >= 2) {
                        global.log('[CinnaFences] Muisknop los zonder release-event; herstelt muisstatus');
                        this._dragWatchId = 0; // Source is already being dispatched.
                        this._finishPointerAt(pointer[0], pointer[1]);
                        return GLib.SOURCE_REMOVE;
                    }
                }
            } catch (err) { safeError('Controle muisknop', err); }
            return GLib.SOURCE_CONTINUE;
        });
    }
    _finishPointerAt(x, y) {
        const d = this._drag;
        if (!d) return;
        try {
            if (d.moved && d.mode === 'item') {
                // The release handler is running under the original X11 modal
                // pointer grab; do not change file contents until it is gone.
                // Resolve the target section before releasing the grab. The
                // filesystem action itself always runs *after* the grab.
                const target=this.manager && this.manager.dropTargetAt
                    ? this.manager.dropTargetAt(x,y,this) : null;
                const legacy=(!target && this.manager && !this.manager.dropTargetAt &&
                    this.manager.fenceAtPoint) ? this.manager.fenceAtPoint(x,y,this) : null;
                if (target || legacy) this._pendingTransfer = {
                    destination:target ? target.destination : legacy,
                    sectionKey:target ? target.sectionKey : '/',
                    names:d.names || [d.item.name], copy:d.copy, x,y};
                else if (this.config.view.mode==='icons') this._finishItemMoveAt(x, y, d.item);
                else if ((!this.manager || !this.manager.canArrangeAt ||
                    this.manager.canArrangeAt(this,x,y)) && this._localSectionCellAt(x,y))
                    this._finishItemMoveAt(x,y,d.item);
            } else if (!d.moved && d.mode === 'item' && d.ctrlClick && d.preselected) {
                this._toggleSelectedItem(d.item);
            } else if (d.moved && d.mode !== 'item') this._save();
        } finally {
            this._endPointer();
            if (this._pendingTransfer) {
                const transfer = this._pendingTransfer;
                this._pendingTransfer = null;
                // This runs after the grab is released, avoiding re-entrant
                // monitors and a stuck mouse after a cross-Fence move.
                GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                    if (!this._disposed && !transfer.destination._disposed)
                        this._transferItemToFence(transfer);
                    return GLib.SOURCE_REMOVE;
                });
            }
        }
    }
    _setPointerMode(mode,e,item) {
        if (this._drag) this._endPointer();
        const [sx,sy] = e.get_coords();
        // A disconnected monitor can temporarily display this Fence elsewhere.
        // Start the next intentional move from its actual screen location.
        const initialX = mode==='item' ? this.config.geometry.x : this.actor.x;
        const initialY = mode==='item' ? this.config.geometry.y : this.actor.y;
        this._drag = {mode, sx, sy, x:initialX, y:initialY,
            width:this.config.geometry.width, height:this.config.geometry.height, item, moved:false};
        // A moving/resizing Fence must never itself own the pointer grab.
        // Use a separate stable event actor, like Cinnamon's dnd.js.
        const grabActor = new Clutter.Actor({width:0, height:0, reactive:true});
        Main.uiGroup.add_actor(grabActor);
        this._modalActor = grabActor;
        try {
            this._dragEventId = grabActor.connect('event', (_actor,ev) => {
                try { return this._stageEvent(ev); }
                catch (err) {
                    safeError('Muisactie afgebroken', err);
                    this._endPointer();
                    return Clutter.EVENT_STOP;
                }
            });
            // Modal sends events across the entire desktop to Cinnamon's stage.
            // If this fails, don't start a half-working drag and don't leave a grab behind.
            this._modalActive = Main.pushModal(grabActor,
                e.get_time(), undefined, Cinnamon.ActionMode.NORMAL,
                () => this._endPointer());
            if (!this._modalActive) throw new Error('Cinnamon weigerde de muis-grab');
            this._dragDevice = e.get_device();
            this._dragDevice.grab(grabActor);
            this._startDragWatchdog();
            // One-shot emergency release to avoid a stuck desktop when an X11
            // input device unexpectedly drops the button-release event.
            this._dragSafetyTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 30, () => {
                this._dragSafetyTimer = 0;
                if (this._drag) {
                    global.log('[CinnaFences] Veiligheidsstop voor lang openstaande muisactie');
                    const [x, y] = global.get_pointer();
                    this._finishPointerAt(x, y);
                }
                return GLib.SOURCE_REMOVE;
            });
        } catch (err) {
            safeError('Kan muis niet betrouwbaar vasthouden', err);
            this._endPointer();
            return;
        }
        // Freeze the active appearance during a drag; the pointer will be
        // reassessed after releasing the modal grab.
        this.hovered = true;
        this._style(true);
        if (mode === 'move') this._setCursor('MOVE');
        else if (mode.startsWith('resize:')) this._setCursor(CURSOR_FOR_EDGE[mode.slice(7)]);
    }
    _startItemPreview(d, x, y) {
        // A non-reactive Clutter.Clone follows the pointer outside the
        // original clipped grid. The real actor remains at its source cell.
        try {
            const item = d.item;
            const [ix,iy] = item.actor.get_transformed_position();
            d.previewOffsetX = clamp(d.sx - ix, 0, item.actor.width);
            d.previewOffsetY = clamp(d.sy - iy, 0, item.actor.height);
            d.preview = new Clutter.Clone({source:item.actor, reactive:false});
            d.preview.set_size(item.actor.width, item.actor.height);
            d.preview.opacity = 230;
            Main.uiGroup.add_actor(d.preview);
            d.preview.raise_top();
            if (d.names && d.names.length > 1) {
                d.previewCount=new St.Label({text:(d.copy?'Copy ':'')+String(d.names.length),
                    style:'background-color:#284b70;color:white;border-radius:10px;padding:3px 8px;'});
                Main.uiGroup.add_actor(d.previewCount);
                d.previewCount.raise_top();
            }
            this._moveItemPreview(d,x,y);
        } catch (err) {
            safeError('Versleepvoorbeeld maken',err);
            if (d.preview) {try {d.preview.destroy();} catch (_) {}}
            d.preview=null;
        }
    }
    _moveItemPreview(d,x,y) {
        if (!d.preview) return;
        d.preview.set_position(Math.round(x-d.previewOffsetX),
            Math.round(y-d.previewOffsetY));
        if (d.previewCount) d.previewCount.set_position(Math.round(x+12),Math.round(y-28));
        if (d.dropHint) d.dropHint.set_position(Math.round(x+14),Math.round(y+20));
    }
    _updateDropHint(d,x,y) {
        if (!this.manager || !this.manager.dropTargetAt) return;
        const now=GLib.get_monotonic_time();
        if (d.lastDropCheck && now-d.lastDropCheck<60000) return;
        d.lastDropCheck=now;
        const target=this.manager.dropTargetAt(x,y,this);
        if (!target) {
            if (d.dropHint) d.dropHint.hide();
            return;
        }
        const title=(d.copy?'Copy to ':'Move to ')+target.destination.config.title+
            (target.sectionKey==='/'?'':' / '+target.sectionKey);
        if (!d.dropHint) {
            d.dropHint=new St.Label({style:'background-color:#244d72;color:white;'+
                'border-radius:6px;padding:4px 7px;',text:title});
            Main.uiGroup.add_actor(d.dropHint);
            d.dropHint.raise_top();
        } else {
            d.dropHint.set_text(title);
            d.dropHint.show();
        }
        d.dropHint.set_position(Math.round(x+14),Math.round(y+20));
    }
    _endPointer() {
        const d=this._drag;
        // Remove the visual drag proxy even on Escape or a lost release event.
        if (d && d.preview) {
            try { d.preview.destroy(); } catch (_) {}
            d.preview=null;
        }
        if (d && d.previewCount) {
            try { d.previewCount.destroy(); } catch (_) {}
            d.previewCount=null;
        }
        if (d && d.dropHint) {
            try { d.dropHint.destroy(); } catch (_) {}
            d.dropHint=null;
        }
        if (d && d.mode === 'item' && d.item && d.item.actor)
            d.item.actor.opacity=255;
        this._drag=null;
        if (this._dragWatchId) {
            GLib.source_remove(this._dragWatchId);
            this._dragWatchId = 0;
        }
        this._missingReleaseChecks = 0;
        if (this._dragSafetyTimer) {
            GLib.source_remove(this._dragSafetyTimer);
            this._dragSafetyTimer=0;
        }
        if (this._dragDevice) {
            try {this._dragDevice.ungrab();} catch (_) {}
            this._dragDevice=null;
        }
        const modalActor = this._modalActor;
        this._modalActor=null;
        if (modalActor && this._dragEventId) {
            try {modalActor.disconnect(this._dragEventId);} catch (_) {}
        }
        this._dragEventId=0;
        if (modalActor && this._modalActive) {
            this._modalActive=false;
            try {Main.popModal(modalActor);} catch (err) { safeError('Cinnamon modal opruimen', err); }
        }
        this._modalActive=false;
        if (modalActor) {
            try {modalActor.destroy();} catch (_) {}
        }
        this._clearCursor();
        try {global.sync_pointer();} catch (_) {}
        // A modal grab can suppress Clutter's enter/leave transitions. Resync
        // hover on the next idle turn, after the grab has been released.
        if (!this._disposed && this.actor && !this._hoverRecoveryId) {
            this._hoverRecoveryId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._hoverRecoveryId = 0;
                if (!this._disposed && !this._drag) {
                    try {
                        const [x,y] = global.get_pointer();
                        this._syncHoverFromPointer(x, y, 'drag-end');
                    } catch (_) { /* Pointer may be temporarily unavailable. */ }
                }
                return GLib.SOURCE_REMOVE;
            });
        }
    }
    _sectionDropAt(x,y) {
        if (this._disposed || this.config.collapsed || !this._pointerInside(x,y)) return null;
        const mode=this.config.view.mode;
        const pointInside=(actor)=>{
            if (!actor || !actor.visible || !actor.get_transformed_position) return false;
            const [ax,ay]=actor.get_transformed_position();
            return x>=ax && y>=ay && x<ax+actor.width && y<ay+actor.height;
        };
        if (mode==='icons') return '/'; // Entire visible Fence is a drop target, including its header.
        for (const entry of this._navButtons) {
            // Clipped Rolodex bars may physically extend under the header.
            // They must not receive a drop outside their visible viewport.
            if ((entry.inHeader || pointInside(this.content)) && pointInside(entry.actor))
                return entry.key;
        }
        if (!pointInside(this.content)) return null;
        if (mode==='tabs') return this._activeSection || null;
        if (mode==='rolodex' && this._activeSection && this._activeSection!=='') {
            const current=this._navButtons.find(n=>n.key===this._activeSection);
            if (!current) return null;
            const [cx,cy]=this.content.get_transformed_position();
            const localY=y-cy+this.scroll;
            const next=this._navButtons.find(n=>n.y>current.y);
            const sectionEnd=next ? next.y : Math.max(this._contentLength, this._gridOriginY+
                (this.items.reduce((max,it)=>Math.max(max,it.row),-1)+1)*this.config.icons.gridHeight+5);
            if (localY>=current.y+current.height && localY<sectionEnd) return current.key;
        }
        return null; // Not an opened section: don't guess which folder to use.
    }
    _isNavigationSource(source) {
        return !!(source && (this._navButtons || []).some(entry=>
            source===entry.actor || source===entry.label ||
            (entry.actor.contains && entry.actor.contains(source))));
    }
    _isHeaderTabSource(source) {
        return this.config && this.config.view && this.config.view.mode==='tabs' &&
            (this._navButtons || []).some(entry=>
            entry.inHeader && (source===entry.actor || source===entry.label ||
                (source && entry.actor.contains && entry.actor.contains(source))));
    }
    _headerDown(e) {
        const source=e.get_source();
        if (source === this.arrow || source === this.arrowIcon || this._isHeaderTabSource(source))
            return Clutter.EVENT_PROPAGATE;
        if (e.get_button() === 3) return this._contextDown(e);
        if (e.get_button() !== 1) return Clutter.EVENT_PROPAGATE;
        const edge = this._edgeName(e);
        if (edge && !this.config.collapsed) {
            this._setPointerMode('resize:'+edge,e,null); return Clutter.EVENT_STOP;
        }
        if (e.get_click_count() >= 2) { this.toggleCollapsed(); return Clutter.EVENT_STOP; }
        if (this.config.geometryLocked) return Clutter.EVENT_STOP;
        this._clearItemStates();
        this._setPointerMode('move',e,null); return Clutter.EVENT_STOP;
    }
    _edgeName(e) {
        if (this.config.geometryLocked) return '';
        const [sx,sy] = e.get_coords();
        const [x,y] = this.actor.get_transformed_position();
        const xx = sx-x, yy = sy-y;
        if (xx < 0 || yy < 0 || xx > this.actor.width || yy > this.actor.height) return '';
        const left = xx < EDGE, right = xx > this.actor.width-EDGE;
        // A hidden header is only 14px high. Keep its full middle region
        // available for moving instead of making 12px of it a resize edge.
        const top = yy < EDGE && (!this.config.header || this.config.header.show !== false);
        const bottom = yy > this.actor.height-EDGE &&
            !(this.config.view && this.config.view.mode==='rolodex' && this.config.view.autoFitHeight);
        return (top?'n':bottom?'s':'')+(left?'w':right?'e':'');
    }
    _boundaryCapture(e) {
        if (this._drag || this.config.collapsed) return Clutter.EVENT_PROPAGATE;
        const type = e.type();
        if (type !== Clutter.EventType.MOTION && type !== Clutter.EventType.BUTTON_PRESS)
            return Clutter.EVENT_PROPAGATE;
        // The headerless Fence has no invisible strip covering its first bar.
        // Use Alt+left-drag anywhere instead, without breaking normal clicks.
        if (type===Clutter.EventType.BUTTON_PRESS && e.get_button()===1 &&
            this.config.header && this.config.header.show===false && !this.config.geometryLocked &&
            this._altDown(e)) {
            this._clearItemStates();
            this._setPointerMode('move',e,null);
            return Clutter.EVENT_STOP;
        }
        if (this._isNavigationSource(e.get_source && e.get_source())) return Clutter.EVENT_PROPAGATE;
        const edge = this._edgeName(e);
        if (type === Clutter.EventType.MOTION) {
            this._setCursor(edge ? CURSOR_FOR_EDGE[edge] : null);
            return Clutter.EVENT_PROPAGATE;
        }
        if (e.get_button() === 1 && edge) {
            this._clearItemStates();
            this._setPointerMode('resize:' + edge,e,null);
            return Clutter.EVENT_STOP;
        }
        return Clutter.EVENT_PROPAGATE;
    }
    _edgeHover(e) {
        if (this._drag) return Clutter.EVENT_PROPAGATE;
        const edge = this.config.collapsed ? '' : this._edgeName(e);
        this._setCursor(edge ? CURSOR_FOR_EDGE[edge] : null);
        return Clutter.EVENT_PROPAGATE;
    }
    _edgeDown(e) {
        if (this._isNavigationSource(e.get_source && e.get_source()))
            return Clutter.EVENT_PROPAGATE;
        if (e.get_button() === 3) return this._contextDown(e);
        if (e.get_button() !== 1 || this.config.collapsed) return Clutter.EVENT_PROPAGATE;
        const edge = this._edgeName(e);
        if (edge) { this._setPointerMode('resize:'+edge,e,null); return Clutter.EVENT_STOP; }
        return Clutter.EVENT_PROPAGATE;
    }
    _itemDown(item,e) {
        if (e.get_button() === 3) {
            if (!item.selected) this._selectItem(item);
            return this._contextDown(e,true);
        }
        if (e.get_button() !== 1) return Clutter.EVENT_PROPAGATE;
        if (e.get_click_count() >= 2) {
            this._clearItemStates();
            this._launchPath(item.path, item.path.endsWith('.desktop'));
            return Clutter.EVENT_STOP;
        }
        // In folder-driven views, the rendered icon names already carry their
        // direct parent section (e.g. "Slicers/X1.desktop"). Selection, copy and
        // the existing drag grab now work exactly as in Icons view.
        const state=typeof e.get_state==='function'?e.get_state():0;
        const ctrl=!!(state & Clutter.ModifierType.CONTROL_MASK);
        const wasSelected=item.selected;
        const shift=!!(state & Clutter.ModifierType.SHIFT_MASK);
        if (shift) {
            this._selectRangeTo(item,ctrl);
            return Clutter.EVENT_STOP;
        }
        if (!ctrl && !item.selected) this._selectItem(item);
        if (ctrl && !item.selected) {
            // Add it now so Ctrl+drag of an unselected icon includes it.
            item.selected=true; this._selectionAnchor=item; this.selectedItem=item;
            this._paintItem(item);
        }
        this._setPointerMode('item',e,item);
        if (this._drag) {
            this._drag.ctrlClick=ctrl;
            this._drag.preselected=wasSelected;
            this._drag.copy=ctrl;
            this._drag.names=this.items.filter(it=>it.selected).map(it=>it.name);
        }
        return Clutter.EVENT_STOP;
    }
    _workAreaForPointer(sx, sy) {
        // Prefer the current monitor's usable work area, not the full stage.
        // Keeping the titlebar outside a top panel is what makes it impossible
        // to catch again after dragging to the top of the screen.
        try {
            const monitors = Main.layoutManager.monitors;
            let index = monitors.findIndex(m => sx >= m.x && sy >= m.y &&
                sx < m.x+m.width && sy < m.y+m.height);
            if (index < 0) index = Main.layoutManager.primaryIndex;
            if (index < 0 || index >= monitors.length) index=0;
            const area = global.workspace_manager.get_active_workspace().get_work_area_for_monitor(index);
            if (area && area.width > 0 && area.height > HEADER_H) return area;
            if (monitors[index]) return monitors[index];
        } catch (_) { /* Fallback for older releases */ }
        return {x:0,y:0,width:global.stage.width,height:global.stage.height};
    }
    _altDown(event) {
        return typeof event.get_state==='function' &&
            !!(event.get_state() & Clutter.ModifierType.MOD1_MASK);
    }
    _stageEvent(e) {
        if (!this._drag) return Clutter.EVENT_PROPAGATE;
        if (e.type() === Clutter.EventType.KEY_PRESS && e.get_key_symbol() === Clutter.KEY_Escape) {
            // Cancellation restores the beginning geometry without writing anything.
            const d = this._drag;
            if (d.mode !== 'item') {
                Object.assign(this.config.geometry,{x:d.x,y:d.y,width:d.width,height:d.height});
                this.actor.set_position(d.x,d.y); this._sizeActors(); this._layoutItems();
            }
            this._endPointer(); return Clutter.EVENT_STOP;
        }
        if (e.type() === Clutter.EventType.BUTTON_RELEASE && e.get_button() === 1) {
            const [x,y] = e.get_coords();
            if (this._drag && this._drag.mode==='item' && typeof e.get_state==='function')
                this._drag.copy=!!(e.get_state() & Clutter.ModifierType.CONTROL_MASK);
            this._finishPointerAt(x,y);
            return Clutter.EVENT_STOP;
        }
        if (e.type() !== Clutter.EventType.MOTION) return Clutter.EVENT_PROPAGATE;
        const d = this._drag, [x,y] = e.get_coords();
        let dx = x-d.sx, dy = y-d.sy;
        if (Math.abs(dx)+Math.abs(dy) < 4 && !d.moved) return Clutter.EVENT_STOP;
        d.moved = true;
        if (d.mode === 'item') {
            if (typeof e.get_state==='function') d.copy=!!(e.get_state() & Clutter.ModifierType.CONTROL_MASK);
            if (d.previewCount) d.previewCount.set_text((d.copy?'Copy ':'')+String(d.names.length));
            if (!d.preview) this._startItemPreview(d,x,y);
            else this._moveItemPreview(d,x,y);
            this._updateDropHint(d,x,y);
            return Clutter.EVENT_STOP;
        }
        const geo = this.config.geometry;
        if (d.mode === 'move') {
            const work=this._workAreaForPointer(x,y);
            const maxX=Math.max(work.x, work.x+work.width-Math.min(geo.width,work.width));
            const maxY=Math.max(work.y, work.y+work.height-Math.min(this.actor.height || geo.height,work.height));
            geo.x = clamp(Math.round(d.x+dx), work.x, maxX);
            geo.y = clamp(Math.round(d.y+dy), work.y, maxY);
            const snapped=snapMoveRect(Object.assign({},geo,{height:this.actor.height || geo.height}),work,
                this.manager?this.manager.snapNeighbors(this):[],
                this.manager?this.manager.snapSettings:SNAP_DEFAULTS, this._altDown(e));
            geo.x=snapped.x;geo.y=snapped.y;
            this.actor.set_position(geo.x,geo.y);
        } else if (d.mode.startsWith('resize:')) {
            const edge = d.mode.slice(7);
            const w = edge.includes('w'), n = edge.includes('n');
            geo.width = clamp(Math.round(d.width+(w?-dx:edge.includes('e')?dx:0)),MIN_W,2400);
            geo.height = clamp(Math.round(d.height+(n?-dy:edge.includes('s')?dy:0)),MIN_H,1600);
            geo.x = Math.round(d.x+(w?d.width-geo.width:0));
            geo.y = Math.round(d.y+(n?d.height-geo.height:0));
            if (w || n) {
                const work=this._workAreaForPointer(x,y);
                if (w && geo.x < work.x) {
                    geo.x=work.x;
                    geo.width=clamp(d.x+d.width-geo.x,MIN_W,2400);
                }
                if (n && geo.y < work.y) {
                    geo.y=work.y;
                    geo.height=clamp(d.y+d.height-geo.y,MIN_H,1600);
                }
            }
            const snapped=snapResizeRect(geo,edge,this._workAreaForPointer(x,y),
                this.manager?this.manager.snapNeighbors(this):[],
                this.manager?this.manager.snapSettings:SNAP_DEFAULTS,this._altDown(e));
            Object.assign(geo,snapped);
            this.actor.set_position(geo.x,geo.y);
            const oldCols = this._renderColumns === undefined ? columns(d.width,this.config.icons.gridWidth) : this._renderColumns;
            this._sizeActors();
            const newCols = columns(geo.width,this.config.icons.gridWidth);
            if (newCols !== oldCols) { this._renderColumns = newCols; this._layoutItems(); }
            else this._placeItems();
        }
        return Clutter.EVENT_STOP;
    }
    _transferItemToFence({destination, sectionKey='/', names, copy=false, x, y}) {
        if (!destination || destination._disposed || destination.config.collapsed ||
            this._disposed || !names || !names.length) return false;
        let entries;
        try {
            entries=planSectionTransfer(this.folder,destination.folder,names,sectionKey,copy);
        } catch (e) {
            // Dropping onto the originating section is a no-op, not a file move.
            if (String(e.message||e).includes('Choose a different Fence')) return false;
            Main.notify('CinnaFences',String(e.message || e));
            return false;
        }
        const result=executeFenceTransfer(entries,copy);
        if (!result.ok) {
            safeError('Fence transfer failed',result.error);
            Main.notify('CinnaFences','Transfer failed: '+String(result.error.message || result.error) +
                (result.rollbackErrors.length?' | Manual recovery needed: '+result.rollbackErrors.join('; '):''));
            return false;
        }
        // Keys in the icon position map are relative to each Fence root, NOT
        // leaf names. Thus the same "file.desktop" can occur in two sections.
        const sourceCells={};
        for (const entry of entries) {
            const found=this.items.find(it=>it.name===entry.sourceKey);
            if (found) sourceCells[entry.sourceKey]=[found.col,found.row];
        }
        if (!copy) {
            for (const entry of entries) delete this.config.icons.positions[entry.sourceKey];
            this.config.icons.undoArrangement=null;
            this._save();
        }
        const g=destination.config.icons;
        const cols=columns(destination.config.geometry.width,g.gridWidth);
        const occupied=new Set(Object.entries(g.positions).filter(([key])=>
            sectionKey==='/' ? !key.includes('/') : key.startsWith(sectionKey+'/'))
            .map(([,pos])=>Array.isArray(pos)?pos[1]*1000+pos[0]:-1));
        // Existing visible icons can have transient default cells absent from
        // the persisted map. Protect those cells as well.
        const activeKeys=new Set(destination.items.filter(it=>
            sectionKey==='/' ? !it.name.includes('/') : it.name.startsWith(sectionKey+'/'))
            .map(it=>it.row*1000+it.col));
        for (const key of activeKeys) occupied.add(key);
        let idx=0;
        for (const entry of entries) {
            while (occupied.has(Math.floor(idx/cols)*1000+idx%cols)) idx++;
            const col=idx%cols,row=Math.floor(idx/cols);
            g.positions[entry.destKey]=[col,row];
            occupied.add(row*1000+col);
            idx++;
        }
        g.layoutColumns=cols;
        g.undoArrangement=null;
        destination._save();
        this.manager.lastTransfer={copy,entries,sourceFolder:this.folder,
            targetFolder:destination.folder,sourceCells};
        this.manager.queueScan(this.folder);
        if (destination!==this) this.manager.queueScan(destination.folder);
        if (destination.config.view.mode!=='icons' && destination._activeSection!==sectionKey &&
            typeof destination._activateSection==='function') destination._activateSection(sectionKey);
        Main.notify('CinnaFences',(copy?'Copied ':'Moved ')+names.length+' item(s) to '+
            destination.config.title+(sectionKey==='/'?'':' / '+sectionKey)+
            ' — Undo available in Fence context menu');
        return true;
    }
    _localSectionCellAt(sx,sy) {
        // Use the actual content coordinates, not the legacy 32px header offset.
        // A Rolodex grid may start below several closed section bars, and a
        // headerless Fence has no reserved header height at all.
        if (this._disposed || this.config.collapsed ||
            this.config.view.mode==='icons' || !this._activeSection ||
            !this._pointerInside(sx,sy)) return null;
        const content=this.content;
        if (!content || !content.visible) return null;
        const [cx,cy]=content.get_transformed_position();
        if (sx<cx || sy<cy || sx>=cx+content.width || sy>=cy+content.height)
            return null;
        // Never rearrange over a tab or a Rolodex section bar.
        for (const nav of this._navButtons) {
            if (!nav.actor.visible) continue;
            const [nx,ny]=nav.actor.get_transformed_position();
            if (sx>=nx && sy>=ny && sx<nx+nav.actor.width && sy<ny+nav.actor.height)
                return null;
        }
        // Only the currently opened section owns these icon cells.
        if (this._sectionDropAt(sx,sy)!==this._activeSection) return null;
        const gx=cx+(this.config.view.mode==='rolodex'?8:0);
        const gy=cy+this._gridOriginY-this.scroll;
        if (sy<gy || sx<gx) return null;
        const conf=this.config.icons;
        const cols=columns(this.config.geometry.width,conf.gridWidth);
        const col=clamp(Math.floor((sx-gx)/conf.gridWidth),0,cols-1);
        const row=clamp(Math.floor((sy-gy)/conf.gridHeight),0,9999);
        return {col,row,cols};
    }
    _storeActiveGrid(positions,cols) {
        const conf=this.config.icons;
        if (this.config.view.mode==='icons') conf.layoutColumns=cols;
        else {
            if (!conf.sectionLayoutColumns) conf.sectionLayoutColumns={};
            conf.sectionLayoutColumns[this._activeSection]=cols;
        }
        // Never discard positions belonging to other tabs/sections (or icons
        // visible only in the classic view) during a local arrangement.
        Object.assign(conf.positions,positions);
        conf.undoArrangement=null;
        this._layoutItems();
        this._save();
    }
    _finishItemMoveAt(sx,sy,item) {
        item.actor.opacity = 255;
        const selected=this.items.filter(it=>it.selected);
        const sectionCell=this.config.view.mode==='icons' ? null : this._localSectionCellAt(sx,sy);
        if (this.config.view.mode!=='icons' && !sectionCell) return;
        if (item.selected && selected.length>1) {
            const [ax,ay]=this.actor.get_transformed_position();
            const g=this.config.icons;
            const cols=sectionCell ? sectionCell.cols : columns(this.config.geometry.width,g.gridWidth);
            const startCol=sectionCell ? sectionCell.col :
                clamp(Math.floor((sx-ax-PAD)/g.gridWidth),0,cols-1);
            const startRow=sectionCell ? sectionCell.row :
                clamp(gridRowAtPointer(sy,ay,this.scroll,g.gridHeight),0,9999);
            const positions={};
            for (const it of this.items) positions[it.name]=[it.col,it.row];
            const used=new Set(this.items.filter(it=>!it.selected).map(it=>it.row*1000+it.col));
            let idx=startRow*cols+startCol;
            for (const it of selected.sort((a,b)=>a.row-b.row || a.col-b.col)) {
                while (used.has(Math.floor(idx/cols)*1000+idx%cols)) idx++;
                const col=idx%cols,row=Math.floor(idx/cols);
                positions[it.name]=[col,row];used.add(row*1000+col);idx++;
            }
            const changed=selected.some(it=>it.col!==positions[it.name][0] || it.row!==positions[it.name][1]);
            if (!changed) return;
            this._storeActiveGrid(positions,cols);
            return;
        }
        const [ax,ay] = this.actor.get_transformed_position();
        const g = this.config.icons;
        const cols = sectionCell ? sectionCell.cols : columns(this.config.geometry.width,g.gridWidth);
        const col = sectionCell ? sectionCell.col :
            clamp(Math.floor((sx-ax-PAD)/g.gridWidth),0,cols-1);
        const row = sectionCell ? sectionCell.row :
            clamp(gridRowAtPointer(sy,ay,this.scroll,g.gridHeight),0,9999);
        const oldCol=item.col, oldRow=item.row;
        if (oldCol===col && oldRow===row) return;
        // A manual move promotes the currently displayed reflow into the new
        // canonical layout, so later resizing restores exactly this layout.
        const positions = {};
        for (const it of this.items) positions[it.name]=[it.col,it.row];
        const other=this.cells.get(row*1000+col);
        positions[item.name]=[col,row];
        if (other && other !== item) positions[other.name]=[oldCol,oldRow];
        this._storeActiveGrid(positions,cols);
    }
    _save(persistGeometryLock=false) {
        try { writeConfig(this.folder,this.config,persistGeometryLock); }
        catch (e) { safeError('Config opslaan: '+this.folder,e); Main.notify('CinnaFences','Opslaan van Fence-instellingen mislukt'); }
    }
    _applyArrangement(names) {
        if (this._disposed || this._drag || names.length !== this.items.length) return false;
        const cols = columns(this.config.geometry.width,this.config.icons.gridWidth);
        // A no-op must NOT replace an already saved undo snapshot.
        // In Tabs/Rolodex, other subfolders keep their own icon positions.
        const newPositions = this.config.view.mode==='icons' ? {} :
            deepCopy(this.config.icons.positions);
        names.forEach((name,index) => { newPositions[name]=[index%cols,Math.floor(index/cols)]; });
        const sectionMode=this.config.view.mode!=='icons';
        const currentCols=sectionMode ?
            (this.config.icons.sectionLayoutColumns || {})[this._activeSection] :
            this.config.icons.layoutColumns;
        const unchanged = currentCols === cols &&
            this.items.every(item => item.col===newPositions[item.name][0] &&
                item.row===newPositions[item.name][1]);
        if (unchanged) return false;
        this.config.icons.undoArrangement = {
            positions: deepCopy(this.config.icons.positions),
            layoutColumns: this.config.icons.layoutColumns || cols,
            sectionLayoutColumns: deepCopy(this.config.icons.sectionLayoutColumns || {})
        };
        this.config.icons.positions=newPositions;
        if (sectionMode) {
            if (!this.config.icons.sectionLayoutColumns) this.config.icons.sectionLayoutColumns={};
            this.config.icons.sectionLayoutColumns[this._activeSection]=cols;
        } else this.config.icons.layoutColumns=cols;
        this.scroll=0;
        this._layoutItems();
        this._save();
        return true;
    }
    sortAlphabetically() {
        const labels = new Map(this.items.map(it=>[it.name,it.label.text]));
        const list = [...this._names].sort((a,b)=>
            (labels.get(a)||a).localeCompare(labels.get(b)||b,'en',{sensitivity:'base'}));
        return this._applyArrangement(list);
    }
    compactIcons() {
        // All icon cells are already grid-aligned. "Compact" removes gaps,
        // retaining the current visible visual order rather than sorting.
        const list = [...this.items].sort((a,b)=>
            a.row-b.row || a.col-b.col || a.name.localeCompare(b.name));
        return this._applyArrangement(list.map(item=>item.name));
    }
    restoreArrangement() {
        if (this._disposed || this._drag || !this.config.icons.undoArrangement) return false;
        const previous = this.config.icons.undoArrangement;
        this.config.icons.positions = deepCopy(previous.positions);
        this.config.icons.layoutColumns = previous.layoutColumns;
        this.config.icons.sectionLayoutColumns = deepCopy(previous.sectionLayoutColumns || {});
        this.config.icons.undoArrangement = null; // exactly one undo step
        this.scroll=0;
        this._layoutItems();
        this._save();
        return true;
    }
    toggleGeometryLock() {
        if (this._disposed || this._drag) return;
        this.config.geometryLocked = !this.config.geometryLocked;
        this._save(true);
        this._refreshMenuActions();
    }
    toggleCollapsed() { this.config.collapsed=!this.config.collapsed; this._sizeActors(); this._layoutItems(); this._save(); }
    updateConfig(config) {
        if (this._drag) return;
        const changed = JSON.stringify(this.config)!==JSON.stringify(config);
        if (changed) {
            this.config=config;
            if (config.hidden || (this.manager && !this.manager.fencesVisible)) {
                if (this._clearInputPieces) this._clearInputPieces();
                if (this.actor.hide) this.actor.hide();
            } else if (this.actor.show) this.actor.show();
            this.title.set_text(config.title);
            this.actor.set_position(config.geometry.x,config.geometry.y);
            this._refreshMenuActions();
            this.rebuild();
        }
    }
    destroy() {
        this._disposed=true;
        this._contextPending=null;
        if (this._contextOpenIdle) {
            GLib.source_remove(this._contextOpenIdle);
            this._contextOpenIdle=0;
        }
        if (this._hoverRecoveryId) {
            GLib.source_remove(this._hoverRecoveryId);
            this._hoverRecoveryId = 0;
        }
        this._endPointer();
        if (this.menu) { this.menu.destroy(); this.menu=null; }
        if (this._menuAnchor) { this._menuAnchor.destroy(); this._menuAnchor=null; }
        if (this.actor) {
            this._clearInputPieces();
            if (this._allocationChangedId) {
                try { this.actor.disconnect(this._allocationChangedId); } catch (_) {}
                this._allocationChangedId=0;
            }
            this.actor.destroy();
            this.actor=null;
        }
    }
}

// Keep stage-motion work local to Fences. Unhover an already-hovered Fence
// once when the pointer leaves it, but do not repaint or recompute X11 input
// regions for motion over unrelated parts of the desktop.
function syncStageFenceHover(fences, x, y) {
    let nearFence=false;
    for (const fence of fences) {
        if (fence._disposed || fence.config.hidden || !fence.actor || !fence.actor.visible)
            continue;
        const inside=fence._pointerInside(x,y);
        if (inside || fence.hovered) {
            if (inside) nearFence=true;
            fence._setHovered(inside,'stage');
        }
    }
    return nearFence;
}

class FenceManager {
    constructor() {
        this.lastTransfer=null;
        this.fencesVisible=true; // session-only; reset on extension restart
        this._registeredHotkey=null;
        this._attemptedHotkey=null;
        this._monitorLayoutIdle=0;
        const settings=readGlobalSettings();
        this.hotkeySettings=normalizeHotkeySettings(settings.hotkeys);
        this.snapSettings=normalizeSnapSettings(settings.snapping);
        this.desktop=pathJoin(GLib.get_home_dir(),'Desktop');
        this.fences=new Map();
        this.monitors=new Map();
        this.sectionMonitors=new Map();
        this.timer=0;
        this.dead=false;
        this._refreshRequested=new Set();
        this._desktopMonitor=null;
        this._globalMonitor=null;
        this._inputRegionIdle=0;
        this._windowSignals=[];
        this._windowWatch=new Map();
        this._windowActorWatch=new Map();
        this._lastPointerRegionCheck=0;
        // Recalculate only after window creation, stacking, geometry changes,
        // workspace switches or Fence allocation changes. No permanent timer.
        this._connectWindowSignal(global.display, 'restacked', ()=>this.queueInputRegions());
        // A newly mapped application may become visible *after* window-created.
        // Focus / actor allocation are more reliable at that point than MetaWindow
        // position/size signals alone, especially on Cinnamon 6.6 / X11.
        this._connectWindowSignal(global.display, 'notify::focus-window', ()=>this.queueInputRegions());
        this._connectWindowSignal(global.window_group, 'actor-added', (_group,actor)=>{
            if (actor.meta_window) {
                this._watchWindow(actor.meta_window);
                this._watchWindowActor(actor);
            }
            this.queueInputRegions();
        });
        this._connectWindowSignal(global.display, 'window-created', (_d,w)=>{
            this._watchWindow(w);
            this.queueInputRegions();
        });
        this._connectWindowSignal(global.display, 'grab-op-end', ()=>this.queueInputRegions());
        this._connectWindowSignal(global.window_manager, 'switch-workspace', ()=>this.queueInputRegions());
        // Monitor geometry changes need no timer or writing to Fence configs.
        this._connectWindowSignal(Main.layoutManager, 'monitors-changed', ()=>this.queueMonitorLayout());
        try {
            for (const actor of global.get_window_actors()) {
                if (actor.meta_window) this._watchWindow(actor.meta_window);
                this._watchWindowActor(actor);
            }
        } catch (e) { safeError('Window input tracking',e); }
        try {
            GLib.mkdir_with_parents(GLOBAL_DIR, 0o700);
            this._globalMonitor=Gio.File.new_for_path(GLOBAL_DIR)
                .monitor_directory(Gio.FileMonitorFlags.NONE,null);
            this._globalMonitor.connect('changed',(_m,file,other)=>{
                if (this.dead) return;
                const a=file ? file.get_basename() : '';
                const b=other ? other.get_basename() : '';
                if (a===GLOBAL_NAME || b===GLOBAL_NAME) this.queueScan();
                // The virtual Fence's settings live next to defaults.json,
                // not inside ~/Desktop. Editing them in Per Fence must take
                // effect immediately, including the first configuration save.
                else if (a===UNASSIGNED_NAME || b===UNASSIGNED_NAME)
                    this.queueScan(this.desktop);
            });
        } catch (e) { safeError('General defaults monitor',e); }
        // One geometry-based hover predicate; no event source checks, stage
        // picking or periodic polling. Crossings on the Fence itself provide
        // additional coverage when the pointer leaves the Cinnamon stage.
        this._stageHoverId = global.stage.connect('captured-event', (_actor, event) => {
            const t = event.type();
            if (t !== Clutter.EventType.MOTION && t !== Clutter.EventType.BUTTON_PRESS &&
                t !== Clutter.EventType.SCROLL)
                return Clutter.EVENT_PROPAGATE;
            // Stage-wide motion can be frequent. Keep the late-window-map
            // input safety fallback, but only when the pointer can intersect
            // a Fence. Geometry/window signals still update regions globally.
            // An already-hovered Fence also needs one event to clear hover.
            const [x, y] = event.get_coords();
            const nearFence=syncStageFenceHover(this.fences.values(),x,y);
            if (nearFence && (t===Clutter.EventType.MOTION || t===Clutter.EventType.BUTTON_PRESS)) {
                const now=GLib.get_monotonic_time();
                if (t===Clutter.EventType.BUTTON_PRESS ||
                    now-this._lastPointerRegionCheck >= 100000) {
                    this._lastPointerRegionCheck=now;
                    this.queueInputRegions();
                }
            }
            return Clutter.EVENT_PROPAGATE;
        });
        if (!GLib.file_test(this.desktop,GLib.FileTest.IS_DIR)) {
            Main.notify('CinnaFences','Geen Desktop-map gevonden: '+this.desktop);
            return;
        }
        try {
            this._desktopMonitor=Gio.File.new_for_path(this.desktop).monitor_directory(Gio.FileMonitorFlags.NONE,null);
            this._desktopMonitor.connect('changed',()=>this.queueScan(this.fences.has(this.desktop) ? this.desktop : null));
        } catch(e) { safeError('Desktop monitor',e); }
        this.scan();
    }
    _bindToggleHotkey() {
        const requested=this.hotkeySettings.enabled ? this.hotkeySettings.toggle : null;
        if (requested===this._attemptedHotkey) return;
        // A changed/disabled shortcut must not strand hidden Fences.
        if (this._registeredHotkey && !this.fencesVisible) this.toggleAllFences();
        if (this._registeredHotkey) {
            try { Main.keybindingManager.removeHotKey(HOTKEY_NAME); }
            catch (e) { safeError('Unregister shortcut',e); }
            this._registeredHotkey=null;
        }
        this._attemptedHotkey=requested;
        if (!requested) return;
        try {
            if (!Main.keybindingManager.addHotKey(HOTKEY_NAME,requested,()=>this.toggleAllFences())) {
                Main.notify('CinnaFences', 'Shortcut '+requested+' is unavailable. Change it in General settings.');
                return;
            }
            this._registeredHotkey=requested;
        } catch (e) {
            safeError('Register shortcut',e);
            Main.notify('CinnaFences','Shortcut could not be registered.');
        }
    }
    toggleAllFences() {
        if (this.dead) return;
        // Never hide actors halfway through a filesystem or geometry drag.
        if ([...this.fences.values()].some(f=>f._drag)) return;
        this.fencesVisible=!this.fencesVisible;
        for (const f of this.fences.values()) {
            if (f.menu) { try { f.menu.close(); } catch (_) {} }
            if (this.fencesVisible && !(f.config && f.config.hidden)) f.actor.show();
            else { f._clearInputPieces(); f.actor.hide(); f._clearCursor(); }
        }
        this.queueInputRegions();
    }
    _workAreas() {
        const areas=[];
        const monitors=Main.layoutManager.monitors || [];
        const workspace=global.workspace_manager.get_active_workspace();
        for (let i=0;i<monitors.length;i++) {
            try {
                const a=workspace.get_work_area_for_monitor(i);
                if (a.width>0 && a.height>0) { areas.push(a); continue; }
            } catch (_) {}
            if (monitors[i].width>0 && monitors[i].height>0) areas.push(monitors[i]);
        }
        return areas;
    }
    queueMonitorLayout() {
        if (this.dead || this._monitorLayoutIdle) return;
        this._monitorLayoutIdle=GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE,()=>{
            this._monitorLayoutIdle=0;
            if (this.dead) return GLib.SOURCE_REMOVE;
            this._applyMonitorLayout();
            return GLib.SOURCE_REMOVE;
        });
    }
    _applyMonitorLayout() {
        let areas;
        try { areas=this._workAreas(); } catch (e) { safeError('Monitor layout',e); return; }
        if (!areas.length) return;
        for (const f of this.fences.values()) {
            if (f._disposed || f._drag) continue;
            const g=f.config.geometry;
            const original={x:g.x,y:g.y,width:g.width,height:f.config.collapsed?(typeof f._headerHeight==='function'?f._headerHeight():HEADER_H):g.height};
            const temporary=recoverOffscreenFence(original,areas);
            // This never calls _save(). Reconnecting the monitor restores the
            // original actor position from the existing JSON coordinates.
            const location=temporary || {x:g.x,y:g.y};
            if (f.actor.x!==location.x || f.actor.y!==location.y)
                f.actor.set_position(location.x,location.y);
        }
        this.queueInputRegions();
    }
    _connectWindowSignal(object, signal, fn) {
        try {
            const id=object.connect(signal, fn);
            this._windowSignals.push([object,id]);
        } catch (e) { safeError('Window signal '+signal,e); }
    }
    _watchWindow(window) {
        if (!window || this._windowWatch.has(window)) return;
        const handlers=[];
        for (const signal of ['position-changed','size-changed','notify::minimized',
                              'workspace-changed','unmanaged']) {
            try {
                const id=window.connect(signal,()=>{
                    if (signal==='unmanaged') this._forgetWindow(window);
                    this.queueInputRegions();
                });
                handlers.push(id);
            } catch (_) { /* Not all Cinnamon releases expose each signal */ }
        }
        this._windowWatch.set(window, handlers);
    }
    _watchWindowActor(actor) {
        if (!actor || this._windowActorWatch.has(actor)) return;
        const handlers=[];
        for (const signal of ['notify::allocation','notify::visible','notify::mapped']) {
            try {
                handlers.push(actor.connect(signal,()=>this.queueInputRegions()));
            } catch (_) { /* varies with the actor implementation */ }
        }
        try {
            handlers.push(actor.connect('destroy',()=>{
                this._forgetWindowActor(actor);
                this.queueInputRegions();
            }));
        } catch (_) {}
        this._windowActorWatch.set(actor,handlers);
    }
    _forgetWindowActor(actor) {
        const ids=this._windowActorWatch.get(actor) || [];
        this._windowActorWatch.delete(actor);
        for (const id of ids) {
            try { actor.disconnect(id); } catch (_) {}
        }
    }
    _forgetWindow(window) {
        const ids=this._windowWatch.get(window) || [];
        for (const id of ids) {
            try { window.disconnect(id); } catch (_) {}
        }
        this._windowWatch.delete(window);
    }
    snapNeighbors(except) {
        const neighbors=[];
        for (const f of this.fences.values()) {
            if (f===except || f._disposed || f.config.hidden || f.actor.visible===false) continue;
            const g=f.config.geometry;
            neighbors.push({x:g.x,y:g.y,width:g.width,
                height:f.config.collapsed?(typeof f._headerHeight==='function'?f._headerHeight():HEADER_H):g.height});
        }
        return neighbors;
    }
    _windowInputBoxes() {
        // Following newer Cinnamon: only windows visible on the active workspace;
        // never subtract the Nemo desktop itself. If we cannot enumerate,
        // leave Fences unclickable rather than stealing window events.
        const workspace=global.workspace_manager.get_active_workspace();
        if (!workspace) throw new Error('No active workspace for Fence input clipping');
        return workspace.list_windows()
            .filter(w => w.get_window_type()!==Meta.WindowType.DESKTOP &&
                w.showing_on_its_workspace())
            .map(w=>w.get_buffer_rect())
            .filter(r=>r.width>0 && r.height>0);
    }
    queueInputRegions() {
        if (this.dead || this._inputRegionIdle) return;
        this._inputRegionIdle=GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE,()=>{
            this._inputRegionIdle=0;
            if (this.dead) return GLib.SOURCE_REMOVE;
            let windows=null;
            try { windows=this._windowInputBoxes(); }
            catch (e) { safeError('Window input geometry',e); }
            // Fail closed when the window list is unavailable.
            if (windows===null) for (const f of this.fences.values()) f._clearInputPieces();
            else for (const f of this.fences.values()) f.updateInputRegions(windows);
            return GLib.SOURCE_REMOVE;
        });
    }
    undoLastTransfer() {
        const operation=this.lastTransfer;
        if (!operation) return false;
        let result;
        try { result=undoFenceTransfer(operation); }
        catch (e) {
            Main.notify('CinnaFences','Undo refused: '+String(e.message||e));
            return false;
        }
        if (!result.ok) {
            Main.notify('CinnaFences','Undo incomplete: '+String(result.error.message||result.error)+
                (result.rollbackErrors.length?' | Manual recovery: '+result.rollbackErrors.join('; '):'')+
                (result.partialTrash?' | Check Trash for recovered copies.':''));
            if (result.partialTrash || result.rollbackErrors.length) this.lastTransfer=null;
            return false;
        }
        const source=this.fences.get(operation.sourceFolder);
        const target=this.fences.get(operation.targetFolder);
        if (target) {
            for (const entry of operation.entries)
                delete target.config.icons.positions[entry.destKey || entry.name];
            target.config.icons.undoArrangement=null;
            target._save();
        }
        if (!operation.copy && source) {
            for (const [name,cell] of Object.entries(operation.sourceCells))
                source.config.icons.positions[name]=cell;
            source.config.icons.undoArrangement=null;
            source._save();
        }
        this.lastTransfer=null;
        this.queueScan(operation.sourceFolder);
        this.queueScan(operation.targetFolder);
        Main.notify('CinnaFences',operation.copy?'Copied files moved to Trash (recoverable)':'Last move undone');
        return true;
    }
    canArrangeAt(source,x,y) {
        // Same safety as file transfers: no rearranging through Nemo or any
        // other overlapping app window, and no drop through a higher Fence.
        try {
            if (this._windowInputBoxes().some(r=>x>=r.x && y>=r.y &&
                x<r.x+r.width && y<r.y+r.height)) return false;
        } catch (_) { return false; }
        const top=[...this.fences.values()].reverse().find(f=>
            !f._disposed && !f.config.hidden && (!f.actor || f.actor.visible!==false) && !f.config.collapsed && f._pointerInside(x,y));
        return top===source;
    }
    dropTargetAt(x,y,source=null) {
        // A grabbed item must never be dropped "through" an ordinary window.
        try {
            const windows=this._windowInputBoxes();
            if (windows.some(r=>x>=r.x && y>=r.y && x<r.x+r.width && y<r.y+r.height))
                return null;
        } catch (_) { return null; } // fail closed
        for (const fence of [...this.fences.values()].reverse()) {
            if (fence._disposed || fence.config.hidden || fence.actor.visible===false || fence.config.collapsed || !fence._pointerInside(x,y)) continue;
            const key=fence._sectionDropAt(x,y);
            if (key===null) return null; // top Fence blocks lower ones
            // A drop into its original directory is a no-op.
            const sourceKey=source && source._activeSection;
            if (source===fence && (source.config.view.mode==='icons' ? key==='/' : key===sourceKey))
                return null;
            return {destination:fence,sectionKey:key};
        }
        return null;
    }
    fenceAtPoint(x, y, exclude=null) {
        // Last added actor is topmost when Fences overlap. The drop must land
        // in the content area, not on the titlebar or on a collapsed Fence.
        const ordered=[...this.fences.values()].reverse();
        for (const f of ordered) {
            if (f === exclude || f._disposed || f.config.hidden || f.actor.visible===false || f.config.collapsed ||
                (f.config.view && f.config.view.mode!=='icons') || !f._pointerInside(x, y))
                continue;
            const [fx, fy] = f.actor.get_transformed_position();
            if (x >= fx+PAD && y >= fy+(typeof f._headerHeight==='function' ? f._headerHeight() : HEADER_H) &&
                x < fx+f.actor.width-PAD && y < fy+f.actor.height-PAD) return f;
        }
        return null;
    }
    queueScan(folder=null) {
        if (this.dead) return;
        if (folder) this._refreshRequested.add(folder);
        if (this.timer) GLib.source_remove(this.timer);
        this.timer=GLib.timeout_add(GLib.PRIORITY_DEFAULT,WATCH_DELAY,()=>{
            this.timer=0;
            if (!this.dead) this.scan();
            return GLib.SOURCE_REMOVE;
        });
    }
    _syncSectionMonitors(wanted) {
        for (const [path, watcher] of this.sectionMonitors) {
            if (!wanted.has(path)) {
                try { watcher.cancel(); } catch (_) {}
                this.sectionMonitors.delete(path);
            }
        }
        for (const [path, root] of wanted) {
            if (this.sectionMonitors.has(path)) continue;
            try {
                const watcher=Gio.File.new_for_path(path)
                    .monitor_directory(Gio.FileMonitorFlags.NONE,null);
                watcher.connect('changed',()=>{
                    if (!this.dead && this.fences.has(root)) this.queueScan(root);
                });
                this.sectionMonitors.set(path,watcher);
            } catch(e) { safeError('Section monitor '+path,e); }
        }
    }
    _unassignedMembershipChanged(folders) {
        // Creating a Fence writes .cinnafence.json inside an existing folder.
        // The Desktop directory itself may not emit a changed event. A scan
        // triggered by that folder's monitor must therefore refresh Unassigned
        // when its set of excluded directories changes.
        const signature=folders.filter(folder=>fileExists(pathJoin(folder,CONFIG_NAME)))
            .sort().join('\u0000');
        const changed=this._unassignedManagedSignature!==signature;
        this._unassignedManagedSignature=signature;
        return changed;
    }
    scan() {
        if (this.dead) return;
        const globals=readGlobalSettings();
        this.snapSettings=normalizeSnapSettings(globals.snapping);
        this.hotkeySettings=normalizeHotkeySettings(globals.hotkeys);
        this._bindToggleHotkey();
        const folders=directoryNames(this.desktop,true).map(name=>pathJoin(this.desktop,name));
        const membershipChanged=this._unassignedMembershipChanged(folders);
        const unassignedEnabled=globals.unassigned && globals.unassigned.enabled === true;
        const current=new Set(folders);
        if (unassignedEnabled) current.add(this.desktop);
        const watchedSections=new Map();
        for (const [folder,monitor] of this.monitors) {
            if (!current.has(folder)) { monitor.cancel(); this.monitors.delete(folder); }
        }
        for (const folder of folders) {
            if (!this.monitors.has(folder)) {
                try {
                    const monitor=Gio.File.new_for_path(folder).monitor_directory(Gio.FileMonitorFlags.NONE,null);
                    monitor.connect('changed',(_m,file,other)=>{
                        if (this.dead) return;
                        // Watch all Desktop folders for config creation, but only active
                        // fences need icon-content updates.
                        const a=file ? file.get_basename() : '';
                        const b=other ? other.get_basename() : '';
                        if (a===CONFIG_NAME || b===CONFIG_NAME || this.fences.has(folder))
                            this.queueScan(folder);
                    });
                    this.monitors.set(folder,monitor);
                } catch(e) { safeError('Monitor '+folder,e); }
            }
            const config=readConfig(folder, globals);
            const existing=this.fences.get(folder);
            if (config && config.view && config.view.mode!=='icons') {
                for (const sub of watchedSectionPaths(folder,config.view.mode,
                    directoryNames(folder,true))) watchedSections.set(sub,folder);
            }
            if (!config) {
                if (existing) {existing.destroy();this.fences.delete(folder);}
            } else if (!existing) {
                try {
                    const created=new Fence(this,folder,config);
                    this.fences.set(folder,created);
                    if (!this.fencesVisible || config.hidden) { created._clearInputPieces(); created.actor.hide(); }
                }
                catch(e) {safeError('Fence maken '+folder,e);}
            } else {
                existing.updateConfig(config);
                if (this._refreshRequested.has(folder)) existing.rebuild();
            }
        }
        // The Desktop is a virtual source. No .cinnafence.json is created in it.
        // Its own layout lives in ~/.config/cinnafences/unassigned.json.
        const unassignedExisting=this.fences.get(this.desktop);
        if (unassignedEnabled) {
            const config=readUnassignedConfig(globals);
            if (!unassignedExisting) {
                try {
                    const fence=new Fence(this,this.desktop,config);
                    this.fences.set(this.desktop,fence);
                    if (!this.fencesVisible || config.hidden) {
                        fence._clearInputPieces();fence.actor.hide();
                    }
                } catch(e) { safeError('Unassigned Fence',e); }
            } else {
                unassignedExisting.updateConfig(config);
                if (this._refreshRequested.has(this.desktop) || membershipChanged) unassignedExisting.rebuild();
            }
        } else if (unassignedExisting) {
            unassignedExisting.destroy();this.fences.delete(this.desktop);
        }
        for (const [folder,fence] of this.fences) {
            if (!current.has(folder)) {fence.destroy();this.fences.delete(folder);}
        }
        // Subfolder monitors are tied to active section views; remove them
        // when a Fence disappears or switches back to Icons. Keep this after
        // the top-level scan so newly created subfolders are picked up too.
        this._syncSectionMonitors(watchedSections);
        this._refreshRequested.clear();
        this._applyMonitorLayout();
        this.queueInputRegions();
    }
    destroy() {
        this.dead=true;
        if (this._registeredHotkey) {
            try { Main.keybindingManager.removeHotKey(HOTKEY_NAME); }
            catch (e) { safeError('Remove shortcut',e); }
            this._registeredHotkey=null;
        }
        if (this._monitorLayoutIdle) {
            GLib.source_remove(this._monitorLayoutIdle);
            this._monitorLayoutIdle=0;
        }
        if (this._inputRegionIdle) {
            GLib.source_remove(this._inputRegionIdle);
            this._inputRegionIdle=0;
        }
        for (const [w] of this._windowWatch) this._forgetWindow(w);
        for (const [actor] of this._windowActorWatch) this._forgetWindowActor(actor);
        for (const [obj,id] of this._windowSignals) {
            try { obj.disconnect(id); } catch (_) {}
        }
        this._windowSignals=[];
        if (this._stageHoverId) {
            try { global.stage.disconnect(this._stageHoverId); } catch (_) {}
            this._stageHoverId = 0;
        }
        if (this.timer) {GLib.source_remove(this.timer);this.timer=0;}
        if (this._desktopMonitor) {this._desktopMonitor.cancel();this._desktopMonitor=null;}
        if (this._globalMonitor) {this._globalMonitor.cancel();this._globalMonitor=null;}
        for (const m of this.monitors.values()) m.cancel();
        this.monitors.clear();
        for (const m of this.sectionMonitors.values()) m.cancel();
        this.sectionMonitors.clear();
        for (const f of this.fences.values()) f.destroy();
        this.fences.clear();
    }
}
let manager=null;
function init() {}
function enable() { if (manager) manager.destroy(); manager=new FenceManager(); syncNemoDesktopMode(true); }
function disable() { if (manager) {manager.destroy();manager=null;} syncNemoDesktopMode(false); }
