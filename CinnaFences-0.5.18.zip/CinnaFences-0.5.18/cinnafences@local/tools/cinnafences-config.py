#!/usr/bin/env python3
"""Safe helper for CinnaFences 0.1: opt-in Desktop folders.

No deletion or moving of user files. All writes are atomic and never overwrite
existing configurations when initializing a folder.
"""
import argparse
import ast
import subprocess
import json
import os
import re
from pathlib import Path
import tempfile

CONFIG = '.cinnafence.json'
DESKTOP = Path.home() / 'Desktop'
STATE_PATH = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config')) / 'cinnafences' / 'desktop-mode.json'
HIDDEN_LAYOUT = 'false::false'
GLOBAL_PATH = STATE_PATH.with_name('defaults.json')
def unassigned_path():
    return GLOBAL_PATH.with_name('unassigned.json')


def nemo_layout():
    result = subprocess.run(['gsettings', 'get', 'org.nemo.desktop', 'desktop-layout'],
                            capture_output=True, text=True, check=True)
    # gsettings prints a quoted GVariant string, e.g. 'true::false'.
    value = ast.literal_eval(result.stdout.strip())
    if not isinstance(value, str) or '::' not in value:
        raise ValueError(f'Onverwachte Nemo-indeling: {value!r}')
    return value


def set_nemo_layout(value):
    subprocess.run(['gsettings', 'set', 'org.nemo.desktop', 'desktop-layout', value],
                   check=True, capture_output=True, text=True)


def desktop_mode_state():
    if STATE_PATH.is_symlink():
        raise ValueError('Symlink bij opgeslagen desktopinstelling geweigerd')
    if not STATE_PATH.exists():
        return None
    state = json.loads(STATE_PATH.read_text(encoding='utf-8'))
    if (not isinstance(state, dict) or state.get('enabled') is not True
            or not isinstance(state.get('originalLayout'), str)
            or '::' not in state['originalLayout']):
        raise ValueError('Ongeldige desktopmodusstatus; niets gewijzigd')
    return state


def save_desktop_mode(state):
    folder = STATE_PATH.parent
    if folder.is_symlink():
        raise ValueError('Symlink bij desktopmodusmap geweigerd')
    folder.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.desktop-mode-', dir=str(folder))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(state, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, STATE_PATH)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def desktop_mode(command):
    if command == 'status':
        state = desktop_mode_state()
        print('Fences-desktopmodus: ' + ('AAN' if state else 'UIT'))
        print('Nemo desktop-layout: ' + nemo_layout())
        if state:
            print('Oorspronkelijke instelling: ' + state['originalLayout'])
        return
    if command == 'on':
        state = desktop_mode_state()
        current = nemo_layout()
        if state is None:
            # Persist recovery data BEFORE making desktop icons disappear.
            state = {'enabled': True, 'originalLayout': current, 'version': 1}
            save_desktop_mode(state)
        elif current != state['originalLayout'] and current != HIDDEN_LAYOUT:
            raise ValueError('Nemo-indeling is elders gewijzigd; herstel eerst of zet modus uit')
        if current != HIDDEN_LAYOUT:
            set_nemo_layout(HIDDEN_LAYOUT)
        print('Fences-desktopmodus AAN. Alle gewone Nemo-desktopiconen zijn verborgen.')
        print('Herstel: python3 tools/cinnafences-config.py desktop-mode restore')
        return
    # A recovery call works even if Cinnamon or CinnaFences has crashed.
    state = desktop_mode_state()
    if state is None:
        print('Geen opgeslagen Fences-desktopmodus; niets gewijzigd.')
        return
    current = nemo_layout()
    original = state['originalLayout']
    if current == HIDDEN_LAYOUT and original != HIDDEN_LAYOUT:
        set_nemo_layout(original)
    elif current != HIDDEN_LAYOUT and current != original:
        print('Nemo-instelling is intussen veranderd; huidige waarde wordt gerespecteerd.')
    STATE_PATH.unlink()
    print(f'Fences-desktopmodus UIT. Nemo desktop-layout: {nemo_layout()}')



def inside_desktop(folder):
    root = DESKTOP.resolve(strict=True)
    folder = Path(folder).expanduser().resolve(strict=True)
    if folder.parent != root or not folder.is_dir():
        raise ValueError(f'Kies een directe map onder {root} (geen submap): {folder}')
    return folder


def default_config(folder, x, y):
    return {
        'version': 1,
        'enabled': True,
        'title': folder.name,
        'geometry': {'x': x, 'y': y, 'width': 350, 'height': 270},
        'inheritGlobals': True,
        'inheritAdvancedGlobals': True,  # new Fences inherit Header/Sections presentation
        'appearance': {
            'background': '#202733', 'backgroundOpacity': 0.27,
            'hoverOpacity': 0.75, 'iconOpacity': 0.45,
            'labelOpacity': 0.60, 'labelColor': '#ffffff',
            'radius': 12, 'hoverEnabled': True,
            'borderEnabled': True, 'borderColor': '#f0f5ff',
            'borderWidth': 1, 'borderOpacity': 0.16
        },
        'icons': {
            'size': 48, 'gridWidth': 86, 'gridHeight': 88,
            'layoutColumns': 3, 'positions': {}, 'showLabels': True,
            'labelFont': 'Sans', 'labelFontSize': 9
        },
        'view': {'mode':'icons','active':None,'tabsInHeader':False,
                 'autoFitHeight':False,'autoFitMaxHeight':720},
        'header': {'show':True,'background':'#0c1017','opacity':0.20,'textColor':'#ffffff',
                   'hoverBackground':'#0c1017','hoverOpacity':0.20,'hoverTextColor':'#ffffff',
                   'fontFamily':'Sans','fontSize':11,'height':32,'showCollapseButton':True},
        'sections': {'background':'#344052','opacity':0.80,'textColor':'#ffffff',
                     'hoverBackground':'#344052','hoverOpacity':0.80,'hoverTextColor':'#ffffff',
                     'fontFamily':'Sans','alignment':'center','showCollapseButton':True,
                     'fontSize':10,'height':30},
        'collapsed': False,
        'geometryLocked': False
    }


def create(folder, x, y, dry_run=False):
    target = folder / CONFIG
    if target.exists() or target.is_symlink():
        print(f'OVERGESLAGEN (config bestaat): {target}')
        return False
    cfg = default_config(folder, x, y)
    # A new Fence may use the General view default; an existing Fence never
    # changes mode merely because the General default changes.
    cfg['view']['mode'] = read_global_settings()['view.mode']
    cfg['view']['active'] = '' if cfg['view']['mode'] == 'rolodex' else None
    print(('ZOU MAKEN: ' if dry_run else 'GEMAAKT: ') + str(target))
    if not dry_run:
        # Exclusief aanmaken. Kan bestaande config nooit overschrijven.
        fd = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
            f.write('\n')
    return True


def change_enabled(folder, state):
    target = folder / CONFIG
    if not target.exists():
        raise ValueError('Geen configuratie gevonden; gebruik eerst init.')
    original = json.loads(target.read_text(encoding='utf-8'))
    if not isinstance(original, dict):
        raise ValueError('Config is geen JSON-object')
    original['enabled'] = state
    fd, temp_path = tempfile.mkstemp(prefix=CONFIG + '.', suffix='.tmp', dir=str(folder))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(original, f, ensure_ascii=False, indent=2)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, target)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)
    print(('INGESCHAKELD' if state else 'UITGESCHAKELD') + ': ' + str(folder))


def change_hover(folder, enabled):
    """Enable or disable hover animation without touching the other settings."""
    target = folder / CONFIG
    if not target.exists():
        raise ValueError('Geen configuratie gevonden; gebruik eerst init.')
    original = json.loads(target.read_text(encoding='utf-8'))
    if not isinstance(original, dict):
        raise ValueError('Config is geen JSON-object')
    appearance = original.get('appearance')
    if appearance is None:
        appearance = {}
    if not isinstance(appearance, dict):
        raise ValueError('appearance moet een JSON-object zijn')
    appearance['hoverEnabled'] = bool(enabled)
    original['appearance'] = appearance
    fd, temp_path = tempfile.mkstemp(prefix=CONFIG + '.', suffix='.tmp', dir=str(folder))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(original, f, ensure_ascii=False, indent=2)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, target)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)
    print(('HOVER AAN' if enabled else 'HOVER UIT (altijd volledig zichtbaar)') + ': ' + str(folder))


# Only these per-Fence keys are editable through the settings window.
# Nested patches preserve geometry, manually assigned icon cells and all
# unrecognised keys from existing/future versions of the configuration.
FENCE_EDIT_FIELDS = {
    'title': ('title', None, None),
    'geometryLocked': ('geometryLocked', None, None),
    'inheritGlobals': ('inheritGlobals', None, None),
    'inheritAdvancedGlobals': ('inheritAdvancedGlobals', None, None),
    'geometry.width': ('geometry', 'width', (172, 2400)),
    'geometry.height': ('geometry', 'height', (108, 1600)),
    'appearance.background': ('appearance', 'background', None),
    'appearance.labelColor': ('appearance', 'labelColor', None),
    'appearance.backgroundOpacity': ('appearance', 'backgroundOpacity', (0.0, 1.0)),
    'appearance.hoverOpacity': ('appearance', 'hoverOpacity', (0.0, 1.0)),
    'appearance.iconOpacity': ('appearance', 'iconOpacity', (0.1, 1.0)),
    'appearance.labelOpacity': ('appearance', 'labelOpacity', (0.1, 1.0)),
    'appearance.radius': ('appearance', 'radius', (0, 28)),
    'appearance.hoverEnabled': ('appearance', 'hoverEnabled', None),
    'appearance.borderEnabled': ('appearance', 'borderEnabled', None),
    'appearance.borderColor': ('appearance', 'borderColor', None),
    'appearance.borderWidth': ('appearance', 'borderWidth', (1, 8)),
    'appearance.borderOpacity': ('appearance', 'borderOpacity', (0.0, 1.0)),
    'icons.size': ('icons', 'size', (20, 96)),
    'icons.gridWidth': ('icons', 'gridWidth', (48, 150)),
    'icons.gridHeight': ('icons', 'gridHeight', (52, 170)),
    'icons.showLabels': ('icons', 'showLabels', None),
    'icons.labelFont': ('icons', 'labelFont', None),
    'icons.labelFontSize': ('icons', 'labelFontSize', (6, 24)),
    'view.mode': ('view','mode',None),
    'view.tabsInHeader': ('view','tabsInHeader',None),
    'view.autoFitHeight': ('view','autoFitHeight',None),
    'view.autoFitMaxHeight': ('view','autoFitMaxHeight',(160,1600)),
    'header.show': ('header','show',None),
    'header.background': ('header','background',None),
    'header.opacity': ('header','opacity',(0.0,1.0)),
    'header.hoverBackground': ('header','hoverBackground',None),
    'header.hoverOpacity': ('header','hoverOpacity',(0.0,1.0)),
    'header.hoverTextColor': ('header','hoverTextColor',None),
    'header.fontFamily': ('header','fontFamily',None),
    'header.textColor': ('header','textColor',None),
    'header.fontSize': ('header','fontSize',(7,22)),
    'header.height': ('header','height',(24,64)),
    'header.showCollapseButton': ('header','showCollapseButton',None),
    'sections.background': ('sections','background',None),
    'sections.opacity': ('sections','opacity',(0.0,1.0)),
    'sections.hoverBackground': ('sections','hoverBackground',None),
    'sections.hoverOpacity': ('sections','hoverOpacity',(0.0,1.0)),
    'sections.hoverTextColor': ('sections','hoverTextColor',None),
    'sections.fontFamily': ('sections','fontFamily',None),
    'sections.alignment': ('sections','alignment',None),
    'sections.showCollapseButton': ('sections','showCollapseButton',None),
    'sections.textColor': ('sections','textColor',None),
    'sections.fontSize': ('sections','fontSize',(7,20)),
    'sections.height': ('sections','height',(24,55)),

}
BOOL_EDIT_FIELDS = {'geometryLocked', 'inheritGlobals', 'inheritAdvancedGlobals', 'appearance.hoverEnabled', 'appearance.borderEnabled', 'icons.showLabels', 'header.show','header.showCollapseButton','sections.showCollapseButton','view.tabsInHeader','view.autoFitHeight'}
INT_EDIT_FIELDS = {'appearance.radius', 'appearance.borderWidth', 'icons.size', 'icons.gridWidth', 'icons.gridHeight', 'icons.labelFontSize', 'geometry.width', 'geometry.height', 'header.fontSize','header.height','sections.fontSize','sections.height','view.autoFitMaxHeight'}
OPACITY_FIELDS = {'appearance.backgroundOpacity', 'appearance.hoverOpacity',
                  'appearance.iconOpacity', 'appearance.labelOpacity',
                  'appearance.borderOpacity'}


def _is_unassigned(folder):
    # Never use resolve() here: do not follow a symlink to some other user's
    # Desktop or an unexpected location when selecting a virtual Fence.
    return Path(folder).expanduser().absolute() == DESKTOP.expanduser().absolute()


def _fence_edit_target(folder):
    if _is_unassigned(folder):
        if not read_unassigned_enabled():
            raise ValueError('Enable Desktop / Unassigned under General → Desktop first')
        if DESKTOP.is_symlink() or not DESKTOP.is_dir():
            raise ValueError('Desktop directory missing or is a symbolic link')
        if unassigned_path().is_symlink() or unassigned_path().parent.is_symlink():
            raise ValueError('Symlink for Unassigned configuration is not allowed')
        return DESKTOP, unassigned_path()
    folder = inside_desktop(folder)
    return folder, folder / CONFIG


def _unassigned_seed():
    # Same editable fields as an ordinary Fence; the directory stays ~/Desktop
    # and the configuration lives in ~/.config/cinnafences/unassigned.json.
    seed = default_config(DESKTOP, 60, 410)
    seed['title'] = 'Desktop / Unassigned'
    seed['inheritGlobals'] = True
    seed['inheritAdvancedGlobals'] = True
    seed['view']['mode'] = 'icons'
    return seed


def active_fence_folders():
    """Expose configured enabled Fences and an enabled virtual Desktop Fence."""
    if not DESKTOP.is_dir():
        return []
    folders = []
    for folder in sorted(DESKTOP.iterdir(), key=lambda p: p.name.casefold()):
        if folder.is_symlink() or not folder.is_dir():
            continue
        file = folder / CONFIG
        if file.is_symlink() or not file.is_file():
            continue
        try:
            data = json.loads(file.read_text(encoding='utf-8'))
            if isinstance(data, dict) and data.get('enabled') is not False and data.get('nofence') is not True:
                folders.append(folder)
        except (OSError, ValueError):
            continue
    if read_unassigned_enabled():
        if DESKTOP.is_symlink():
            raise ValueError('Desktop path cannot be a symlink')
        folders.append(DESKTOP)
    return folders


def read_fence_settings(folder):
    folder, target = _fence_edit_target(folder)
    if target.is_symlink():
        raise ValueError('Symlink naar Fence-config geweigerd')
    if _is_unassigned(folder) and not target.exists():
        return _unassigned_seed()  # Editing is read-only until Apply.
    data = json.loads(target.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('enabled') is False or data.get('nofence') is True:
        raise ValueError('Geen actieve Fence-configuratie gevonden')
    if _is_unassigned(folder):
        # A virtual Desktop view never reveals managed subfolders as tabs.
        data['view'] = dict(data.get('view') or {}, mode='icons')
    return data


def _validate_edit(field, value):
    if field not in FENCE_EDIT_FIELDS:
        raise ValueError(f'Onbekende instelling: {field}')
    if field in BOOL_EDIT_FIELDS:
        if not isinstance(value, bool):
            raise ValueError(f'{field} moet waar/onwaar zijn')
    elif field == 'title':
        if not isinstance(value, str) or not value.strip() or len(value) > 100:
            raise ValueError('De Fence-naam moet 1 tot 100 tekens bevatten')
        value = value.strip()
    elif field == 'sections.alignment':
        if value not in ('left','center','right'):
            raise ValueError('Section alignment must be left, center or right')
    elif field == 'view.mode':
        if value not in ('icons','tabs','rolodex'):
            raise ValueError('View mode must be icons, tabs or rolodex')
    elif field in ('appearance.background', 'appearance.labelColor', 'appearance.borderColor', 'header.background','header.textColor','header.hoverBackground','header.hoverTextColor','sections.background','sections.textColor','sections.hoverBackground','sections.hoverTextColor'):
        import re
        if not isinstance(value, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
            raise ValueError('Color must use #RRGGBB')
    elif field in ('icons.labelFont','header.fontFamily','sections.fontFamily'):
        import re
        if not isinstance(value, str) or not re.fullmatch(r'[\w .,+-]{1,80}', value, flags=re.UNICODE):
            raise ValueError('Font family must be a valid name (max 80 characters)')
    else:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f'{field} moet een getal zijn')
        import math
        if not math.isfinite(value):
            raise ValueError(f'{field} moet eindig zijn')
        low, high = FENCE_EDIT_FIELDS[field][2]
        if not low <= value <= high:
            raise ValueError(f'{field} buiten toegestaan bereik ({low} - {high})')
        if field in INT_EDIT_FIELDS and (not isinstance(value, int)):
            raise ValueError(f'{field} moet een geheel getal zijn')
    return value


# General snapping is independent from Fence style inheritance. Existing
# Fences never change positions merely because General settings are saved.
SNAP_DEFAULTS = {
    'snapping.enabled': False, 'snapping.fences': True,
    'snapping.screen': True, 'snapping.grid': False,
    'snapping.distance': 14, 'snapping.gridX': 20, 'snapping.gridY': 20,
}
SNAP_INT_RANGES = {'snapping.distance': (2, 40),
                   'snapping.gridX': (8, 200), 'snapping.gridY': (8, 200)}
SNAP_FIELDS = set(SNAP_DEFAULTS)

# Optional shortcut: disabled after upgrade to avoid conflicting with a user's
# existing Cinnamon/application keyboard shortcuts. Only modifier+key combos.
HOTKEY_DEFAULTS = {'hotkeys.enabled': False, 'hotkeys.toggle': '<Super>f'}
HOTKEY_FIELDS = set(HOTKEY_DEFAULTS)
HOTKEY_PATTERN = re.compile(r'(?:(?:<Super>|<Control>|<Alt>|<Shift>)){1,4}(?:[a-zA-Z0-9]|F(?:[1-9]|1[0-2]))\Z')


def default_hotkeys():
    return dict(HOTKEY_DEFAULTS)


def _validate_hotkey(name, value):
    if name == 'hotkeys.enabled':
        if not isinstance(value, bool):
            raise ValueError('hotkeys.enabled must be true or false')
    elif name == 'hotkeys.toggle':
        if not isinstance(value, str) or not HOTKEY_PATTERN.fullmatch(value):
            raise ValueError('Shortcut must be, for example, <Super>f or <Control><Alt>f')
    else:
        raise ValueError('Unknown shortcut setting: '+name)
    return value


def read_hotkey_settings():
    values = default_hotkeys()
    raw = _read_global_document().get('hotkeys', {})
    if not isinstance(raw, dict):
        raise ValueError('Invalid General hotkeys configuration')
    for key in HOTKEY_FIELDS:
        sub = key.split('.', 1)[1]
        if sub in raw:
            values[key] = _validate_hotkey(key, raw[sub])
    return values


def update_hotkey_settings(changes):
    if not isinstance(changes, dict) or not changes:
        return False
    if not set(changes).issubset(HOTKEY_FIELDS):
        raise ValueError('Only hotkey values are permitted')
    return update_general_settings(changes)

# Global values cover all presentation categories. The selected view.mode
# is a DEFAULT FOR NEW FENCES ONLY (not an inherited active mode). Positions,
# geometry, file state, title and lock remain exclusively per Fence.
GENERAL_FIELDS = {name for name in FENCE_EDIT_FIELDS
                  if name.startswith(('appearance.', 'icons.', 'view.', 'header.', 'sections.'))}
GENERAL_ADVANCED_FIELDS = {name for name in GENERAL_FIELDS
                           if name.startswith(('view.', 'header.', 'sections.')) and name != 'view.mode'}


def default_snapping():
    return dict(SNAP_DEFAULTS)


def _validate_snap(name, value):
    if name not in SNAP_FIELDS:
        raise ValueError('Unknown snapping setting: ' + name)
    if name in SNAP_INT_RANGES:
        low, high = SNAP_INT_RANGES[name]
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise ValueError(f'{name} must be an integer between {low} and {high}')
    elif not isinstance(value, bool):
        raise ValueError(f'{name} must be true or false')
    return value


def _read_global_document():
    if GLOBAL_PATH.is_symlink() or GLOBAL_PATH.parent.is_symlink():
        raise ValueError('Symlink for global settings is not allowed')
    if not GLOBAL_PATH.exists():
        return {}
    data = json.loads(GLOBAL_PATH.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('General configuration must be a JSON object')
    return data


def read_snapping_settings():
    values = default_snapping()
    raw = _read_global_document().get('snapping', {})
    if not isinstance(raw, dict):
        raise ValueError('Invalid General snapping configuration')
    for key in SNAP_FIELDS:
        sub=key.split('.',1)[1]
        if sub in raw:
            values[key] = _validate_snap(key, raw[sub])
    return values


def default_style():
    data = default_config(Path('Fence'), 50, 80)
    return {name: data[group][key] for name, (group, key, _) in FENCE_EDIT_FIELDS.items()
            if name in GENERAL_FIELDS}


def read_global_settings():
    """Read only the valid, known style fields. Snapping is independent."""
    settings = default_style()
    obj = _read_global_document()
    for name in GENERAL_FIELDS:
        group, sub, _ = FENCE_EDIT_FIELDS[name]
        part = obj.get(group, {})
        if isinstance(part, dict) and sub in part:
            settings[name] = _validate_edit(name, part[sub])
    return settings


def read_unassigned_enabled():
    value=_read_global_document().get('unassigned',{});
    if not isinstance(value,dict):
        raise ValueError('Invalid Unassigned configuration')
    enabled=value.get('enabled',False)
    if not isinstance(enabled,bool):
        raise ValueError('Unassigned enabled must be true or false')
    return enabled


def _validate_unassigned(name,value):
    raise ValueError('unassigned.enabled must be true or false')


def update_general_settings(changes):
    """Atomically update General style + snapping, preserving other keys."""
    if not isinstance(changes, dict) or not changes:
        return False
    if not set(changes).issubset(GENERAL_FIELDS | SNAP_FIELDS | HOTKEY_FIELDS | {'unassigned.enabled'}):
        raise ValueError('Unknown General setting')
    verified = {name: (value if name == 'unassigned.enabled' and isinstance(value,bool) else
                       (_validate_unassigned(name,value) if name == 'unassigned.enabled' else
                       _validate_hotkey(name,value) if name in HOTKEY_FIELDS else
                       _validate_snap(name,value) if name in SNAP_FIELDS else
                       _validate_edit(name,value))) for name,value in changes.items()}
    current = _read_global_document()  # Preserve unrelated/future settings.
    # Validate all existing known values before writing, fail closed on corrupt data.
    read_global_settings()
    read_snapping_settings()
    read_hotkey_settings()
    read_unassigned_enabled()
    for name,value in verified.items():
        if name == 'unassigned.enabled':
            group, sub = 'unassigned', 'enabled'
        elif name in HOTKEY_FIELDS:
            group, sub = 'hotkeys', name.split('.',1)[1]
        elif name in SNAP_FIELDS:
            group, sub = 'snapping', name.split('.',1)[1]
        else:
            group, sub, _ = FENCE_EDIT_FIELDS[name]
        if group not in current:
            current[group] = {}
        if not isinstance(current[group], dict):
            raise ValueError('Invalid configuration group: '+group)
        current[group][sub] = value
    if 'version' not in current:
        current['version'] = 1
    GLOBAL_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.defaults-', suffix='.tmp', dir=str(GLOBAL_PATH.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(current, out, ensure_ascii=False, indent=2)
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, GLOBAL_PATH)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return True


def update_global_settings(changes):
    if not isinstance(changes, dict) or not changes:
        return False
    if not set(changes).issubset(GENERAL_FIELDS):
        raise ValueError('Only presentation defaults may be saved globally')
    return update_general_settings(changes)


def update_snapping_settings(changes):
    if not isinstance(changes, dict) or not changes:
        return False
    if not set(changes).issubset(SNAP_FIELDS):
        raise ValueError('Only snapping values are permitted')
    return update_general_settings(changes)


def update_fence_settings(folder, changes):
    """Atomic read/merge/write of explicitly changed UI fields.

    Re-read immediately before saving: do not overwrite icon drag positions,
    live geometry, existing JSON keys, or unrelated updates made by Cinnamon.
    """
    folder, target = _fence_edit_target(folder)
    if not isinstance(changes, dict) or not changes:
        return False
    if _is_unassigned(folder) and 'view.mode' in changes and changes['view.mode'] != 'icons':
        raise ValueError('Desktop / Unassigned uses Icons view only')
    verified = {key: _validate_edit(key, value) for key, value in changes.items()}
    if target.is_symlink():
        raise ValueError('Symlink naar Fence-config geweigerd')
    data = read_fence_settings(folder)
    prior_view_mode = data.get('view', {}).get('mode', 'icons') if isinstance(data.get('view', {}),dict) else 'icons'
    for key, value in verified.items():
        parent, sub, _ = FENCE_EDIT_FIELDS[key]
        if sub is None:
            data[parent] = value
        else:
            group = data.setdefault(parent, {})
            if not isinstance(group, dict):
                raise ValueError(f'{parent} is geen JSON-object')
            group[sub] = value
    if 'view.mode' in verified and verified['view.mode'] != prior_view_mode:
        # First use of the accordion starts fully collapsed, as in the
        # desktop mock-up. Tabs select their first available real folder.
        data['view']['active'] = '' if verified['view.mode'] == 'rolodex' else None
    # Respect the same constraints as the Cinnamon renderer. Do not silently
    # shrink the configured icon size or corrupt a manually arranged grid.
    icons = data.get('icons', {})
    if not isinstance(icons, dict):
        raise ValueError('icons is geen JSON-object')
    size = icons.get('size', 48)
    width = icons.get('gridWidth', 86)
    height = icons.get('gridHeight', 88)
    if isinstance(size, (int, float)) and isinstance(width, (int, float)):
        if size > width - 8:
            icons['gridWidth'] = min(150, int(size) + 8)
    if isinstance(size, (int, float)) and isinstance(height, (int, float)):
        if size > height - 21:
            icons['gridHeight'] = min(170, int(size) + 21)
    # An Unassigned save creates its own config safely outside ~/Desktop.
    # Never create a .cinnafence.json in the Desktop root.
    if _is_unassigned(folder):
        if target.parent.is_symlink():
            raise ValueError('Unassigned settings directory is a symlink')
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            data.setdefault('version', 1)
    fd, temporary = tempfile.mkstemp(prefix=target.name + '.', suffix='.tmp', dir=str(target.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out, ensure_ascii=False, indent=2)
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return True


# Layout profiles are explicit named snapshots. They never change Nemo, the
# Cinnamon actors or arbitrary Desktop files. No automatic monitor switching:
# profile restoration is an intentional, reversible user action.
def _profiles_path():
    return GLOBAL_PATH.with_name('layout-profiles.json')


def _profile_name(name):
    if (not isinstance(name, str) or name != name.strip() or
            not 1 <= len(name) <= 48 or any(ord(c) < 32 or c in '/\\' for c in name)):
        raise ValueError('Profile name must be 1–48 characters without path separators')
    return name


def _profile_monitors(rects):
    if not isinstance(rects, (tuple, list)) or not 1 <= len(rects) <= 12:
        raise ValueError('A monitor layout must contain 1–12 displays')
    result = []
    for r in rects:
        if not isinstance(r, dict) or set(r) != {'x', 'y', 'width', 'height'}:
            raise ValueError('Invalid monitor rectangle')
        for k in ('x', 'y', 'width', 'height'):
            if type(r[k]) is not int:
                raise ValueError('Invalid monitor coordinate')
        if not (-20000 <= r['x'] <= 20000 and -20000 <= r['y'] <= 20000 and
                1 <= r['width'] <= 20000 and 1 <= r['height'] <= 20000):
            raise ValueError('Monitor coordinates out of range')
        result.append({k: r[k] for k in ('x', 'y', 'width', 'height')})
    result.sort(key=lambda r: (r['x'], r['y'], r['width'], r['height']))
    if len({(r['x'],r['y'],r['width'],r['height']) for r in result}) != len(result):
        raise ValueError('Duplicate monitor rectangles')
    return result


def _profile_geometry(g):
    if not isinstance(g, dict) or set(g) != {'x', 'y', 'width', 'height'}:
        raise ValueError('Invalid Fence geometry in profile')
    for k in ('x', 'y', 'width', 'height'):
        if type(g[k]) is not int:
            raise ValueError('Invalid Fence geometry number')
    if not (-20000 <= g['x'] <= 20000 and -20000 <= g['y'] <= 20000 and
            172 <= g['width'] <= 2400 and 108 <= g['height'] <= 1600):
        raise ValueError('Fence geometry out of range')
    return {key:g[key] for key in ('x','y','width','height')}


def _read_profiles():
    path = _profiles_path()
    if path.is_symlink() or path.parent.is_symlink():
        raise ValueError('Symlink at profile storage is not permitted')
    if not path.exists():
        return {'version': 1, 'profiles': {}, 'undo': None}
    if path.stat().st_size > 1024*1024:
        raise ValueError('Profile storage is unexpectedly large')
    state = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(state, dict) or state.get('version') != 1 or not isinstance(state.get('profiles'),dict):
        raise ValueError('Unknown layout profile file format')
    if len(state['profiles']) > 40:
        raise ValueError('Too many saved layout profiles')
    for name,profile in state['profiles'].items():
        _profile_name(name)
        if not isinstance(profile,dict) or not isinstance(profile.get('fences'),dict):
            raise ValueError('Invalid profile content')
        _profile_monitors(profile.get('monitors'))
        if len(profile['fences']) > 350:
            raise ValueError('Too many Fences in profile')
        for folder,g in profile['fences'].items():
            _profile_folder_name(folder)
            _profile_geometry(g)
    undo = state.get('undo')
    if undo is not None:
        if not isinstance(undo,dict) or not isinstance(undo.get('before'),dict) or not isinstance(undo.get('after'),dict):
            raise ValueError('Invalid layout undo data')
        _profile_monitors(undo.get('monitors'))
        if undo['before'].keys()!=undo['after'].keys():
            raise ValueError('Mismatched layout undo data')
        for name in undo['before']:
            _profile_folder_name(name)
            _profile_geometry(undo['before'][name]); _profile_geometry(undo['after'][name])
    return {'version':1, 'profiles':state['profiles'], 'undo':undo}


def _profile_folder_name(name):
    if (not isinstance(name,str) or name in ('', '.', '..') or '/' in name or '\\' in name or
            '\x00' in name or name.startswith('.')):
        raise ValueError('Unsafe Desktop folder in profile')
    return name


def _atomic_json_file(path, data):
    if path.is_symlink() or path.parent.is_symlink():
        raise ValueError('Symlink at settings target is not permitted')
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tempname=tempfile.mkstemp(prefix='.'+path.name+'-', suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            json.dump(data,out,ensure_ascii=False,indent=2)
            out.write('\n'); out.flush(); os.fsync(out.fileno())
        os.replace(tempname,path)
    finally:
        if os.path.exists(tempname):
            os.unlink(tempname)


def list_layout_profiles():
    state = _read_profiles()
    return [{ 'name':name, 'monitors':len(p['monitors']), 'fences':len(p['fences']),
              'savedAt':p.get('savedAt','') } for name,p in sorted(state['profiles'].items())]


def _snapshot_fence_geometries():
    result = {}
    for folder in active_fence_folders():
        data = read_fence_settings(folder)
        result[_profile_folder_name(folder.name)] = _profile_geometry(data.get('geometry'))
    return result


def save_layout_profile(name, monitors):
    name = _profile_name(name)
    monitors = _profile_monitors(monitors)
    state = _read_profiles()
    if name not in state['profiles'] and len(state['profiles'])>=40:
        raise ValueError('Maximum of 40 saved profiles')
    fences = _snapshot_fence_geometries()
    if not fences:
        raise ValueError('No active Fences to save')
    from datetime import datetime, timezone
    state['profiles'][name] = {
        'monitors':monitors,'fences':fences,
        'savedAt':datetime.now(timezone.utc).isoformat(timespec='seconds')
    }
    _atomic_json_file(_profiles_path(),state)
    return len(fences)


def delete_layout_profile(name):
    name=_profile_name(name)
    state=_read_profiles()
    if name not in state['profiles']:
        raise ValueError('Layout profile does not exist')
    del state['profiles'][name]
    _atomic_json_file(_profiles_path(),state)


def can_undo_layout_restore():
    return _read_profiles()['undo'] is not None


def _commit_geometries(changes, undo_state):
    # Validate *all* targets before changing anything. Every file is only
    # written with a merge preserving labels, icons, positions, and settings.
    prepared=[]
    for name, g in changes.items():
        _profile_folder_name(name)
        g=_profile_geometry(g)
        folder=inside_desktop(DESKTOP/name)
        path=folder/CONFIG
        if path.is_symlink():
            raise ValueError('Refusing symlink Fence config: '+name)
        config=read_fence_settings(folder)
        original=path.read_bytes()
        config['geometry']=g
        prepared.append((path,config,original))
    state=_read_profiles()
    done=[]
    try:
        for path, config, original in prepared:
            _atomic_json_file(path,config)
            done.append((path,original))
        state['undo']=undo_state
        _atomic_json_file(_profiles_path(),state)
    except Exception as e:
        rollback_errors=[]
        for path, original in reversed(done):
            try:
                # Original bytes, not JSON-normalized: preserve every unknown
                # key and indentation exactly through an atomic replacement.
                fd,tmp=tempfile.mkstemp(prefix='.rollback-',suffix='.tmp',dir=str(path.parent))
                try:
                    with os.fdopen(fd,'wb') as out:
                        out.write(original);out.flush();os.fsync(out.fileno())
                    os.replace(tmp,path)
                finally:
                    if os.path.exists(tmp):os.unlink(tmp)
            except Exception as rollback_error:
                rollback_errors.append(f'{path}: {rollback_error}')
        raise RuntimeError(f'Layout restore failed: {e}. '+
                           ('Manual recovery required: '+'; '.join(rollback_errors) if rollback_errors else 'All modified configs rolled back.')) from e
    return len(done)


def restore_layout_profile(name, monitors):
    name=_profile_name(name)
    monitors=_profile_monitors(monitors)
    state=_read_profiles()
    profile=state['profiles'].get(name)
    if profile is None:
        raise ValueError('Layout profile does not exist')
    if _profile_monitors(profile['monitors']) != monitors:
        raise ValueError('Monitor setup differs from this profile. Connect the original monitors before restoring.')
    before = _snapshot_fence_geometries()
    stored=profile['fences']
    missing=[name for name in stored if name not in before]
    if missing:
        raise ValueError('Saved Fence is unavailable or disabled: '+', '.join(missing))
    after={name:stored[name] for name in stored}
    original={name:before[name] for name in after}
    undo={'monitors':monitors,'before':original,'after':after}
    return _commit_geometries(after,undo)


def undo_layout_restore(monitors):
    monitors=_profile_monitors(monitors)
    state=_read_profiles()
    undo=state['undo']
    if undo is None:
        raise ValueError('No recent layout restore to undo')
    if _profile_monitors(undo['monitors']) != monitors:
        raise ValueError('Monitor setup changed; cannot safely undo')
    current=_snapshot_fence_geometries()
    for name,expected in undo['after'].items():
        if name not in current or current[name]!=expected:
            raise ValueError('Fence geometry changed since restore; refusing to overwrite changes')
    return _commit_geometries(undo['before'],None)


def main():
    parser = argparse.ArgumentParser(description='CinnaFences v0.4.1 configuratie')
    sub = parser.add_subparsers(dest='command', required=True)
    init = sub.add_parser('init', help='Eén Desktop-map als Fence activeren')
    init.add_argument('folder', type=Path)
    init.add_argument('--dry-run', action='store_true')
    allp = sub.add_parser('init-all', help='Alle directe Desktop-mappen activeren')
    allp.add_argument('--dry-run', action='store_true')
    for cmd in ('enable','disable','activate'):
        p = sub.add_parser(cmd)
        p.add_argument('folder', type=Path)
    hover = sub.add_parser('hover', help='Hover-effect in- of uitschakelen')
    hover.add_argument('folder', type=Path)
    hover.add_argument('state', choices=('on', 'off'))
    dm = sub.add_parser('desktop-mode', help='Optionele Nemo-desktopmodus (veilig en herstelbaar)')
    dm.add_argument('state', choices=('on', 'off', 'restore', 'status'))
    sub.add_parser('list', help='Toon status per Desktop-map')
    args = parser.parse_args()
    if args.command != 'desktop-mode' and not DESKTOP.is_dir():
        parser.error(f'Desktop-map bestaat niet: {DESKTOP}')
    try:
        if args.command == 'desktop-mode':
            desktop_mode(args.state)
        elif args.command == 'init':
            create(inside_desktop(args.folder), 50, 80, args.dry_run)
        elif args.command == 'init-all':
            folders = sorted((p for p in DESKTOP.iterdir() if p.is_dir() and not p.is_symlink()),
                             key=lambda p: p.name.casefold())
            for index, folder in enumerate(folders):
                create(folder, 40+(index%4)*365, 60+(index//4)*290, args.dry_run)
        elif args.command == 'activate':
            folder = inside_desktop(args.folder)
            target = folder / CONFIG
            if target.exists() or target.is_symlink():
                if target.is_symlink():
                    raise ValueError('Symlink naar Fence-config geweigerd')
                change_enabled(folder, True)
            else:
                create(folder, 50, 80)
        elif args.command in ('enable','disable'):
            change_enabled(inside_desktop(args.folder), args.command=='enable')
        elif args.command == 'hover':
            change_hover(inside_desktop(args.folder), args.state == 'on')
        elif args.command == 'list':
            for p in sorted(DESKTOP.iterdir(),key=lambda p:p.name.casefold()):
                if p.is_dir() and not p.is_symlink() and not p.name.startswith('.'):
                    f = p / CONFIG
                    if not f.exists(): status='gewone map'
                    else:
                        try:
                            data=json.loads(f.read_text(encoding='utf-8'))
                            status=('Fence actief' if data.get('enabled',True) and
                                    data.get('nofence') is not True else 'Fence uit')
                        except (OSError,ValueError,AttributeError): status='CONFIGFOUT'
                    print(f'{p.name:32} {status}')
    except (OSError, ValueError, json.JSONDecodeError, subprocess.CalledProcessError, SyntaxError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    main()


# Safe Fence management API used by the on-demand GTK settings window.
def managed_fences():
    """Return direct Desktop folders with a valid Fence config, enabled or not."""
    if not DESKTOP.is_dir():
        return []
    result=[]
    for folder in sorted(DESKTOP.iterdir(),key=lambda v:v.name.casefold()):
        if folder.is_symlink() or not folder.is_dir():
            continue
        target=folder/CONFIG
        if target.is_symlink() or not target.is_file():
            continue
        try:
            cfg=json.loads(target.read_text(encoding='utf-8'))
            if isinstance(cfg,dict):
                result.append((folder,cfg))
        except (OSError,ValueError):
            pass
    return result


def create_managed_fence(name, use_existing=False):
    """Never overwrite an existing Desktop folder or Fence configuration."""
    if not isinstance(name,str) or not name.strip() or name!=name.strip() or len(name)>100 or \
        name in ('.','..') or name.startswith('.') or any(c in name for c in '/\\\x00'):
        raise ValueError('Choose a valid folder name (no slashes or leading dot).')
    if DESKTOP.is_symlink():
        raise ValueError('Symlink Desktop is not supported')
    DESKTOP.mkdir(parents=True,exist_ok=True)
    folder=DESKTOP/name
    if folder.is_symlink():
        raise ValueError('Symlink destination refused')
    if folder.exists():
        if not use_existing or not folder.is_dir():
            raise ValueError('Folder already exists. Select "Use existing folder" to activate it.')
    else:
        folder.mkdir(mode=0o700) # exclusive; another process may race
    if not create(folder,80,80):
        raise ValueError('Fence configuration already exists. Use Enable instead.')
    return folder


def change_managed_fence(folder, *, enabled=None, hidden=None, title=None):
    folder=inside_desktop(folder)
    target=folder/CONFIG
    if target.is_symlink() or not target.is_file():
        raise ValueError('Fence configuration missing or unsafe')
    data=json.loads(target.read_text(encoding='utf-8'))
    if not isinstance(data,dict):
        raise ValueError('Invalid Fence configuration')
    if enabled is not None:
        if not isinstance(enabled,bool): raise ValueError('enabled must be bool')
        data['enabled']=enabled
    if hidden is not None:
        if not isinstance(hidden,bool): raise ValueError('hidden must be bool')
        data['hidden']=hidden
    if title is not None:
        if not isinstance(title,str) or not title.strip() or len(title.strip())>100:
            raise ValueError('Fence title must be 1–100 characters')
        data['title']=title.strip()
    _atomic_json_file(target,data)
    return True


def rename_icon_file(source, new_name):
    """Safely rename a rendered Fence item, no overwrite or symlink traversal."""
    from gi.repository import Gio
    if not isinstance(new_name,str) or not new_name.strip() or new_name != new_name.strip() or \
        new_name in ('.','..') or new_name.startswith('.') or len(new_name)>255 or \
        any(c in new_name for c in '/\\\x00'):
        raise ValueError('Invalid name (no slashes or hidden configuration files).')
    source=Path(source)
    folder=source.parent
    if folder.is_symlink(): raise ValueError('Refusing symlink section')
    if folder.parent == DESKTOP:
        root=folder
        rel_old=source.name; rel_new=new_name
    elif folder.parent.parent == DESKTOP and not folder.parent.is_symlink():
        root=folder.parent
        rel_old=folder.name+'/'+source.name
        rel_new=folder.name+'/'+new_name
    else: raise ValueError('File must be in a direct Fence folder or section')
    root=inside_desktop(root)
    cfg_path=root/CONFIG
    if cfg_path.is_symlink() or not cfg_path.is_file():
        raise ValueError('Missing Fence configuration')
    cfg=json.loads(cfg_path.read_text(encoding='utf-8'))
    if not isinstance(cfg,dict) or cfg.get('enabled') is False:
        raise ValueError('No active Fence')
    if source.name in (CONFIG, '.', '..') or source.name.startswith(CONFIG+'.'):
        raise ValueError('Cannot rename Fence configuration')
    if not source.exists() and not source.is_symlink():
        raise ValueError('File no longer exists')
    if source.name == new_name: return False
    target=folder/new_name
    if target.exists() or target.is_symlink():
        raise FileExistsError('A file with this name already exists')
    # Gio move WITHOUT OVERWRITE. Do not follow or touch a symlink target.
    Gio.File.new_for_path(str(source)).move(Gio.File.new_for_path(str(target)),
        Gio.FileCopyFlags.NONE,None,None)
    # Keep manual layout positions, if present, after a successful move.
    positions=cfg.get('icons',{}).get('positions',{})
    if isinstance(positions,dict) and rel_old in positions:
        positions[rel_new]=positions.pop(rel_old)
        try:_atomic_json_file(cfg_path,cfg)
        except Exception:
            # Roll back the filesystem rename when the config cannot be saved.
            try:
                Gio.File.new_for_path(str(target)).move(Gio.File.new_for_path(str(source)),
                    Gio.FileCopyFlags.NONE,None,None)
            except Exception: pass
            raise
    return True
