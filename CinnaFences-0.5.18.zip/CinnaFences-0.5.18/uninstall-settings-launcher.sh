#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
APP_DIR="$DATA_HOME/applications"
ICON_DIR="$DATA_HOME/icons/hicolor/scalable/apps"
TARGET="$APP_DIR/cinnafences-settings.desktop"
ICON="$ICON_DIR/cinnafences-settings.svg"
if [[ -f "$TARGET" && ! -L "$TARGET" ]] && grep -Fxq '# CinnaFences managed launcher' "$TARGET"; then
    rm -- "$TARGET"
fi
if [[ -f "$ICON" && ! -L "$ICON" ]] && cmp -s "$ICON" "$BASE/cinnafences@local/cinnafences-icon.svg"; then
    rm -- "$ICON"
fi
