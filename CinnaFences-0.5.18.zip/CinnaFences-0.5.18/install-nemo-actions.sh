#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
NEMO_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/nemo/actions"
HELPER_DIR="$NEMO_DIR/cinnafences"
if [[ -L "$NEMO_DIR" || -L "$HELPER_DIR" ]]; then
    echo 'Nemo action map is een symlink; uit veiligheid gestopt.' >&2
    exit 1
fi
mkdir -p "$NEMO_DIR"
for file in cinnafences-activate.nemo_action cinnafences-disable.nemo_action cinnafences-move.nemo_action cinnafences-shortcut.nemo_action cinnafences-launcher.nemo_action; do
    target="$NEMO_DIR/$file"
    if [[ -L "$target" ]]; then
        echo "Symlink bij $target geweigerd." >&2; exit 1
    fi
    if [[ -e "$target" ]] && ! grep -qx '# CinnaFences managed action' "$target"; then
        echo "Bestaande niet-CinnaFences Nemo action geweigerd: $target" >&2; exit 1
    fi
done
if [[ -e "$HELPER_DIR" && ! -d "$HELPER_DIR" ]]; then
    echo "Onverwacht pad bij $HELPER_DIR; gestopt." >&2; exit 1
fi
mkdir -p "$HELPER_DIR"
for file in dispatch.py cinnafences-config.py send-to-fence.py create-shortcut.py create-launcher.py; do
    if [[ -L "$HELPER_DIR/$file" ]]; then
        echo "Symlink bij $HELPER_DIR/$file geweigerd." >&2; exit 1
    fi
done
install -m 0755 "$BASE/nemo-actions/dispatch.py" "$HELPER_DIR/dispatch.py"
install -m 0755 "$BASE/nemo-actions/send-to-fence.py" "$HELPER_DIR/send-to-fence.py"
install -m 0755 "$BASE/nemo-actions/create-shortcut.py" "$HELPER_DIR/create-shortcut.py"
install -m 0755 "$BASE/nemo-actions/create-launcher.py" "$HELPER_DIR/create-launcher.py"
install -m 0644 "$BASE/tools/cinnafences-config.py" "$HELPER_DIR/cinnafences-config.py"
for file in cinnafences-activate.nemo_action cinnafences-disable.nemo_action cinnafences-move.nemo_action cinnafences-shortcut.nemo_action cinnafences-launcher.nemo_action; do
    install -m 0644 "$BASE/nemo-actions/$file" "$NEMO_DIR/$file"
done
echo "Nemo contextmenu's geïnstalleerd in: $NEMO_DIR"
echo 'Heropen zo nodig het contextmenu. Bij sommige Nemo-versies helpt een nieuwe sessie.'
