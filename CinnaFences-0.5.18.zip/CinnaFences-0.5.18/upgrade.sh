#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
SRC="$BASE/cinnafences@local"
EXT_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/cinnamon/extensions"
DST="$EXT_DIR/cinnafences@local"
BACKUP_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/cinnafences-backups"
if [[ ! -f "$SRC/extension.js" || ! -f "$SRC/metadata.json" ]]; then
    echo "Ontbrekende CinnaFences-bestanden." >&2; exit 1
fi
if [[ -L "$DST" ]]; then echo "Extensiemap is een symlink, afgebroken." >&2; exit 1; fi
if [[ -d "$DST" ]] && ! grep -Eq '"uuid"[[:space:]]*:[[:space:]]*"cinnafences@local"' "$DST/metadata.json"; then
    echo "Onverwachte extensie op $DST; afgebroken." >&2; exit 1
fi
mkdir -p "$EXT_DIR" "$BACKUP_DIR"
# Cinnamon scans everything below extensions; move old leftovers out of its path.
shopt -s nullglob
for d in "$EXT_DIR"/cinnafences@local.backup-* "$EXT_DIR"/cinnafences@local.new.*; do
    if [[ -d "$d" && ! -L "$d" ]]; then
        mv -- "$d" "$BACKUP_DIR/"
    fi
done
TEMP="$(mktemp -d "$EXT_DIR/.cinnafences-install-XXXXXX")"
cleanup() { if [[ -d "$TEMP" ]]; then rm -rf -- "$TEMP"; fi; }
trap cleanup EXIT
cp -a -- "$SRC/." "$TEMP/"
if [[ -d "$DST" ]]; then
    BACKUP="$BACKUP_DIR/cinnafences@local-$(date +%Y%m%d-%H%M%S)-$$"
    mv -- "$DST" "$BACKUP"
    if ! mv -- "$TEMP" "$DST"; then
        mv -- "$BACKUP" "$DST"
        echo "Installatie mislukt; oude extensie teruggezet." >&2
        exit 1
    fi
    echo "Back-up van vorige versie: $BACKUP"
else
    mv -- "$TEMP" "$DST"
fi
trap - EXIT
echo "CinnaFences v0.5.18 geïnstalleerd in: $DST"
echo "Schakel CinnaFences weer IN via Systeeminstellingen > Extensies."
echo "De Desktop-mappen en .cinnafence.json-bestanden blijven onaangetast."

# The Nemo action is independent from the extension; failure must not lose an installed fence.
if ! bash "$BASE/install-nemo-actions.sh"; then
    echo 'WAARSCHUWING: extensie bijgewerkt, maar Nemo-contextmenu niet geïnstalleerd.' >&2
fi

# Register the settings window as its own desktop application, giving docks
# a stable icon/title even when the Python UI is started by Cinnamon.
if ! bash "$BASE/install-settings-launcher.sh"; then
    echo 'WAARSCHUWING: instellingenvenster werkt, maar applicatieregistratie kon niet worden geïnstalleerd.' >&2
fi
