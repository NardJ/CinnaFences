#!/usr/bin/env bash
# Independent emergency exit: also works when Cinnamon is stopped.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$DIR/tools/cinnafences-config.py" desktop-mode restore
