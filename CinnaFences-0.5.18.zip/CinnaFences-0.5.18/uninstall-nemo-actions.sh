#!/usr/bin/env bash
set -euo pipefail
NEMO_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/nemo/actions"
if [[ -L "$NEMO_DIR" || -L "$NEMO_DIR/cinnafences" ]]; then
    echo 'Nemo action map is symlink; afgebroken.' >&2
    exit 1
fi
for file in cinnafences-activate.nemo_action cinnafences-disable.nemo_action cinnafences-move.nemo_action cinnafences-shortcut.nemo_action cinnafences-launcher.nemo_action; do
    target="$NEMO_DIR/$file"
    if [[ -f "$target" && ! -L "$target" ]] && grep -qx '# CinnaFences managed action' "$target"; then
        rm -- "$target"
    fi
done
helper="$NEMO_DIR/cinnafences"
if [[ -d "$helper" && ! -L "$helper" ]]; then
    # Do not remove unknown files added by the user.
    for f in dispatch.py cinnafences-config.py send-to-fence.py create-shortcut.py create-launcher.py; do
        [[ ! -f "$helper/$f" || -L "$helper/$f" ]] || rm -- "$helper/$f"
    done
    rmdir "$helper" 2>/dev/null || true
fi
echo 'CinnaFences Nemo-menuacties opgeruimd; Desktop-mappen onaangetast.'
