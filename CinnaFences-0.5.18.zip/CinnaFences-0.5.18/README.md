# CinnaFences v0.5.18 — Manage Fences Alignment & Rename Sync

Deze onderhoudsversie is gebaseerd op v0.5.17 en verandert de werking van de
bestandsacties, drag-and-drop, Nemo-integratie en inputregio niet.

## Wijzigingen

- **Manage Fences** heeft nu twee compacte, gelijk ingedeelde formulieren: labels
  in de eerste kolom, keuzelijst/invoerveld en contextknoppen op dezelfde hoogte.
  De status en beheeracties staan precies onder de Fence-keuze.
- **Per Fence** gebruikt in de keuzelijst nu de **zichtbare Fence-titel**, in
  plaats van uitsluitend de mapnaam. Bij een afwijkende titel wordt de
  oorspronkelijke map tussen vierkante haken vermeld: `Mijn werk [Werk]`.
- Een hernoeming in **Manage Fences** wordt onmiddellijk doorgevoerd in de
  Per Fence-keuze en, indien de titel niet lokaal bewerkt werd, het titelveld.
  Een titelwijziging via **Per Fence → Apply Fence settings** wordt eveneens
  direct zichtbaar in de Manage Fences-keuzelijst.
- Niet-opgeslagen wijzigingen in Per Fence blijven bewaard wanneer het beheerblad
  de lijst vernieuwt; Apply en Revert bepalen wat ermee gebeurt.
- **Remove from Desktop** blijft een zuivere deactivering en verwijdert geen bestanden.

## Installeren

Schakel eerst CinnaFences uit via **System Settings → Extensions** en sluit
het instellingenvenster. Pak vervolgens de ZIP uit en voer uit:

```bash
cd ~/Downloads
unzip CinnaFences-0.5.18.zip
cd CinnaFences-0.5.18
bash upgrade.sh
```

Schakel de extensie opnieuw in. Je bestaande config-bestanden en Desktop-items
worden tijdens de upgrade niet gewijzigd. De vorige extensie wordt geback-upt.

## Praktijktest

1. Open **Manage Fences**, selecteer `Coding` en klik **Rename…**.
2. Hernoem naar `Development`.
3. Open **Per Fence**: de keuze moet `Development [Coding]` tonen en
   bij **Fence & Layout** moet `Development` in het titelveld staan.
4. Pas nogmaals de titel aan via **Per Fence → Apply Fence settings** en
   controleer de Manage Fences-keuze.
5. Controleer uitlijning van Fence- en mapnaamvelden.

De broncode is automatisch getest, maar de GTK-opmaak moet nog op de echte
Cinnamon 6.6.9-desktop worden bekeken.
