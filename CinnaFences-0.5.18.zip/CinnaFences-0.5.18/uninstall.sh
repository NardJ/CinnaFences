#!/usr/bin/env bash
set -euo pipefail
DST="${XDG_DATA_HOME:-$HOME/.local/share}/cinnamon/extensions/cinnafences@local"
echo 'Schakel de extensie eerst uit via Systeeminstellingen > Extensies.'
read -r -p "Verwijder alleen de extensie uit $DST (j/N)? " reply
if [[ "$reply" == 'j' || "$reply" == 'J' ]]; then
  if [[ -f "$DST/metadata.json" ]] && grep -q '"uuid": "cinnafences@local"' "$DST/metadata.json"; then
    # Restore Nemo before removing the extension, even if Cinnamon is not running.
    python3 "$(dirname "$0")/tools/cinnafences-config.py" desktop-mode restore
    rm -rf -- "$DST"
    echo 'Extensie verwijderd. Desktop-mappen en hun .cinnafence.json blijven intact.'
    bash "$(dirname "$0")/uninstall-nemo-actions.sh"
    bash "$(dirname "$0")/uninstall-settings-launcher.sh"
  else
    echo 'Geen herkende CinnaFences-installatie gevonden. Niets gedaan.' >&2
    exit 2
  fi
fi
