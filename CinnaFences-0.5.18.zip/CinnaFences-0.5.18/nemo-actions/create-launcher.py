#!/usr/bin/env python3
"""CinnaFences: choose an active Fence/section and invoke Cinnamon's launcher editor.

No process stays resident. The editor writes into a private temporary subfolder
first; we atomically publish the finished .desktop with NO replacement of
existing entries. The original Fence configuration/files are never modified.
"""
import configparser
import re
import importlib.util
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile


def shortcut_helpers():
    helper = Path(__file__).resolve().parent / 'create-shortcut.py'
    spec = importlib.util.spec_from_file_location('cinnafence_shortcut_helper', helper)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def checked_target(desktop, fence, section='Main'):
    return shortcut_helpers().checked_destination(desktop, fence, section)


def valid_desktop_file(path):
    """Ensure that the staged file really looks like an Application launcher."""
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size == 0 or info.st_size > 1024 * 1024:
        raise ValueError('The desktop editor did not produce a normal launcher file')
    parser = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        with path.open('r', encoding='utf-8') as f:
            parser.read_file(f)
        section = parser['Desktop Entry']
        if section.get('Type') != 'Application' or not section.get('Name', '').strip() or not section.get('Exec', '').strip():
            raise ValueError('Launcher is missing Type=Application, Name or Exec')
    except (OSError, UnicodeError, configparser.Error, KeyError) as e:
        raise ValueError('The desktop editor did not produce a valid .desktop file') from e


def publish_launcher(stage, destination, filename):
    """Atomic no-clobber publication of a real launcher; never follow symlinks."""
    if (not filename or filename.startswith('.') or filename in ('.', '..') or
            '/' in filename or chr(92) in filename or not filename.endswith('.desktop')):
        raise ValueError('Invalid .desktop filename')
    staged = stage / filename
    valid_desktop_file(staged)
    flags = os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    stage_fd = os.open(stage, flags)
    dest_fd = os.open(destination, flags)
    try:
        # Both directories are on one filesystem because stage is inside destination.
        # link() fails atomically with EEXIST, including for existing symlinks.
        os.link(filename, filename, src_dir_fd=stage_fd, dst_dir_fd=dest_fd, follow_symlinks=False)
    except FileExistsError as e:
        raise FileExistsError(f'"{filename}" already exists in the destination. Choose a different launcher name.') from e
    finally:
        os.close(stage_fd)
        os.close(dest_fd)
    return destination / filename


# Nemo passes selected local files as %U. When no item is selected the
# standard empty launcher editor remains available.
def selected_launcher_source(argv, fallback=None):
    if not argv:
        # Nemo 6.x builds have sometimes emitted empty %U values for actions.
        # Nemo's documented script environment is an optional fallback.
        # Never use a shell to parse filenames; each newline is a path.
        fallback = os.environ.get('NEMO_SCRIPT_SELECTED_FILE_PATHS', '') if fallback is None else fallback
        argv = [p for p in fallback.splitlines() if p] if fallback else []
    if not argv:
        return None
    if len(argv) != 1:
        raise ValueError('Select exactly one application, script or .desktop file in Nemo')
    raw = shortcut_helpers().local_nemo_uri(argv[0])
    source = Path(raw)
    if not source.is_file() or source.is_symlink():
        raise ValueError('Select a normal local file (not a symlink or directory)')
    if source.suffix.lower() == '.desktop':
        return source
    if source.name.lower().endswith('.appimage'):
        if not os.access(source, os.X_OK):
            raise ValueError('The AppImage is not executable. In Nemo: Properties > Permissions > Allow executing file as program.')
        return source
    if os.access(source, os.X_OK):
        return source
    raise ValueError('Select an executable program, executable script, AppImage or .desktop file')


def quote_desktop_exec_path(path):
    """Produce a quoted executable token for a Desktop Entry Exec field.

    Desktop entries need two rounds of backslash escapes: one in the keyfile
    and one in the Exec quoting syntax. Avoid shell invocation altogether.
    """
    path = str(path)
    if '\n' in path or '\r' in path or '\x00' in path:
        raise ValueError('Executable filename contains an unsupported control character')
    result = []
    for ch in path:
        if ch == '\\':
            result.append('\\\\\\\\')
        elif ch in ('"', '$', '`'):
            result.append('\\\\' + ch)
        else:
            result.append(ch)
    return '"' + ''.join(result) + '"'


def app_display_name(source):
    stem = source.name
    if stem.lower().endswith('.appimage'):
        stem = stem[:-len('.AppImage')]
    else:
        stem = source.stem
    # Trim common AppImage architecture/version suffixes, but keep meaningful
    # words such as Repetier Host or FreeCAD.
    stem = re.sub(r'(?i)([-_. ](?:x86[_-]?64|amd64|aarch64|arm64|i386|i686)(?:[-_. ]|$))', ' ', stem)
    stem = re.sub(r'(?i)(?:[-_. ]+v?\d+(?:\.\d+){1,5}(?:[-_. ].*)?)$', '', stem)
    stem = re.sub(r'[-_]+', ' ', stem).strip(' .-')
    return stem or source.stem


def nearby_icon(source):
    """Find a sidecar icon only; do NOT execute an AppImage to extract icons."""
    words = re.findall(r'[a-z]{4,}', app_display_name(source).casefold())
    if not words:
        return None
    try:
        candidates = []
        for item in source.parent.iterdir():
            if not item.is_file() or item.is_symlink() or item.suffix.lower() not in ('.png', '.svg', '.xpm'):
                continue
            lname = item.stem.casefold()
            matches = sum(word in lname for word in words)
            if not matches:
                continue
            # Prioritize files matching more of the application name. Slight
            # preference for explicit icon sizes (e.g. repetier_48x48.png).
            score = matches * 10 + int('icon' in lname or re.search(r'\d+x\d+', lname) is not None)
            candidates.append((score, item))
        if candidates:
            return str(max(candidates, key=lambda x: (x[0], x[1].name))[1])
    except OSError:
        pass
    return None


def launcher_defaults(source):
    """Return prefilled Desktop Entry fields; the user can edit in Cinnamon."""
    if source is None:
        return None
    if source.suffix.lower() == '.desktop':
        cp = configparser.ConfigParser(interpolation=None, strict=False)
        cp.optionxform = str
        try:
            with source.open('r', encoding='utf-8') as f:
                cp.read_file(f)
            entry = cp['Desktop Entry']
        except (UnicodeError, OSError, configparser.Error, KeyError) as e:
            raise ValueError('Selected .desktop file cannot be read') from e
        if entry.get('Type', '') != 'Application' or not entry.get('Exec', '').strip():
            raise ValueError('Selected .desktop file is not a valid application launcher')
        return {
            'Name': entry.get('Name', source.stem),
            'Exec': entry.get('Exec', ''),
            'Icon': entry.get('Icon', 'application-x-executable'),
            'Comment': entry.get('Comment', ''),
            'Terminal': entry.get('Terminal', 'false'),
        }
    icon = nearby_icon(source) or ('application-x-executable' if source.name.lower().endswith('.appimage') else 'text-x-script')
    return {
        'Name': app_display_name(source),
        'Exec': quote_desktop_exec_path(source),
        'Icon': icon,
        'Comment': f'Launch {source.name}',
        'Terminal': 'false',
    }


def write_prefill(path, fields):
    """Write an editor-readable .desktop seed outside its output directory."""
    parser = configparser.ConfigParser(interpolation=None)
    parser.optionxform = str
    parser['Desktop Entry'] = {'Type': 'Application', **fields}
    with path.open('w', encoding='utf-8') as f:
        parser.write(f, space_around_delimiters=False)


def create_launcher(desktop, fence, section='Main', editor='cinnamon-desktop-editor', runner=None, source=None):
    """Open standard editor on demand; return created path, or None on Cancel.

    The runner injection is used only by tests to simulate the standard editor.
    """
    destination = checked_target(desktop, fence, section)
    if not destination.is_dir():
        raise ValueError('Destination folder is unavailable')
    initial = destination.stat()
    editor_binary = shutil.which(editor) if runner is None else editor
    if not editor_binary:
        raise FileNotFoundError('Cinnamon Desktop Editor is not installed or not in PATH')
    defaults = launcher_defaults(source)
    with tempfile.TemporaryDirectory(prefix='.cinnafences-launcher-', dir=destination) as folder:
        stage = Path(folder)
        output = stage / 'output'
        output.mkdir()
        command = [editor_binary, '-m', 'nemo-launcher', '-d', str(output)]
        if defaults is not None:
            seed = stage / 'prefill.desktop'
            write_prefill(seed, defaults)
            command += ['-o', str(seed)]
        result = (runner or subprocess.run)(command, check=False)
        if result.returncode != 0:
            raise RuntimeError('Cinnamon Desktop Editor closed with an error')
        launchers = [p for p in output.iterdir() if p.suffix == '.desktop']
        if not launchers:
            # Normal cancellation in Cinnamon Desktop Editor returns success.
            return None
        if len(launchers) != 1:
            raise ValueError('The editor created more than one launcher; nothing was installed')
        # Recheck enabled Fence and unchanged filesystem directory after editor ran.
        checked_again = checked_target(desktop, fence, section)
        current = checked_again.stat()
        if (checked_again != destination or (current.st_dev, current.st_ino) != (initial.st_dev, initial.st_ino)):
            raise ValueError('Destination changed while the editor was open')
        return publish_launcher(output, destination, launchers[0].name)


def main():
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk
    h = shortcut_helpers()
    try:
        source = selected_launcher_source(sys.argv[1:])
    except ValueError as e:
        h.error_dialog(Gtk, 'Cannot create launcher from selection', e)
        return 2
    desktop = Path.home() / 'Desktop'
    available = h.active_fences(desktop)
    if not available:
        h.error_dialog(Gtk, 'No active CinnaFences found', 'Activate a Desktop folder as a Fence first.')
        return 1
    dialog = Gtk.Dialog(title='Create application launcher in CinnaFence', flags=Gtk.DialogFlags.MODAL)
    dialog.add_button('Cancel', Gtk.ResponseType.CANCEL)
    dialog.add_button('Open Cinnamon Desktop Editor', Gtk.ResponseType.OK)
    dialog.set_default_response(Gtk.ResponseType.CANCEL)
    dialog.set_resizable(False)
    area = dialog.get_content_area()
    area.set_spacing(12)
    area.set_border_width(16)
    grid = Gtk.Grid(column_spacing=12, row_spacing=10)
    area.add(grid)
    grid.attach(Gtk.Label(label='Fence:', xalign=0), 0, 0, 1, 1)
    fence_combo = Gtk.ComboBoxText()
    for name, _ in available: fence_combo.append_text(name)
    grid.attach(fence_combo, 1, 0, 1, 1)
    grid.attach(Gtk.Label(label='Folder / section:', xalign=0), 0, 1, 1, 1)
    section_combo = Gtk.ComboBoxText()
    grid.attach(section_combo, 1, 1, 1, 1)
    sections = []

    def update_sections(*_):
        sections.clear()
        section_combo.remove_all()
        idx = fence_combo.get_active()
        if idx < 0: return
        try:
            sections.extend(h.destinations(available[idx][1]))
            for name, _path in sections: section_combo.append_text(name)
            section_combo.set_active(0)
        except OSError:
            pass

    fence_combo.connect('changed', update_sections)
    fence_combo.set_active(0)
    message = ('Cinnamon Desktop Editor opens with Name, Command and Icon prefilled.\n'
               if source else 'No file selected: create a launcher from scratch.\n')
    label = Gtk.Label(label=message +
                            'The new .desktop file will be saved in the chosen section.\n'
                            'Existing files are never overwritten.', xalign=0)
    area.add(label)
    dialog.show_all()
    response = dialog.run()
    idx, section_idx = fence_combo.get_active(), section_combo.get_active()
    section = sections[section_idx][0] if 0 <= section_idx < len(sections) else None
    dialog.destroy()
    if response != Gtk.ResponseType.OK:
        return 0
    if idx < 0 or section is None:
        h.error_dialog(Gtk, 'No destination selected', 'Choose a Fence and a folder.')
        return 1
    try:
        create_launcher(desktop, available[idx][1], section, source=source)
    except (OSError, ValueError, RuntimeError) as e:
        h.error_dialog(Gtk, 'Could not create application launcher', e)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
