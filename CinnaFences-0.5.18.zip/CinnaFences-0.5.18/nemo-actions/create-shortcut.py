#!/usr/bin/env python3
"""Create safe local symlink shortcuts from Nemo inside a CinnaFence section.

GTK is started only on demand. Never moves/copies the selected originals.
No overwrite, no following destination symlinks, and rollback on partial failure.
"""
import importlib.util
import os
from pathlib import Path
import stat
import sys
from urllib.parse import urlsplit, unquote_to_bytes

CONFIG = '.cinnafence.json'
MAX_SELECTED = 32


def local_nemo_uri(uri):
    """Accept local file:// URIs from Nemo's %U (not shell-unsafe %F)."""
    if uri.startswith('/'):
        return str(Path(uri))  # helpful for command-line/manual test use
    try:
        parts = urlsplit(uri)
        if parts.scheme != 'file' or parts.netloc not in ('', 'localhost') or \
                parts.query or parts.fragment:
            raise ValueError('Only local files and folders are supported')
        decoded = unquote_to_bytes(parts.path).decode('utf-8', 'strict')
        if not decoded.startswith('/') or '\x00' in decoded:
            raise ValueError('Invalid local file URL')
        return decoded
    except (UnicodeError, ValueError) as exc:
        raise ValueError(f'Invalid or remote Nemo selection: {uri[:160]}') from exc


def active_fences(desktop):
    # Reuse the same definition as the existing Move to CinnaFence action.
    helper = Path(__file__).resolve().parent / 'send-to-fence.py'
    spec = importlib.util.spec_from_file_location('cinnafence_move_helper', helper)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.active_fences(desktop)


def destinations(fence):
    """Main plus direct real subfolders, matching Tabs and Rolodex."""
    fence = Path(fence)
    groups = [('Main', fence)]
    for p in sorted(fence.iterdir(), key=lambda x: x.name.casefold()):
        if p.name.startswith('.') or p.is_symlink() or not p.is_dir():
            continue
        groups.append((p.name, p))
    return groups


def checked_destination(desktop, fence, section='Main'):
    """Return destination after rechecking enabled Fence + direct child boundary."""
    desktop, fence = Path(desktop), Path(fence)
    available = dict(active_fences(desktop))
    if fence.name not in available or available[fence.name] != fence:
        raise ValueError('The destination Fence is no longer active')
    if not fence.is_dir() or fence.is_symlink() or fence.parent.resolve() != desktop.resolve():
        raise ValueError('Destination is not a direct Desktop Fence')
    dest = fence if section == 'Main' else fence / section
    if section != 'Main' and (not section or '/' in section or section.startswith('.') or section in ('.', '..')):
        raise ValueError('Invalid section name')
    if not dest.is_dir() or dest.is_symlink():
        raise ValueError('The selected section no longer exists')
    if section != 'Main' and dest.parent != fence:
        raise ValueError('Only direct subfolders can be used as sections')
    return dest


def checked_source(source):
    src = Path(source)
    if not src.is_absolute() or src.name.startswith('.') or src.is_symlink():
        raise ValueError(f'Choose an ordinary local file or folder: {src}')
    if not (src.is_file() or src.is_dir()):
        raise ValueError(f'Item is missing or not a regular local file/folder: {src}')
    if src.is_dir() and (src / CONFIG).exists():
        raise ValueError('Cannot create a shortcut to an entire active Fence folder')
    return src


def shortcut_filename(src, used, existing):
    """Preserve extension (.desktop included), append suffix if name is occupied."""
    name = src.name
    if name not in used and name not in existing:
        return name
    stem, ext = src.stem, src.suffix
    # Hidden dotfiles are already rejected above.
    for number in range(1, 1001):
        suffix = ' (shortcut)' if number == 1 else f' (shortcut {number})'
        candidate = stem + suffix + ext
        if candidate not in used and candidate not in existing:
            return candidate
    raise ValueError('Too many shortcuts with the same name')


def prepare_shortcuts(sources, desktop, fence, section='Main'):
    """Preflight every item and return immutable (target-name, source-path) pairs."""
    if not sources or len(sources) > MAX_SELECTED:
        raise ValueError(f'Select 1–{MAX_SELECTED} items in Nemo')
    dest = checked_destination(desktop, fence, section)
    resolved = [checked_source(s) for s in sources]
    if len(set(resolved)) != len(resolved):
        raise ValueError('The same item was selected more than once')
    # Symbolic links may refer to locations outside the Fence. Never follow
    # destination symlinks when deciding whether a filename is available.
    existing = {entry.name for entry in dest.iterdir()}
    targets = set()
    planned = []
    for src in resolved:
        if src.is_dir() and (dest == src or src in dest.parents):
            raise ValueError('Cannot make a directory shortcut within itself')
        # Avoid filling the Fence with duplicate links to exactly the same file.
        for entry in dest.iterdir():
            if entry.is_symlink() and os.path.realpath(entry) == os.path.realpath(src):
                raise ValueError(f'Shortcut already exists for {src.name}: {entry.name}')
        name = shortcut_filename(src, targets, existing)
        targets.add(name)
        planned.append((name, str(src.resolve())))
    return dest, tuple(planned)


def create_shortcuts(sources, desktop, fence, section='Main', symlink_creator=None):
    """Create all symlinks without overwrites; roll back only our own on failure.

    Uses directory-fd operations to protect against a symlink substitution
    of the destination directory between preflight and file creation.
    """
    dest, plan = prepare_shortcuts(sources, desktop, fence, section)
    flags = os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(dest, flags)
    created = []
    try:
        real_dest = os.fstat(fd)
        current_dest = os.stat(dest, follow_symlinks=False)
        if (real_dest.st_dev, real_dest.st_ino) != (current_dest.st_dev, current_dest.st_ino):
            raise ValueError('Destination changed during selection')
        for name, target in plan:
            if symlink_creator is None:
                os.symlink(target, name, dir_fd=fd)
            else:
                symlink_creator(target, name, fd)
            linkstat = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if not stat.S_ISLNK(linkstat.st_mode):
                raise ValueError('Shortcut creation did not produce a symbolic link')
            created.append((name, target, linkstat.st_dev, linkstat.st_ino))
        return [dest / name for name, *_ in created]
    except Exception:
        for name, target, dev, inode in reversed(created):
            try:
                current = os.stat(name, dir_fd=fd, follow_symlinks=False)
                if (current.st_dev, current.st_ino) == (dev, inode) and os.readlink(name, dir_fd=fd) == target:
                    os.unlink(name, dir_fd=fd)
            except OSError:
                pass
        raise
    finally:
        os.close(fd)


def error_dialog(Gtk, title, details):
    msg = Gtk.MessageDialog(message_type=Gtk.MessageType.ERROR, buttons=Gtk.ButtonsType.OK, text=title)
    msg.format_secondary_text(str(details))
    msg.run()
    msg.destroy()


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk
    desktop = Path.home() / 'Desktop'
    available = active_fences(desktop)
    if not available:
        error_dialog(Gtk, 'No active CinnaFences found', 'Activate a Desktop folder as a Fence first.')
        return 1
    if not argv or len(argv) > MAX_SELECTED:
        error_dialog(Gtk, 'Incorrect selection', f'Select 1–{MAX_SELECTED} files or folders in Nemo.')
        return 2
    try:
        selected_sources = [local_nemo_uri(arg) for arg in argv]
    except ValueError as exc:
        error_dialog(Gtk, 'Local files only', exc)
        return 2

    dialog = Gtk.Dialog(title='Create shortcut in CinnaFence', flags=Gtk.DialogFlags.MODAL)
    dialog.add_button('Cancel', Gtk.ResponseType.CANCEL)
    dialog.add_button('Create shortcut' if len(argv) == 1 else 'Create shortcuts', Gtk.ResponseType.OK)
    dialog.set_default_response(Gtk.ResponseType.CANCEL)
    dialog.set_resizable(False)
    area = dialog.get_content_area()
    area.set_spacing(10)
    area.set_border_width(16)
    area.add(Gtk.Label(label=('Shortcut for: ' + Path(selected_sources[0]).name) if len(argv) == 1 else
                             f'Shortcuts for {len(argv)} selected items'))
    grid = Gtk.Grid(column_spacing=12, row_spacing=10)
    area.add(grid)
    grid.attach(Gtk.Label(label='Fence:', xalign=0), 0, 0, 1, 1)
    fence_combo = Gtk.ComboBoxText()
    for name, _ in available:
        fence_combo.append_text(name)
    grid.attach(fence_combo, 1, 0, 1, 1)
    grid.attach(Gtk.Label(label='Folder / section:', xalign=0), 0, 1, 1, 1)
    section_combo = Gtk.ComboBoxText()
    grid.attach(section_combo, 1, 1, 1, 1)
    section_list = []

    def update_sections(*_):
        section_list.clear()
        section_combo.remove_all()
        idx = fence_combo.get_active()
        if idx < 0:
            return
        try:
            section_list.extend(destinations(available[idx][1]))
            for name, _ in section_list:
                section_combo.append_text(name)
            section_combo.set_active(0)
        except OSError:
            pass

    fence_combo.connect('changed', update_sections)
    fence_combo.set_active(0)
    info = Gtk.Label(label='Creates links only. Original files and folders stay in place.\n'
                           'Existing destination files are never overwritten.', xalign=0)
    area.add(info)
    dialog.show_all()
    response = dialog.run()
    idx, sec_idx = fence_combo.get_active(), section_combo.get_active()
    section_name = section_list[sec_idx][0] if 0 <= sec_idx < len(section_list) else None
    dialog.destroy()
    if response != Gtk.ResponseType.OK:
        return 0
    if idx < 0 or section_name is None:
        error_dialog(Gtk, 'No destination selected', 'Choose a Fence and a folder.')
        return 1
    try:
        create_shortcuts(selected_sources, desktop, available[idx][1], section_name)
    except (OSError, ValueError) as exc:
        error_dialog(Gtk, 'Could not create shortcuts', exc)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
