#!/usr/bin/env python3
"""Nemo action: safely move one selected local item into a chosen active Fence.

GTK runs only while the user invokes the action; no persistent background app.
No overwrite, no following symlinks, no file mutations before confirmation.
"""
import json
import os
from pathlib import Path
import sys

CONFIG = '.cinnafence.json'


def active_fences(desktop):
    """List only real, enabled folders directly below the Desktop directory."""
    desktop = Path(desktop)
    if not desktop.is_dir() or desktop.is_symlink():
        return []
    found = []
    for folder in desktop.iterdir():
        if not folder.is_dir() or folder.is_symlink():
            continue
        cfg = folder / CONFIG
        if cfg.is_symlink() or not cfg.is_file():
            continue
        try:
            settings = json.loads(cfg.read_text(encoding='utf-8'))
        except (ValueError, OSError, UnicodeError):
            continue
        if isinstance(settings, dict) and settings.get('enabled') is not False and settings.get('nofence') is not True:
            found.append((folder.name, folder))
    return sorted(found, key=lambda x: x[0].casefold())


def validate_move(source, dest_folder, desktop):
    """Return safe destination path or raise ValueError before any mutation."""
    source = Path(source)
    dest_folder = Path(dest_folder)
    desktop = Path(desktop)
    if (source.is_symlink() or not source.exists() or
            not (source.is_file() or source.is_dir())):
        raise ValueError('Source must be an existing regular file or folder (not a symlink)')
    if not source.is_absolute() or source.name.startswith('.'):
        raise ValueError('Select an ordinary local file or folder')
    if source.is_dir() and ((source / CONFIG).exists() or (source / CONFIG).is_symlink()):
        raise ValueError('An entire Fence folder cannot be moved')
    if dest_folder.is_symlink() or not dest_folder.is_dir() or dest_folder.parent.resolve() != desktop.resolve():
        raise ValueError('Destination must be a direct Desktop folder')
    if dest_folder not in (folder for _, folder in active_fences(desktop)):
        raise ValueError('Destination Fence is no longer enabled')
    canonical_source = source.resolve()
    canonical_dest = dest_folder.resolve()
    if canonical_source == canonical_dest or canonical_source in canonical_dest.parents:
        raise ValueError('Cannot move a folder into itself or one of its descendants')
    target = dest_folder / source.name
    if target.exists() or target.is_symlink():
        raise ValueError('A file with that name already exists in the destination')
    return target


def safe_move(source, target, mover=None):
    """No-overwrite Gio move; passing mover supports isolated filesystem tests."""
    if mover is None:
        from gi.repository import Gio
        mover = lambda s, t: Gio.File.new_for_path(str(s)).move(
            Gio.File.new_for_path(str(t)), Gio.FileCopyFlags.NONE, None, None)
    return mover(source, target)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        print('Select a single file or folder in Nemo', file=sys.stderr)
        return 2
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk
    source = Path(argv[0])
    desktop = Path.home() / 'Desktop'
    available = active_fences(desktop)
    if not available:
        dialog = Gtk.MessageDialog(message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text='No active CinnaFences found')
        dialog.format_secondary_text('Create and activate a Fence from a Desktop folder first.')
        dialog.run(); dialog.destroy()
        return 1
    dialog = Gtk.Dialog(title='Move to CinnaFence', flags=Gtk.DialogFlags.MODAL)
    dialog.add_button('Cancel', Gtk.ResponseType.CANCEL)
    dialog.add_button('Move file', Gtk.ResponseType.OK)
    dialog.set_default_response(Gtk.ResponseType.CANCEL)
    dialog.set_resizable(False)
    contents = dialog.get_content_area()
    contents.set_spacing(12)
    contents.set_border_width(16)
    contents.add(Gtk.Label(label='Move "'+source.name+'" into:'))
    combo = Gtk.ComboBoxText()
    for name, _ in available:
        combo.append_text(name)
    combo.set_active(0)
    contents.add(combo)
    contents.add(Gtk.Label(label='The item will be moved, not copied. Existing files are never overwritten.'))
    dialog.show_all()
    response = dialog.run()
    selected = combo.get_active()
    dialog.destroy()
    if response != Gtk.ResponseType.OK or selected < 0:
        return 0
    try:
        target = validate_move(source, available[selected][1], desktop)
        safe_move(source, target)
    except Exception as exc:
        error = Gtk.MessageDialog(message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK, text='Could not move the item')
        error.format_secondary_text(str(exc))
        error.run(); error.destroy()
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
