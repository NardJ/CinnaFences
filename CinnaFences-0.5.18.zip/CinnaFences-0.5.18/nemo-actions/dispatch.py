#!/usr/bin/env python3
"""Nemo action helper: delegate safely to the installed configuration CLI.

The directory must be directly under Desktop. The CLI enforces that boundary.
"""
import os
from pathlib import Path
import sys


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ('activate', 'disable'):
        print('Gebruik: dispatch.py activate|disable /pad/naar/Desktop/map', file=sys.stderr)
        return 2
    cli = Path(__file__).resolve().parent / 'cinnafences-config.py'
    if not cli.is_file():
        print('CinnaFences-confighelper niet geïnstalleerd', file=sys.stderr)
        return 2
    os.execv(sys.executable, [sys.executable, str(cli), sys.argv[1], sys.argv[2]])


if __name__ == '__main__':
    sys.exit(main())
