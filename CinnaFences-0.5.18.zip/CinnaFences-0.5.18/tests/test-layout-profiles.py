#!/usr/bin/env python3
"""Profile snapshot/restore/undo tests without Cinnamon, GDK or user files."""
import importlib.util
import json
from pathlib import Path
import tempfile

SOURCE=Path(__file__).resolve().parents[1]/'tools/cinnafences-config.py'
spec=importlib.util.spec_from_file_location('fence_layout_config',SOURCE)
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
ONE=[{'x':0,'y':0,'width':1920,'height':1080}]
DUAL=[{'x':0,'y':0,'width':1920,'height':1080},
      {'x':1920,'y':0,'width':2560,'height':1440}]
with tempfile.TemporaryDirectory(prefix='cf-layout-profile-') as temp:
    home=Path(temp)
    c.DESKTOP=home/'Desktop';c.DESKTOP.mkdir()
    c.GLOBAL_PATH=home/'.config/cinnafences/defaults.json'
    first=c.DESKTOP/'3D';second=c.DESKTOP/'Games VR'
    first.mkdir();second.mkdir()
    for folder in [first,second]:
        c.create(folder,50,80)
    target1=first/c.CONFIG;target2=second/c.CONFIG
    data=json.loads(target1.read_text());data['icons']['positions']={'test.desktop':[2,3]}
    data['geometry']={'x':2050,'y':60,'width':380,'height':270};target1.write_text(json.dumps(data))
    data2=json.loads(target2.read_text());data2['geometry']={'x':120,'y':500,'width':430,'height':320};target2.write_text(json.dumps(data2))
    other_file=first/'DO_NOT_TOUCH.txt';other_file.write_text('original')
    assert c.save_layout_profile('Dual',DUAL)==2
    assert len(c.list_layout_profiles())==1
    assert c._read_profiles()['profiles']['Dual']['fences']['3D']['x']==2050
    # Reset and save a separate single-monitor layout, then manually restore dual.
    for path in (target1,target2):
        d=json.loads(path.read_text());d['geometry']['x']=100;d['geometry']['y']=120
        path.write_text(json.dumps(d))
    assert c.save_layout_profile('Single',ONE)==2
    before1=json.loads(target1.read_text());before2=json.loads(target2.read_text())
    before_bytes1=target1.read_bytes()
    assert len(c.list_layout_profiles())==2
    try:
        c.restore_layout_profile('Dual',ONE)
        assert False,'Mismatched setup restored'
    except ValueError as exc:
        assert 'Monitor setup' in str(exc)
    assert target1.read_bytes()==before_bytes1
    assert c.restore_layout_profile('Dual',DUAL)==2
    after1=json.loads(target1.read_text());after2=json.loads(target2.read_text())
    assert after1['geometry']['x']==2050 and after1['geometry']['width']==380
    assert after2['geometry']['x']==120 and after2['geometry']['y']==500
    assert after1['icons']==before1['icons'] and after2['icons']==before2['icons']
    assert other_file.read_text()=='original'
    assert c.can_undo_layout_restore()
    assert c.undo_layout_restore(DUAL)==2
    assert json.loads(target1.read_text())['geometry']==before1['geometry']
    assert json.loads(target2.read_text())['geometry']==before2['geometry']
    assert not c.can_undo_layout_restore()
    # Undo refuses to overwrite later manual resizing or dragging.
    c.restore_layout_profile('Dual',DUAL)
    current=json.loads(target1.read_text());current['geometry']['x']=2100
    target1.write_text(json.dumps(current))
    try:
        c.undo_layout_restore(DUAL)
        assert False,'Undo clobbered a manual change'
    except ValueError as exc:
        assert 'changed since restore' in str(exc)
    assert json.loads(target1.read_text())['geometry']['x']==2100
    for invalid in ('../Escape','',' /bad','a/b', 'x'*49):
        original=c._profiles_path().read_bytes()
        try:
            c.save_layout_profile(invalid,ONE)
            raise AssertionError('Invalid name accepted '+repr(invalid))
        except ValueError:pass
        assert c._profiles_path().read_bytes()==original
    bad_setup=[{'x':0,'y':0,'width':False,'height':1080}]
    try:c.save_layout_profile('Bad setup',bad_setup);assert False
    except ValueError:pass
    # A disabled saved Fence refuses restore rather than silently half-applying.
    c.change_enabled(second,False)
    saved=target1.read_bytes()
    try:c.restore_layout_profile('Dual',DUAL);assert False
    except ValueError as exc:assert 'unavailable' in str(exc)
    assert target1.read_bytes()==saved
    c.change_enabled(second,True)
    c.delete_layout_profile('Single')
    assert [p['name'] for p in c.list_layout_profiles()]==['Dual']
    # Rollback after a simulated write failure on the *second* config.
    first_before=target1.read_bytes();second_before=target2.read_bytes()
    real_atomic=c._atomic_json_file
    state={'counter':0}
    def broken(path,document):
        if path.name==c.CONFIG:
            state['counter']+=1
            if state['counter']==2:
                raise OSError('Simulated disk/write error')
        return real_atomic(path,document)
    c._atomic_json_file=broken
    try:
        c.restore_layout_profile('Dual',DUAL)
        raise AssertionError('Partial restore was accepted')
    except RuntimeError as exc:
        assert 'rolled back' in str(exc)
    finally:c._atomic_json_file=real_atomic
    assert target1.read_bytes()==first_before and target2.read_bytes()==second_before
    # Path safety: malicious saved name cannot break out of the Desktop.
    state=c._read_profiles();state['profiles']['Dual']['fences']['../out']={'x':1,'y':1,'width':350,'height':270}
    c._atomic_json_file(c._profiles_path(),state)
    try:c.restore_layout_profile('Dual',DUAL);assert False
    except ValueError as exc:assert 'Unsafe Desktop folder' in str(exc)
    print('OK: profiles, monitor matching, undo, rollback, Desktop safety, preservation')
