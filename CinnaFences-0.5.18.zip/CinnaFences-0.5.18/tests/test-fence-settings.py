#!/usr/bin/env python3
"""Per-Fence settings tests use a disposable HOME; never modify real Desktop."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile

root = Path(__file__).resolve().parents[1]
module_path = root / 'tools' / 'cinnafences-config.py'
with tempfile.TemporaryDirectory(prefix='cinnafence-per-fence-') as temp:
    home = Path(temp)
    desktop = home / 'Desktop'
    folder = desktop / 'My Games'
    folder.mkdir(parents=True)
    (folder / 'DO-NOT-DELETE.desktop').write_text('original launcher', encoding='utf8')
    spec = importlib.util.spec_from_file_location('test_cinnafences_cli', module_path)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    config.DESKTOP = desktop
    config.create(folder, 50, 80)
    path = folder / config.CONFIG
    before = json.loads(path.read_text())
    before['unrecognizedFutureField'] = {'remember': 123}
    before['icons']['positions'] = {'DO-NOT-DELETE.desktop': [2, 4]}
    before['geometry'] = {'x': 234, 'y': 123, 'width': 521, 'height': 365}
    path.write_text(json.dumps(before))

    assert config.active_fence_folders() == [folder]
    assert config.read_fence_settings(folder)['title'] == 'My Games'
    assert config.update_fence_settings(folder, {
        'title': 'Mijn spellen', 'appearance.backgroundOpacity': .35,
        'icons.size': 72, 'icons.showLabels': False, 'geometryLocked': True,
        'appearance.background': '#ab42EF', 'appearance.hoverEnabled': False})
    updated = json.loads(path.read_text())
    assert updated['title'] == 'Mijn spellen'
    assert updated['geometryLocked'] is True
    assert updated['icons']['showLabels'] is False
    assert updated['icons']['size'] == 72
    assert updated['icons']['gridWidth'] >= 80
    assert updated['icons']['gridHeight'] >= 93
    assert updated['appearance']['hoverEnabled'] is False
    assert updated['unrecognizedFutureField'] == before['unrecognizedFutureField']
    assert updated['geometry'] == before['geometry']
    assert updated['icons']['positions'] == before['icons']['positions']
    assert (folder / 'DO-NOT-DELETE.desktop').read_text() == 'original launcher'
    assert not list(folder.glob('.cinnafence.json.*.tmp'))

    snapshot = path.read_bytes()
    for field, value in [
        ('icons.size', 500), ('icons.size', 48.5),
        ('appearance.backgroundOpacity', -0.1),
        ('appearance.background', 'blue'),
        ('appearance.hoverEnabled', 'false'),
        ('geometry.x', 50), ('title', ''), ('geometryLocked', 1),
    ]:
        try:
            config.update_fence_settings(folder, {field: value})
            raise AssertionError(f'Invalid value was accepted: {field}={value}')
        except ValueError:
            pass
        assert path.read_bytes() == snapshot, field

    other = home / 'Documents'
    other.mkdir()
    try:
        config.update_fence_settings(other, {'title': 'Impossible'})
        raise AssertionError('Outside-Desktop folder was accepted')
    except ValueError:
        pass

    config.change_enabled(folder, False)
    assert config.active_fence_folders() == []
    try:
        config.update_fence_settings(folder, {'title': 'Disabled'})
        raise AssertionError('Disabled Fence was edited')
    except ValueError:
        pass
    assert json.loads(path.read_text())['title'] == 'Mijn spellen'

print('OK: Fence-instellingen, veilige merges, iconposities, grenzen en rollback')

# v0.2.7: exact numeric width and height, preserving x/y and manual icon layout.
with tempfile.TemporaryDirectory(prefix='cinnafence-geometry-') as temp:
    desktop = Path(temp)/'Desktop'
    folder = desktop/'Wide Screens'
    folder.mkdir(parents=True)
    config.DESKTOP = desktop
    config.create(folder, 50, 80)
    path = folder/config.CONFIG
    before = json.loads(path.read_text())
    before['icons']['positions'] = {'a.desktop': [2, 4]}
    before['icons']['layoutColumns'] = 3
    before['icons']['undoArrangement'] = {'positions':{'a.desktop':[0,1]},'layoutColumns':3}
    path.write_text(json.dumps(before))
    assert config.update_fence_settings(folder, {'geometry.width': 840, 'geometry.height': 610})
    after=json.loads(path.read_text())
    assert after['geometry']=={'x':50,'y':80,'width':840,'height':610}
    assert after['icons']==before['icons']
    assert after['appearance']==before['appearance']
    unchanged=path.read_bytes()
    for bad in ({'geometry.width':171}, {'geometry.height':1601},
                {'geometry.width':840.5}, {'geometry.width':True}):
        try:
            config.update_fence_settings(folder,bad)
            raise AssertionError('Accepted bad Fence dimension: '+str(bad))
        except ValueError:
            pass
        assert path.read_bytes()==unchanged
print('OK: v0.2.7 numeric width/height, preserved x/y, icon layout, undo, boundaries')
