#!/usr/bin/env python3
"""0.5.14: defaults for Header/Sections, scoped inheritance, zero file mutations."""
import importlib.util, json, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cf_parity',root/'tools/cinnafences-config.py')
cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
with tempfile.TemporaryDirectory() as t:
    tmp=Path(t);cli.GLOBAL_PATH=tmp/'config'/'defaults.json';cli.DESKTOP=tmp/'Desktop'
    parent=cli.DESKTOP/'3D';parent.mkdir(parents=True)
    original=parent/'keep.txt';original.write_text('leave me untouched')
    cli.create(parent,45,70)
    config_path=parent/'.cinnafence.json'
    cfg=json.loads(config_path.read_text())
    assert cfg['inheritGlobals'] and cfg['inheritAdvancedGlobals']
    cfg['inheritAdvancedGlobals']=False  # previous installations have no key at all
    del cfg['inheritAdvancedGlobals']
    cfg['view']['mode']='rolodex'
    cfg['header']['background']='#123123'
    config_path.write_text(json.dumps(cfg))
    baseline=config_path.read_bytes()
    assert cli.update_general_settings({
        'view.mode':'tabs', 'view.tabsInHeader':True,
        'view.autoFitHeight':True,'view.autoFitMaxHeight':630,
        'header.background':'#112233','header.hoverOpacity':.36,
        'header.showCollapseButton':False,'sections.background':'#334455',
        'sections.alignment':'left','sections.fontFamily':'DejaVu Sans',
        'sections.showCollapseButton':False,'sections.height':33})
    values=cli.read_global_settings()
    assert values['view.mode']=='tabs'
    assert values['sections.fontFamily']=='DejaVu Sans'
    assert values['view.tabsInHeader']
    assert config_path.read_bytes()==baseline
    assert cli.read_fence_settings(parent)['view']['mode']=='rolodex'
    cli.update_fence_settings(parent,{'inheritAdvancedGlobals':True})
    now=cli.read_fence_settings(parent)
    assert now['inheritAdvancedGlobals'] and now['view']['mode']=='rolodex'
    assert now['header']['background']=='#123123' # effective style applied in GJS, local value preserved
    cli.update_fence_settings(parent,{'inheritAdvancedGlobals':False})
    assert original.read_text()=='leave me untouched'
    # Only safe view defaults for newly CREATED Fences.
    newer=cli.DESKTOP/'Fresh';newer.mkdir()
    cli.create(newer,80,90)
    new=cli.read_fence_settings(newer)
    assert new['view']['mode']=='tabs' and new['inheritAdvancedGlobals']
    for field,value in [('view.mode','invalid'),('sections.alignment','middle'),
                        ('header.opacity',2),('view.autoFitMaxHeight',12),
                        ('geometry.width',250),('inheritAdvancedGlobals',True)]:
        data=cli.GLOBAL_PATH.read_bytes()
        try:cli.update_general_settings({field:value})
        except ValueError:pass
        else:raise AssertionError(f'Invalid General entry accepted: {field}')
        assert cli.GLOBAL_PATH.read_bytes()==data
    assert original.read_text()=='leave me untouched'
print('OK: 0.5.14 General/Header/Sections parity, opt-in inheritance, legacy view preserved, new-Fence mode and validation')
