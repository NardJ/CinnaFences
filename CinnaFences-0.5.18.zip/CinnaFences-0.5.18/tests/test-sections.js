'use strict';
// v0.5.6: offline, compositor-free tests for genuine subfolder transfers.
const fs=require('fs'), vm=require('vm'),assert=require('assert'),path=require('path');
const source=fs.readFileSync(path.join(__dirname,'../cinnafences@local/extension.js'),'utf8');
const files=new Map(), trashed=[], notices=[], scans=[];
const ROOT='/sandbox/Desktop', F1=ROOT+'/3D', F2=ROOT+'/Games';
const DIRECTORY=2, REGULAR=1, LINK=3;
function add(p,type=REGULAR,text='data'){files.set(p,{type,text,version:0});}
add(F1,DIRECTORY);add(F2,DIRECTORY);
for(const section of ['CAD','Slicers','Tools'])add(F1+'/'+section,DIRECTORY);
add(F1+'/CAD/BS.desktop');add(F1+'/CAD/X1.desktop');
add(F1+'/Slicers/BS.desktop');add(F1+'/Slicers/X2.desktop');
add(F1+'/root.desktop');
const Gio={FileType:{REGULAR,DIRECTORY,SYMBOLIC_LINK:LINK,UNKNOWN:0},FileQueryInfoFlags:{NOFOLLOW_SYMLINKS:1},FileCopyFlags:{NONE:0},File:{new_for_path(p){return {
  path:p,
  query_exists(){return files.has(p)},
  query_file_type(){return files.get(p)?.type||0},
  query_info(){const f=files.get(p);return {get_file_type:()=>f?.type||0,get_size:()=>f?.text.length||0,
    get_attribute_uint64:()=>f?.version||0,get_attribute_uint32:()=>0,get_attribute_string:()=>null}},
  move(to,flags){if(flags!==0||!files.has(p)||files.has(to.path))throw Error('unsafe move');
    files.set(to.path,files.get(p));files.delete(p);},
  copy(to,flags){if(flags!==0||!files.has(p)||files.has(to.path))throw Error('unsafe copy');
    files.set(to.path,{...files.get(p)})},
  trash(){if(!files.has(p))throw Error('missing trash');trashed.push(p);files.delete(p)}
}}}};
const Main={notify:(...args)=>notices.push(args),uiGroup:{add_actor:()=>{}}};
const context=vm.createContext({console,assert,files,trashed,notices,scans,Gio,Main,
  imports:{gi:{Gio,GLib:{build_filenamev:parts=>parts.join('/'),path_get_basename:p=>path.basename(p),
    get_user_config_dir:()=>'/sandbox/cfg',get_monotonic_time:()=>1000000},
    St:{Label:class{}},Clutter:{ModifierType:{CONTROL_MASK:4,SHIFT_MASK:1},EVENT_STOP:true},Cinnamon:{},Pango:{},Meta:{}},byteArray:{},ui:{main:Main,popupMenu:{}}},
  global:{logError:()=>{}},
});
vm.runInContext(source,context,{filename:'extension.js'});
const run=s=>vm.runInContext(s,context);
const groupPlan=run(`planSectionTransfer('${F1}','${F1}',['CAD/BS.desktop','CAD/X1.desktop'],'Tools',false)`);
assert.equal(groupPlan[0].src.path,F1+'/CAD/BS.desktop');
assert.equal(groupPlan[0].dst.path,F1+'/Tools/BS.desktop');
assert.equal(groupPlan[0].sourceKey,'CAD/BS.desktop');
assert.equal(groupPlan[0].destKey,'Tools/BS.desktop');
// Identical leaf file names in *different* sections do not conflict with each other.
assert(files.has(F1+'/CAD/BS.desktop') && files.has(F1+'/Slicers/BS.desktop'));
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['CAD/BS.desktop'],'Slicers',false)`),/already exists/);
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['CAD/X1.desktop'],'CAD',false)`),/different Fence/);
for(const key of ['../Tools','/tmp','Slicers/Deep','.private'])
  assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['CAD/X1.desktop'],${JSON.stringify(key)},false)`));
for(const name of ['CAD/../X1.desktop','CAD/deep/file.desktop','CAD/.secret','CAD\\x'])
  assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',[${JSON.stringify(name)}],'Tools',false)`));
add(F1+'/Tools/alias',LINK);
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['Tools/alias'],'CAD',false)`),/Symbolic links/);
add(F1+'/link-section',LINK);
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['CAD/X1.desktop'],'link-section',false)`),/missing or is a link/);
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['CAD/X1.desktop'],'../../outside',false)`));
// Same-file name in a destination is refused before any files are moved.
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',
   ['CAD/X1.desktop','CAD/BS.desktop'],'Slicers',false)`),/already exists/);
// Nested (recursive) transfer blocked even when the source is a directory.
assert.throws(()=>run(`planSectionTransfer('${F1}','${F1}',['CAD'],'CAD',false)`),/into itself/);
// Actual move from CAD to Tools, then Undo, and cross-Fence root copy and Undo.
const moved=run(`planSectionTransfer('${F1}','${F1}',['CAD/X1.desktop'],'Tools',false)`);
context.moved=moved;
assert.equal(run('executeFenceTransfer(moved,false).ok'),true);
assert(files.has(F1+'/Tools/X1.desktop')&&!files.has(F1+'/CAD/X1.desktop'));
assert.equal(run('undoFenceTransfer({entries:moved,copy:false}).ok'),true);
assert(files.has(F1+'/CAD/X1.desktop')&&!files.has(F1+'/Tools/X1.desktop'));
const copied=run(`planSectionTransfer('${F1}','${F2}',['CAD/X1.desktop'],'/',true)`);
context.copied=copied;
assert.equal(run('executeFenceTransfer(copied,true).ok'),true);
assert(files.has(F2+'/X1.desktop')&&files.has(F1+'/CAD/X1.desktop'));
assert.equal(run('undoFenceTransfer({entries:copied,copy:true}).ok'),true);
assert(files.has(F1+'/CAD/X1.desktop')&&!files.has(F2+'/X1.desktop'));
assert(trashed.includes(F2+'/X1.desktop'));
console.log('OK: safe subfolder->subfolder move/copy, duplicate names, traversal/symlinks, undo');

// A file named BS.desktop in CAD must not share the same icon-position key
// with another BS.desktop in Slicers. Exercise the full Fence transfer method
// with both source and destination being the SAME Fence object.
const fence=run('Object.create(Fence.prototype)');
context.fence=fence;
fence.folder=F1;fence._disposed=false;fence.scroll=0;
fence.config=run(`normalizeConfig({view:{mode:'rolodex',active:'CAD'},
  icons:{positions:{'CAD/X1.desktop':[1,1],'Slicers/BS.desktop':[0,0]}}},'${F1}')`);
fence.items=[{name:'CAD/X1.desktop',col:1,row:1}];
fence.actor={get_transformed_position:()=>[100,100]};
fence._activeSection='CAD';
fence._activateSection=key=>{fence.activated=key;fence._activeSection=key};
fence._save=()=>{fence.saves=(fence.saves||0)+1};
const manager=run('Object.create(FenceManager.prototype)');
context.testManager=manager;manager.lastTransfer=null;manager.fences=new Map([[F1,fence]]);
manager.queueScan=p=>scans.push(p);
fence.manager=manager;
assert.equal(run(`fence._transferItemToFence({destination:fence,
    sectionKey:'Slicers',names:['CAD/X1.desktop'],copy:false,x:200,y:250})`),true);
assert(files.has(F1+'/Slicers/X1.desktop')&&!files.has(F1+'/CAD/X1.desktop'));
assert.equal(fence.activated,'Slicers');
assert.equal(fence.config.icons.positions['CAD/X1.desktop'],undefined);
assert(fence.config.icons.positions['Slicers/X1.desktop']);
assert.equal(fence.config.icons.positions['Slicers/BS.desktop'][0],0);
assert.equal(manager.lastTransfer.entries[0].sourceKey,'CAD/X1.desktop');
assert.equal(manager.lastTransfer.entries[0].destKey,'Slicers/X1.desktop');
assert.equal(run('testManager.undoLastTransfer()'),true);
assert(files.has(F1+'/CAD/X1.desktop')&&!files.has(F1+'/Slicers/X1.desktop'));
assert.deepEqual(Array.from(fence.config.icons.positions['CAD/X1.desktop']),[1,1]);
assert.equal(fence.config.icons.positions['Slicers/X1.desktop'],undefined);
console.log('OK: same-Fence section transfer, independent position keys, refresh and Undo');

// Drop detection is based on visible geometry under a modal pointer grab.
// Navigation in the header must not be mistaken for a Fence move.
const section=run('Object.create(Fence.prototype)');
context.section=section;
const box=(x,y,width,height,visible=true)=>({width,height,visible,
  get_transformed_position:()=>[x,y]});
section.actor=box(100,100,400,250);
section.content=box(101,100,398,249);
section._disposed=false;
section._pointerInside=(x,y)=>x>=100&&x<500&&y>=100&&y<350;
section.config={collapsed:false,view:{mode:'rolodex'},icons:{gridHeight:88}};
section._activeSection='CAD';section.scroll=0;section._gridOriginY=66;
section._contentLength=180;
section.items=[{row:0}];
section._navButtons=[
  {key:'Main',actor:box(101,100,398,30),y:0,height:30,inHeader:false},
  {key:'CAD',actor:box(101,132,398,30),y:32,height:30,inHeader:false},
  {key:'Slicers',actor:box(101,280,398,30),y:180,height:30,inHeader:false},
];
assert.equal(run('section._sectionDropAt(130,118)'), 'Main');
assert.equal(run('section._sectionDropAt(130,146)'), 'CAD');
assert.equal(run('section._sectionDropAt(130,200)'), 'CAD');
assert.equal(run('section._sectionDropAt(130,292)'), 'Slicers');
section.config.view.mode='tabs';section._navButtons=[
  {key:'Main',actor:box(280,100,75,30),inHeader:true},
  {key:'CAD',actor:box(355,100,75,30),inHeader:true},
];
section.content=box(110,140,380,200);
assert.equal(run('section._sectionDropAt(380,114)'), 'CAD');
assert.equal(run('section._sectionDropAt(200,190)'), 'CAD');
section._activeSection='Main';
assert.equal(run('section._sectionDropAt(200,190)'), 'Main');
console.log('OK: Rolodex closed section bars, open contents, titlebar tabs and body drop');

// Never deliver a drop to a window behind the pointer or through a front Fence.
section.config.view.mode='rolodex';section._activeSection='CAD';
section._navButtons=[{key:'CAD',actor:box(101,132,398,30),y:32,height:30,inHeader:false}];
section.content=box(101,100,398,249);
section._windowInputBoxes=()=>[];
manager.fences=new Map([['one',section]]);
manager._windowInputBoxes=()=>[];
assert.equal(run('testManager.dropTargetAt(130,146,null).sectionKey'),'CAD');
manager._windowInputBoxes=()=>[{x:120,y:130,width:90,height:90}];
assert.equal(run('testManager.dropTargetAt(130,146,null)'),null);
manager._windowInputBoxes=()=>[];
assert.equal(run('testManager.dropTargetAt(130,146,section)'),null); // same active section
section._activeSection='Slicers';
assert.equal(run('testManager.dropTargetAt(130,146,section).sectionKey'),'CAD');
console.log('OK: drop occlusion, no self-section transfer, actual destination hit testing');

// Tabs/Rolodex use the SAME modal-grab item selection as classic Icons.
section._drag=null;section.items=[];section._selectionAnchor=null;
section._setPointerMode=(mode,e,item)=>{section._drag={mode,item,moved:false}};
const item={name:'CAD/X1.desktop',selected:false,col:0,row:0,actor:{set_style(){}}};
section.items=[item];section._paintItem=()=>{};
context.item=item;
context.event={get_button:()=>1,get_click_count:()=>1,get_state:()=>0};
run('section._itemDown(item,event)');
assert.equal(section._drag.mode,'item');
assert.equal(section._drag.names[0],'CAD/X1.desktop');
console.log('OK: section icon initiates a real drag with its relative file path');
