#!/usr/bin/env python3
"""Isolated tests for new Cinnamon Desktop Editor integration (no GTK or Nemo)."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cinnafence_launcher', ROOT/'nemo-actions/create-launcher.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

def expect_error(typ, func):
    try:
        func()
    except typ:
        return
    raise AssertionError(f'Expected {typ.__name__} from {func}')

with tempfile.TemporaryDirectory(prefix='cinnafences-launcher-tests-') as t:
    home = Path(t)
    desktop = home/'Desktop'; desktop.mkdir()
    fence = desktop/'3D'; fence.mkdir()
    (fence/'.cinnafence.json').write_text(json.dumps({'enabled': True}))
    cad = fence/'CAD'; cad.mkdir()
    slicers = fence/'Slicers'; slicers.mkdir()
    links = fence/'Alias'; links.symlink_to(cad, target_is_directory=True)
    off = desktop/'Disabled'; off.mkdir()
    (off/'.cinnafence.json').write_text(json.dumps({'enabled': False}))

    def editor(filename='My Cool App.desktop', body=None, code=0):
        def run(cmd,check):
            assert check is False
            assert cmd[0] == 'mock-cinnamon-desktop-editor'
            assert cmd[1:4] == ['-m','nemo-launcher','-d']
            stage = Path(cmd[4])
            assert stage.name == 'output'
            assert stage.parent.parent in (fence,cad,slicers)
            if filename:
                p = stage/filename
                p.write_text(body or '[Desktop Entry]\nType=Application\nName=My Cool App\nExec=echo hello\nIcon=utilities-terminal\n', encoding='utf-8')
                p.chmod(0o755)
            return SimpleNamespace(returncode=code)
        return run

    # Nemo URI selection now drives the standard editor's initial values.
    appimg = home/'Repetier-Host-x86_64-2.2.2.2.AppImage'
    appimg.write_bytes(b'FAKE-APPIMAGE-NEVER-RUN')
    appimg.chmod(0o755)
    icon = home/'repetier_48x48.png'; icon.write_bytes(b'PNG')
    assert a.selected_launcher_source([appimg.as_uri()]) == appimg
    assert a.selected_launcher_source([], fallback="") is None
    assert a.selected_launcher_source([], fallback=str(appimg) + "\n") == appimg
    expect_error(ValueError,lambda:a.selected_launcher_source([appimg.as_uri(),appimg.as_uri()]))
    defaults=a.launcher_defaults(appimg)
    assert defaults['Name']=='Repetier Host', defaults
    assert appimg.name in defaults['Exec'] and defaults['Exec'].startswith('"')
    assert defaults['Icon']==str(icon)
    appimg.chmod(0o644)
    expect_error(ValueError,lambda:a.selected_launcher_source([appimg.as_uri()]))
    appimg.chmod(0o755)

    commands=[]
    def check_prefill(cmd,check):
        assert cmd[0:4]==['mock-cinnamon-desktop-editor','-m','nemo-launcher','-d']
        assert cmd[5]=='-o', cmd
        output=Path(cmd[4]); seed=Path(cmd[6])
        assert output.name=='output' and seed.parent==output.parent and output.parent.parent==slicers
        assert output != seed.parent
        info=seed.read_text(encoding='utf-8')
        assert 'Name=Repetier Host' in info and appimg.name in info
        assert f'Icon={icon}' in info
        commands.append(cmd)
        (output/'Repetier Host.desktop').write_text(
            '[Desktop Entry]\nType=Application\nName=Repetier Host\nExec=' + defaults['Exec'] + '\nIcon=' + str(icon) + '\n', encoding='utf-8')
        (output/'Repetier Host.desktop').chmod(0o755)
        return SimpleNamespace(returncode=0)
    result=a.create_launcher(desktop,fence,'Slicers',editor='mock-cinnamon-desktop-editor',runner=check_prefill,source=appimg)
    assert result==slicers/'Repetier Host.desktop' and result.is_file()
    assert len(commands)==1
    assert not list(slicers.glob('.cinnafences-launcher-*'))
    assert appimg.read_bytes()==b'FAKE-APPIMAGE-NEVER-RUN'

    # Saving a prefilled editor draft should never install the draft on Cancel.
    def cancel_prefill(cmd,check):
        assert '-o' in cmd and Path(cmd[-1]).exists()
        return SimpleNamespace(returncode=0)
    assert a.create_launcher(desktop,fence,'Main',editor='mock-cinnamon-desktop-editor',runner=cancel_prefill,source=appimg) is None
    assert not (fence/'prefill.desktop').exists()

    # Existing .desktop selections copy their metadata into editor prefill.
    source_launcher=home/'OpenSCAD.desktop'
    source_launcher.write_text('[Desktop Entry]\nType=Application\nName=OpenSCAD\nExec=openscad %F\nIcon=openscad\nTerminal=false\n')
    assert a.launcher_defaults(source_launcher)['Exec']=='openscad %F'
    assert a.launcher_defaults(source_launcher)['Icon']=='openscad'

    created = a.create_launcher(desktop,fence,'CAD',editor='mock-cinnamon-desktop-editor',runner=editor())
    assert created == cad/'My Cool App.desktop'
    assert created.is_file() and not created.is_symlink()
    assert 'Exec=echo hello' in created.read_text()
    assert created.stat().st_mode & 0o111
    assert list(cad.glob('.cinnafences-launcher-*')) == []

    # A repeated name may NEVER overwrite the first launcher, not even when editing succeeded.
    before = created.read_bytes()
    expect_error(FileExistsError,lambda:a.create_launcher(desktop,fence,'CAD',editor='mock-cinnamon-desktop-editor',runner=editor()))
    assert created.read_bytes() == before
    assert list(cad.glob('.cinnafences-launcher-*')) == []

    # No launcher on cancellation, and no stale temporary folders.
    assert a.create_launcher(desktop,fence,'Main',editor='mock-cinnamon-desktop-editor',runner=editor(filename=None)) is None
    assert list(fence.glob('*.desktop')) == []
    assert list(fence.glob('.cinnafences-launcher-*')) == []

    # Staged files are not trusted blindly: malformed or symlink launches are rejected.
    expect_error(ValueError,lambda:a.create_launcher(desktop,fence,'Main',editor='mock-cinnamon-desktop-editor',runner=editor(body='hello')))
    assert list(fence.glob('*.desktop')) == []

    # Enabled Fence and direct real sections only; no .desktop generated on failure.
    expect_error(ValueError,lambda:a.create_launcher(desktop,off,'Main',editor='mock-cinnamon-desktop-editor',runner=editor()))
    expect_error(ValueError,lambda:a.create_launcher(desktop,fence,'../CAD',editor='mock-cinnamon-desktop-editor',runner=editor()))
    expect_error(ValueError,lambda:a.create_launcher(desktop,fence,'Alias',editor='mock-cinnamon-desktop-editor',runner=editor()))

    def disappearing(cmd,check):
        (fence/'.cinnafence.json').write_text(json.dumps({'enabled': False}))
        return editor('Gone.desktop')(cmd,check)
    expect_error(ValueError,lambda:a.create_launcher(desktop,fence,'Slicers',editor='mock-cinnamon-desktop-editor',runner=disappearing))
    assert not (slicers/'Gone.desktop').exists()
    assert not list(slicers.glob('.cinnafences-launcher-*'))
    (fence/'.cinnafence.json').write_text(json.dumps({'enabled': True}))

    # An editor failure does not publish any partial file.
    expect_error(RuntimeError,lambda:a.create_launcher(desktop,fence,'Main',editor='mock-cinnamon-desktop-editor',runner=editor('Broken.desktop',code=1)))
    assert not (fence/'Broken.desktop').exists()

    # Unicode and shell-special names are literal filenames; no shell is involved.
    tricky = 'App € with spaces & $money.desktop'
    p=a.create_launcher(desktop,fence,'Slicers',editor='mock-cinnamon-desktop-editor',runner=editor(tricky))
    assert p.name == tricky and p.is_file()

print('OK: standard Cinnamon desktop editor, atomic no-overwrite, cancellation, safe destinations, rollback')
