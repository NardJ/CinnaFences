'use strict';
// v0.5.7: real extension logic for section-local icon grids and drops.
const fs=require('fs'), vm=require('vm'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'../cinnafences@local/extension.js'),'utf8');
const notices=[], scanned=[];
const context=vm.createContext({console,notices,scanned,
 imports:{gi:{Gio:{},GLib:{build_filenamev:a=>a.join('/'),path_get_basename:p=>path.basename(p),
    get_user_config_dir:()=>'/tmp/test',get_monotonic_time:()=>1000000},
    St:{},Clutter:{},Cinnamon:{},Pango:{},Meta:{}},byteArray:{},ui:{main:{notify:(...a)=>notices.push(a)},popupMenu:{}}},
 global:{logError:()=>{}}});
vm.runInContext(src,context,{filename:'extension.js'});
const run=s=>vm.runInContext(s,context);
const cfg=run(`normalizeConfig({geometry:{width:350,height:300},
 view:{mode:'rolodex',active:'/'},
 icons:{positions:{'SweetHome.desktop':[3,2],'CAD/FreeCAD.desktop':[2,2],
 'CAD/Blender.desktop':[0,0],'Slicers/X1.desktop':[3,4]}}},'/home/me/Desktop/3D')`);
assert.equal(Object.keys(cfg.icons.sectionLayoutColumns).length,0);
context.cfg=cfg;
const box=(x,y,w,h,visible=true)=>({width:w,height:h,visible,
 get_transformed_position:()=>[x,y]});
const item=(name,selected=false)=>({name,col:0,row:0,selected,actor:{opacity:255}});
const f=run('Object.create(Fence.prototype)'); context.f=f;
f.folder='/sandbox/3D';f._disposed=false;f._drag=null;f.scroll=0;f.config=cfg;
f.actor=box(100,70,350,300);f.actor.set_position=()=>{};
f.content=box(100,102,350,268);
f._gridOriginY=48;
f._contentLength=160;
f._maxScroll=0;
f._activeSection='/';f.config.view.active='/';
f._pointerInside=(x,y)=>x>=100&&x<450&&y>=70&&y<370;
f._navButtons=[{key:'/',inHeader:false,actor:box(100,102,350,30),y:0,height:30}];
f._placeItems=()=>{};f._save=()=>{f.saves=(f.saves||0)+1};
f._endPointer=()=>{f._drag=null};
f.manager={dropTargetAt:()=>null,canArrangeAt:()=>true};
const setItems=(nameArray)=>{f.items=nameArray.map(x=>item(x));f._names=nameArray.slice();f.cells=new Map();};
setItems(['SweetHome.desktop']);
run('f._layoutItems()');
assert.deepEqual([f.items[0].col,f.items[0].row],[0,0]);
assert.deepEqual(Array.from(f.config.icons.positions['SweetHome.desktop']),[3,2]);
console.log('OK: existing sparse Main icon is displayed at left-top without deleting old positions');
// Below header at y=150 is local row 0; at y=250 is local row 1.
assert.deepEqual(Array.from(Object.values(run('f._localSectionCellAt(110,155)'))),[0,0,3]);
assert.equal(run('f._localSectionCellAt(110,118)'),null); // section bar
assert.equal(run('f._localSectionCellAt(110,140)'),null); // before icon grid
const movedItem=f.items[0];context.movedItem=movedItem;
f._drag={mode:'item',moved:true,item:movedItem,names:['SweetHome.desktop'],copy:false};
run('f._finishPointerAt(210,254)');
assert.equal(f.config.icons.sectionLayoutColumns['/'],3);
assert.deepEqual(Array.from(f.config.icons.positions['SweetHome.desktop']),[1,1]);
assert.equal(f.saves,1);
assert.equal(f._drag,null);
console.log('OK: same-section release uses actual Rolodex grid coordinates and saves position');
// Reopen same section: manual gap should be preserved, not compacted.
setItems(['SweetHome.desktop']);run('f._layoutItems()');
assert.deepEqual([f.items[0].col,f.items[0].row],[1,1]);
// Unconfigured CAD is compacted independently, despite old CAD positions.
f._activeSection='CAD';f.config.view.active='CAD';
f._navButtons=[{key:'CAD',inHeader:false,actor:box(100,102,350,30),y:0,height:30}];
setItems(['CAD/Blender.desktop','CAD/FreeCAD.desktop']);run('f._layoutItems()');
assert.deepEqual(f.items.map(i=>[i.col,i.row]),[[0,0],[1,0]]);
// Put one item onto the other's cell: swap without touching Main or Slicers.
const first=f.items[0];context.first=first;
run('f._finishItemMoveAt(200,160,first)');
assert.deepEqual(Array.from(f.config.icons.positions['CAD/Blender.desktop']),[1,0]);
assert.deepEqual(Array.from(f.config.icons.positions['CAD/FreeCAD.desktop']),[0,0]);
assert.deepEqual(Array.from(f.config.icons.positions['SweetHome.desktop']),[1,1]);
assert.deepEqual(Array.from(f.config.icons.positions['Slicers/X1.desktop']),[3,4]);
assert.equal(f.config.icons.sectionLayoutColumns.CAD,3);
console.log('OK: CAD swaps independently; Main and unopened Slicers positions remain unchanged');
// Resize to two columns and back: manual cell remains stable when restored.
f.config.geometry.width=260;run('f._layoutItems()');
f.config.geometry.width=350;run('f._layoutItems()');
assert.deepEqual(f.items.map(i=>[i.col,i.row]),[[1,0],[0,0]]);
// Reopen Slicers: legacy sparse position gets compacted, CAD stays intact.
f._activeSection='Slicers';f.config.view.active='Slicers';
f._navButtons=[{key:'Slicers',inHeader:false,actor:box(100,102,350,30),y:0,height:30}];
setItems(['Slicers/X1.desktop']);run('f._layoutItems()');
assert.deepEqual([f.items[0].col,f.items[0].row],[0,0]);
console.log('OK: independent section columns, reopening and resizing');
// Tabs mode uses its own navigation height and scroll offset, not hardcoded HEADER_H.
f.config.view.mode='tabs';f._activeSection='CAD';f._navButtons=[{key:'CAD',inHeader:false,actor:box(100,102,100,30),y:0,height:30}];
f._gridOriginY=50;f.scroll=20;
assert.deepEqual(Array.from(Object.values(run('f._localSectionCellAt(115,230)'))),[0,1,3]); // current width 350 => 3 cols
assert.equal(run('f._localSectionCellAt(115,115)'),null);
// Cannot rearrange when another window or Fence covers the drop.
const m=run('Object.create(FenceManager.prototype)'); context.m=m;
const other={_disposed:false,config:{collapsed:false},_pointerInside:()=>true};
m.fences=new Map([['mine',f],['top',other]]);
m._windowInputBoxes=()=>[];
assert.equal(run('m.canArrangeAt(f,110,230)'),false);
m.fences.delete('top');
assert.equal(run('m.canArrangeAt(f,110,230)'),true);
m._windowInputBoxes=()=>[{x:105,y:225,width:60,height:60}];
assert.equal(run('m.canArrangeAt(f,110,230)'),false);
m._windowInputBoxes=()=>{throw Error('Window manager unavailable')};
assert.equal(run('m.canArrangeAt(f,110,230)'),false);
console.log('OK: tabs/scroll offsets, no rearrangement through windows or overlapping Fences');
// Ctrl/group positioning changes only selected icons in one active section.
f.config.view.mode='rolodex';f._activeSection='CAD';f._gridOriginY=48;f.scroll=0;
f._navButtons=[{key:'CAD',inHeader:false,actor:box(100,102,350,30),y:0,height:30}];
f.config.geometry.width=350;
setItems(['CAD/Blender.desktop','CAD/FreeCAD.desktop','CAD/OpenSCAD.desktop']);
run('f._layoutItems()');
f.items[0].selected=true;f.items[1].selected=true;
const beforeSlicer=JSON.stringify(f.config.icons.positions['Slicers/X1.desktop']);
context.groupItem=f.items[0];
run('f._finishItemMoveAt(200,255,groupItem)');
assert.deepEqual(Array.from(f.config.icons.positions['CAD/FreeCAD.desktop']),[1,1]);
assert.deepEqual(Array.from(f.config.icons.positions['CAD/Blender.desktop']),[2,1]);
assert.equal(JSON.stringify(f.config.icons.positions['Slicers/X1.desktop']),beforeSlicer);
console.log('OK: multiple icon rearrangement stays within its section');
// Bad external configuration values must not leak into the saved columns map.
const invalid=run(`normalizeConfig({icons:{sectionLayoutColumns:{CAD:3,'../../escape':5,Tools:0,'/':4,Extra:99}}},'/tmp/A')`);
assert.deepEqual(Object.entries(invalid.icons.sectionLayoutColumns).map(x=>x.join(':')).sort(),['/:4','CAD:3']);
console.log('OK: section grid column validation');
