'use strict';
// Actual filesystem-backed tests of the Desktop / Unassigned virtual Fence.
// No Cinnamon install, background service or user's Desktop is touched.
const assert=require('assert');
const fs=require('fs');
const os=require('os');
const path=require('path');
const vm=require('vm');
const source=fs.readFileSync(path.join(__dirname,'../cinnafences@local/extension.js'),'utf8');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'cf-unassigned-'));
const home=path.join(root,'home');
const desktop=path.join(home,'Desktop');
const globalDir=path.join(home,'.config','cinnafences');
fs.mkdirSync(desktop,{recursive:true});fs.mkdirSync(globalDir,{recursive:true});
const makeDir=name=>fs.mkdirSync(path.join(desktop,name));
try {
  makeDir('3D');makeDir('Removed');makeDir('Personal');
  fs.writeFileSync(path.join(desktop,'3D','.cinnafence.json'),'{"enabled":true}');
  fs.writeFileSync(path.join(desktop,'Removed','.cinnafence.json'),'{"enabled":false}');
  fs.writeFileSync(path.join(desktop,'Notes.txt'),'hello');
  fs.writeFileSync(path.join(desktop,'App.desktop'),'[Desktop Entry]\nType=Application\n');
  fs.symlinkSync(path.join(desktop,'3D'),path.join(desktop,'Link to 3D'));
  // Existing config files, whether disabled or hidden, exclude the folder.
  const FileType={DIRECTORY:2,REGULAR:1,SYMBOLIC_LINK:3,UNKNOWN:0};
  const typeFor=p=>{const st=fs.lstatSync(p);return st.isSymbolicLink()?FileType.SYMBOLIC_LINK:st.isDirectory()?FileType.DIRECTORY:FileType.REGULAR;};
  const gioFile=p=>({
    query_file_type:()=>{try{return typeFor(p)}catch(_){return FileType.UNKNOWN}},query_exists:()=>fs.existsSync(p),
    enumerate_children:()=>{const names=fs.readdirSync(p,{withFileTypes:true});let i=0;return {
      next_file:()=>i>=names.length?null:(()=>{const n=names[i++].name;return {get_name:()=>n,get_file_type:()=>typeFor(path.join(p,n))};})(),
      close:()=>{}};},
    load_contents:()=>[true,fs.readFileSync(p)],
    query_info:()=>({get_size:()=>fs.statSync(p).size,get_symlink_target:()=>fs.readlinkSync(p)}),
    move:dest=>fs.renameSync(p,dest.get_path()),
    copy:dest=>fs.copyFileSync(p,dest.get_path(),fs.constants.COPYFILE_EXCL),
    get_path:()=>p
  });
  const Gio={FileType,FileQueryInfoFlags:{NOFOLLOW_SYMLINKS:1},FileCopyFlags:{NONE:0,NOFOLLOW_SYMLINKS:4},File:{new_for_path:gioFile}};
  const GLib={get_home_dir:()=>home,get_user_config_dir:()=>path.join(home,'.config'),
    build_filenamev:x=>path.join(...x),path_get_basename:path.basename,
    uuid_string_random:()=>String(Date.now())+Math.random().toString(16).slice(2),
    file_set_contents:(p,bytes)=>fs.writeFileSync(p,bytes),
    FileTest:{EXISTS:1,IS_DIR:2},file_test:(p,flag)=>{
      if(flag===1)return fs.existsSync(p);
      try{return fs.statSync(p).isDirectory();}catch(_){return false;}
    }};
  const ctx=vm.createContext({imports:{gi:{St:{},Clutter:{},Cinnamon:{},Gio,GLib,Pango:{},Meta:{}},
    byteArray:{toString:Buffer.from},ui:{main:{},popupMenu:{}}},global:{logError:()=>{}}});
  vm.runInContext(source,ctx,{filename:'extension.js'});
  const run=expr=>vm.runInContext(expr,ctx);
  ctx.desktop=desktop;
  assert.equal(run('configPathFor(desktop)'),path.join(globalDir,'unassigned.json'));
  assert.equal(run('configPathFor(desktop+"/3D")'),path.join(desktop,'3D','.cinnafence.json'));
  ctx.fake=run('Object.create(Fence.prototype)');ctx.fake.folder=desktop;
  ctx.fake.isUnassigned=true;ctx.fake.config={view:{mode:'icons'}};
  const items=run('fake._readItems()');
  const names=Array.from(items,i=>i.name).sort();
  assert.deepEqual(names,['App.desktop','Link to 3D','Notes.txt','Personal']);
  // The Desktop monitor may not emit an event when only a child folder's
  // .cinnafence.json changes. Scanning that child must still invalidate Other.
  ctx.membershipManager=run('Object.create(FenceManager.prototype)');
  ctx.managedFolders=['3D','Removed','Personal'].map(x=>path.join(desktop,x));
  assert.equal(run('membershipManager._unassignedMembershipChanged(managedFolders)'),true);
  assert.equal(run('membershipManager._unassignedMembershipChanged(managedFolders)'),false);
  fs.writeFileSync(path.join(desktop,'Personal','.cinnafence.json'),'{}');
  assert.equal(run('membershipManager._unassignedMembershipChanged(managedFolders)'),true);
  assert.equal(run('membershipManager._unassignedMembershipChanged(managedFolders)'),false);
  assert(!Array.from(run('fake._readItems()'),x=>x.name).includes('Personal'),
    'Newly activated Fence folder must disappear from Other');
  fs.unlinkSync(path.join(desktop,'Personal','.cinnafence.json'));
  assert.equal(run('membershipManager._unassignedMembershipChanged(managedFolders)'),true);
  assert(Array.from(run('fake._readItems()'),x=>x.name).includes('Personal'),
    'Removed Fence config must reveal ordinary folder again');
  assert.equal(run('membershipManager._unassignedMembershipChanged(managedFolders)'),false);
  assert(!fs.existsSync(path.join(desktop,'.cinnafence.json')),'Never convert the Desktop into an ordinary Fence');
  const config=run('readUnassignedConfig({appearance:{background:"#aabbcc"}})');
  assert.equal(config.title,'Desktop / Unassigned');
  assert.equal(config.view.mode,'icons');
  assert.equal(config.appearance.background,'#aabbcc');
  assert.equal(config.geometry.y,410);
  assert(!fs.existsSync(path.join(globalDir,'unassigned.json')),'Reading must not create a file');
  // First drag/save must work even though the virtual config did not yet exist.
  ctx.virtualConfig=config;
  config.geometry.x=233;
  run('writeConfig(desktop,virtualConfig)');
  assert.equal(JSON.parse(fs.readFileSync(path.join(globalDir,'unassigned.json'),'utf8')).geometry.x,233);
  assert(!fs.existsSync(path.join(desktop,'.cinnafence.json')));
  assert.equal(run('readUnassignedConfig({}).geometry.x'),233);
  // Exactly the real source selection and target used when dropping an icon
  // from the virtual Desktop Fence onto the 3D Fence's root.
  ctx.target=path.join(desktop,'3D');
  const transfer=run('planSectionTransfer(desktop,target,["Notes.txt"],"/",false)');
  assert.equal(transfer.length,1);
  assert.equal(transfer[0].sourceKey,'Notes.txt');
  assert.equal(transfer[0].destKey,'Notes.txt');
  ctx.transfer=transfer;
  assert.equal(run('executeFenceTransfer(transfer,false).ok'),true);
  assert(!fs.existsSync(path.join(desktop,'Notes.txt')));
  assert.equal(fs.readFileSync(path.join(desktop,'3D','Notes.txt'),'utf8'),'hello');
  assert.equal(run('undoFenceTransfer({entries:transfer,copy:false}).ok'),true);
  assert(fs.existsSync(path.join(desktop,'Notes.txt')));
  assert(!fs.existsSync(path.join(desktop,'3D','Notes.txt')));
  // A loose Desktop shortcut should MOVE AS A LINK, with no target traversal.
  const linkBefore=fs.readlinkSync(path.join(desktop,'Link to 3D'));
  const symlinkMove=run('planSectionTransfer(desktop,target,["Link to 3D"],"/",false)');
  assert.equal(symlinkMove[0].isSymlink,true);
  ctx.symlinkMove=symlinkMove;
  assert.equal(run('executeFenceTransfer(symlinkMove,false).ok'),true);
  assert.equal(fs.readlinkSync(path.join(desktop,'3D','Link to 3D')),linkBefore);
  assert(!fs.existsSync(path.join(desktop,'Link to 3D')));
  assert.equal(run('undoFenceTransfer({entries:symlinkMove,copy:false}).ok'),true);
  assert.equal(fs.readlinkSync(path.join(desktop,'Link to 3D')),linkBefore);
  assert.throws(()=>run('planSectionTransfer(desktop,target,["Link to 3D"],"/",true)'),/cannot be copied/);
  fs.symlinkSync('Personal',path.join(desktop,'relative-link'));
  assert.throws(()=>run('planSectionTransfer(desktop,target,["relative-link"],"/",false)'),/Relative symbolic link/);
  assert.equal(fs.readlinkSync(path.join(desktop,'relative-link')),'Personal');
  // A broken Desktop symlink is also an existing item. Undo must work even
  // though query_exists() follows the link and reports false.
  fs.symlinkSync('/this-target-does-not-exist/at-all',path.join(desktop,'broken'));
  ctx.brokenPlan=run('planSectionTransfer(desktop,target,["broken"],"/",false)');
  assert.equal(run('executeFenceTransfer(brokenPlan,false).ok'),true);
  assert.equal(run('undoFenceTransfer({entries:brokenPlan,copy:false}).ok'),true);
  assert.equal(fs.readlinkSync(path.join(desktop,'broken')),'/this-target-does-not-exist/at-all');
  // An ordinary Icons Fence must accept a drop over the header and background.
  const games=run('Object.create(Fence.prototype)');
  games._disposed=false;games.config={collapsed:false,view:{mode:'icons'}};
  games.actor={visible:true};games._pointerInside=(x,y)=>x>=600&&x<950&&y>=100&&y<370;
  games.content={visible:true,width:330,height:210,get_transformed_position:()=>[610,132]};
  assert.equal(games._sectionDropAt(650,105),'/','header must be a valid Games drop');
  const manager=run('Object.create(FenceManager.prototype)');
  manager.fences=new Map([[ctx.target,games]]);
  manager._windowInputBoxes=()=>[];
  ctx.testManager=manager;ctx.games=games;
  assert.equal(run('testManager.dropTargetAt(650,105,null).destination===games'),true);
  assert.throws(()=>run('planSectionTransfer(desktop,target,["3D"],"/",false)'),/Cannot move a folder into itself|Choose a different Fence/);
  console.log('OK: virtual Desktop files, managed/disabled Fence folders excluded, symlink preserved, no Desktop config, transfer and Undo');
} finally { fs.rmSync(root,{force:true,recursive:true}); }
