#!/usr/bin/env python3
"""Validate Nemo on-demand move independently from GTK or Nemo installation."""
import importlib.util
import json
from pathlib import Path
import os
import tempfile

root=Path(__file__).resolve().parents[1]
path=root/'nemo-actions/send-to-fence.py'
spec=importlib.util.spec_from_file_location('cinnafence_send',path)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory(prefix='cinnafence-move-test-') as tmp:
    home=Path(tmp); desktop=home/'Desktop'; desktop.mkdir()
    dest=desktop/'My Games'; dest.mkdir()
    (dest/'.cinnafence.json').write_text(json.dumps({'version':1,'enabled':True}))
    disabled=desktop/'Not Enabled'; disabled.mkdir()
    (disabled/'.cinnafence.json').write_text(json.dumps({'version':1,'enabled':False}))
    (desktop/'No Config').mkdir()
    assert mod.active_fences(desktop)==[('My Games',dest)]
    source=home/'Other Places'/'Long filename & symbols.txt'
    source.parent.mkdir()
    source.write_text('USER-DATA')
    target=mod.validate_move(source,dest,desktop)
    assert target==dest/source.name
    assert source.exists()
    mod.safe_move(source,target,mover=lambda src,dst: os.rename(src,dst))
    assert target.read_text()=='USER-DATA' and not source.exists()
    # Never overwrite: validate collision, and do not invoke mover.
    another=source; another.write_text('DIFFERENT-DATA')
    try:mod.validate_move(another,dest,desktop)
    except ValueError as e:assert 'already exists' in str(e)
    else:raise AssertionError('collision accepted')
    assert another.read_text()=='DIFFERENT-DATA' and target.read_text()=='USER-DATA'
    # No symlink, no Fence root, no directory into itself, no disabled destination.
    symlink=source.parent/'alias';symlink.symlink_to(another)
    for item,folder in [(symlink,dest),(dest,dest),(another,disabled)]:
        try:mod.validate_move(item,folder,desktop)
        except ValueError:pass
        else:raise AssertionError(f'unsafe move accepted: {item}')
    nested=dest/'subdir';nested.mkdir()
    (nested/'.cinnafence.json').write_text('{}')
    try:mod.validate_move(dest,nested,desktop)
    except ValueError:pass
    else:raise AssertionError('recursive target accepted')
    try:mod.validate_move(desktop,dest,desktop)
    except ValueError:pass
    else:raise AssertionError('Desktop root move accepted')
    # Real folder move should preserve all children (no deletion, no extra copy).
    folder=home/'Other Places'/'Folder with spaces';folder.mkdir()
    (folder/'inside.txt').write_text('KEEP')
    target2=mod.validate_move(folder,dest,desktop)
    mod.safe_move(folder,target2,mover=lambda src,dst:os.rename(src,dst))
    assert (target2/'inside.txt').read_text()=='KEEP'
    assert not folder.exists()
    # Repeated no-write checks.
    for name,folder in mod.active_fences(desktop):
        assert folder==dest

print('OK: Nemo selected-file move, conflict protection, symlink/recursive protection, spaces, disabled fences')
