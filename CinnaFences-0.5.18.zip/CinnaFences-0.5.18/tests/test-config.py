"""CLI integration smoke test in a temporary HOME — never touches real Desktop."""
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

script = Path(__file__).resolve().parents[1] / 'tools' / 'cinnafences-config.py'

with TemporaryDirectory() as temp:
    home = Path(temp)
    desktop = home / 'Desktop'
    desktop.mkdir()
    folder = desktop / 'Internet'
    folder.mkdir()
    (folder / 'Firefox.desktop').write_text('[Desktop Entry]\nName=Firefox\n', encoding='utf-8')
    env = {**os.environ, 'HOME': str(home)}

    def run(*args):
        return subprocess.run([sys.executable, str(script), *map(str,args)],
            env=env, text=True, capture_output=True, check=True)

    run('init',folder,'--dry-run')
    assert not (folder/'.cinnafence.json').exists()
    run('init',folder)
    conf=folder/'.cinnafence.json'
    assert conf.exists()
    config=json.loads(conf.read_text())
    assert config['enabled'] and config['icons']['layoutColumns']==3
    assert (folder/'Firefox.desktop').exists()
    run('init',folder)
    assert json.loads(conf.read_text())==config
    run('disable',folder)
    assert json.loads(conf.read_text())['enabled'] is False
    run('enable',folder)
    assert json.loads(conf.read_text())['enabled'] is True
    run('hover', folder, 'off')
    config = json.loads(conf.read_text())
    assert config['appearance']['hoverEnabled'] is False
    assert config['enabled'] is True and (folder/'Firefox.desktop').exists()
    run('hover', folder, 'on')
    assert json.loads(conf.read_text())['appearance']['hoverEnabled'] is True
    second=desktop/'Graphics'
    second.mkdir()
    run('init-all','--dry-run')
    assert not (second/'.cinnafence.json').exists()
    run('init-all')
    assert (second/'.cinnafence.json').exists()
    assert (folder/'Firefox.desktop').exists()
    status=run('list').stdout
    assert 'Internet' in status and 'Graphics' in status
    print('OK: CLI dry-run, init, no-overwrite, enable/disable, hover on/off, init-all, list, untouched files')
