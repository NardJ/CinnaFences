#!/usr/bin/env python3
"""Nemo desktop mode recovery tests without subprocess-per-operation overhead.

Exercise the same production functions used by both the CLI and GTK settings UI,
substituting only an in-memory gsettings backend. No Node/GTK/display needed.
"""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import tempfile
from unittest import mock

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cinnafences_cli_desktop_test',
                                         root / 'tools/cinnafences-config.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

with tempfile.TemporaryDirectory(prefix='cinnafences-desktop-mode-') as tmp:
    mod.STATE_PATH = Path(tmp) / '.config/cinnafences/desktop-mode.json'
    layout=['true::false']

    def set_layout(value):
        layout[0] = value

    def run(cmd):
        with redirect_stdout(io.StringIO()) as output:
            mod.desktop_mode(cmd)
        return output.getvalue()

    with mock.patch.object(mod, 'nemo_layout', side_effect=lambda: layout[0]), \
         mock.patch.object(mod, 'set_nemo_layout', side_effect=set_layout):
        assert 'UIT' in run('status')
        assert layout[0]=='true::false'
        run('on')
        assert layout[0]=='false::false'
        assert json.loads(mod.STATE_PATH.read_text())['originalLayout']=='true::false'
        assert 'AAN' in run('status')
        run('on')
        assert json.loads(mod.STATE_PATH.read_text())['originalLayout']=='true::false'
        run('off')
        assert layout[0]=='true::false' and not mod.STATE_PATH.exists()
        run('off')

        layout[0]='true::true'
        run('on')
        assert layout[0]=='false::false'
        run('restore')
        assert layout[0]=='true::true' and not mod.STATE_PATH.exists()

        run('on')
        layout[0]='true::custom'
        run('restore')
        assert layout[0]=='true::custom'

        mod.STATE_PATH.write_text('{broken')
        try:
            run('on')
            raise AssertionError('Beschadigde status moet geweigerd worden')
        except json.JSONDecodeError:
            pass
        assert layout[0]=='true::custom'
        mod.STATE_PATH.unlink()

        layout[0]='false::false'
        run('on')
        run('restore')
        assert layout[0]=='false::false' and not mod.STATE_PATH.exists()

print('OK: desktopmodus bewaren, activeren, herstellen, crashherstel en gebruikerswijzigingen')
