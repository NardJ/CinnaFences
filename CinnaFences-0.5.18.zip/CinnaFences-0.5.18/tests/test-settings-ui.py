#!/usr/bin/env python3
"""Offline GTK3 UI tests: lightweight stand-ins, no GTK session required."""
import importlib.util
import json
from pathlib import Path
import re
import sys
import types

base = Path(__file__).resolve().parents[1]


class FakeRGBA:
    def __init__(self):
        self.red = self.green = self.blue = 0
    def parse(self, value):
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
            return False
        self.red = int(value[1:3], 16) / 255
        self.green = int(value[3:5], 16) / 255
        self.blue = int(value[5:7], 16) / 255
        return True


class FakeWidget:
    def __init__(self, **kwargs):
        self.values = kwargs
        self.signals = {}
        self.active = False
        self.value = 0
        self.text = kwargs.get('label', '')
        self.children = []
        self.active_index = -1
        self.choices = []
        self.color = FakeRGBA()
        self.font_name = 'Sans 10'
        self.sensitive = True
        self.hexpand = None
        self.wmclass = None
        self.icon_path = None
    def connect(self, name, callback):
        self.signals[name] = callback
    def set_active(self, value):
        if isinstance(value, int) and not isinstance(value, bool):
            self.active_index = value
            if 'changed' in self.signals:
                self.signals['changed'](self)
        else:
            old = self.active
            self.active = value
            if old != value and 'toggled' in self.signals:
                self.signals['toggled'](self)
            if old != value and 'notify::active' in self.signals:
                self.signals['notify::active'](self, None)
    def run(self):
        return 1
    def get_active(self):
        return self.active_index if isinstance(self, FakeCombo) else self.active
    def set_rgba(self, rgba):
        self.color = rgba
    def get_rgba(self):
        return self.color
    def set_font_name(self, font):
        self.font_name = font
    def get_font_name(self):
        return self.font_name
    def set_text(self, value):
        self.text = value
    def set_label(self, value):
        self.text = value
    def get_text(self):
        return self.text
    def set_value(self, value):
        self.value = value
    def get_value_as_int(self):
        return round(self.value)
    def set_sensitive(self, value):
        self.sensitive = value
    def set_hexpand(self, value):
        self.hexpand = value
    def set_border_width(self, value):
        self.border_width = value
    def attach(self, child, left, top, width, height):
        self.children.append((child, left, top, width, height))
    def set_markup(self, markup):
        self.markup = markup
    def set_size_request(self, width, height):
        self.requested_size = (width,height)
    def set_wmclass(self, name, cls):
        self.wmclass = (name, cls)
    def set_icon_from_file(self, path):
        assert Path(path).is_file()
        self.icon_path = path
    def append_page(self, panel, label):
        self.children.append((panel,label))
    def reorder_child(self, panel, index):
        for i, (child, label) in enumerate(self.children):
            if child is panel:
                item = self.children.pop(i)
                self.children.insert(index, item)
                return
        raise AssertionError('Unknown GTK notebook page')
    def append_text(self, value):
        self.choices.append(value)
    def remove_all(self):
        self.choices.clear()
    def __getattr__(self, key):
        return lambda *args, **kwargs: None


class FakeCombo(FakeWidget):
    pass


class FakeSizeGroup(FakeWidget):
    @classmethod
    def new(cls, mode):
        return cls(mode=mode)
    def add_widget(self, widget):
        self.children.append(widget)


class FakeButton(FakeWidget):
    @classmethod
    def new_with_label(cls, label):
        return cls(label=label)


class FakeSpin(FakeWidget):
    @classmethod
    def new_with_range(cls, low, high, step):
        return cls(low=low, high=high, step=step)


fake_gtk = types.SimpleNamespace(
    Window=FakeWidget, Box=FakeWidget, Label=FakeWidget, Switch=FakeWidget,
    CheckButton=FakeWidget, ColorButton=FakeWidget, FontButton=FakeWidget,
    Button=FakeButton, MessageDialog=FakeWidget, Notebook=FakeWidget, Separator=FakeWidget,
    ComboBoxText=FakeCombo, ScrolledWindow=FakeWidget, Grid=FakeWidget,
    Entry=FakeWidget, SpinButton=FakeSpin, SizeGroup=FakeSizeGroup,
    SizeGroupMode=types.SimpleNamespace(HORIZONTAL=0),
    Orientation=types.SimpleNamespace(VERTICAL=1,HORIZONTAL=0),
    Align=types.SimpleNamespace(CENTER=1,START=2),
    WindowPosition=types.SimpleNamespace(CENTER=1),
    PolicyType=types.SimpleNamespace(NEVER=0,AUTOMATIC=1),
    DialogFlags=types.SimpleNamespace(MODAL=1),
    MessageType=types.SimpleNamespace(ERROR=1,QUESTION=2),
    ButtonsType=types.SimpleNamespace(OK=1,YES_NO=2),
    ResponseType=types.SimpleNamespace(YES=1),
    main_quit=lambda:None, main=lambda:None)
fake_gi = types.ModuleType('gi')
fake_gi.require_version = lambda name, version:None
identity_calls = []
fake_gi.repository = types.SimpleNamespace(
    Gtk=fake_gtk,
    Gdk=types.SimpleNamespace(RGBA=FakeRGBA, Screen=types.SimpleNamespace(
        get_default=lambda:types.SimpleNamespace(
            get_n_monitors=lambda:1,
            get_monitor_geometry=lambda i:types.SimpleNamespace(x=0,y=0,width=1920,height=1080))),
        set_program_class=lambda v: identity_calls.append(('class', v))),
    GLib=types.SimpleNamespace(
        set_prgname=lambda v: identity_calls.append(('prgname', v)),
        set_application_name=lambda v: identity_calls.append(('appname', v))))
sys.modules['gi'] = fake_gi
sys.modules['gi.repository'] = fake_gi.repository
spec = importlib.util.spec_from_file_location('cinnafences_settings_ui',base/'cinnafences@local/settings.py')
ui = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ui)

class ConfigStub:
    HIDDEN_LAYOUT='false::false'
    def __init__(self,state=False,layout='true::false'):
        self.state = state
        self.layout = layout
        self.calls = []
        self.fail = False
        self.folders = [Path('/home/test/Desktop/Games'), Path('/home/test/Desktop/3D')]
        self.global_settings = {
            'appearance.background':'#202733','appearance.labelColor':'#ffffff',
            'appearance.backgroundOpacity':.27,'appearance.hoverOpacity':.75,
            'appearance.iconOpacity':.45,'appearance.labelOpacity':.6,
            'appearance.radius':12,'appearance.hoverEnabled':True,
            'appearance.borderEnabled':True,'appearance.borderColor':'#f0f5ff',
            'appearance.borderWidth':1,'appearance.borderOpacity':0.16,
            'icons.size':48,'icons.gridWidth':86,'icons.gridHeight':88,
            'icons.showLabels':True,'icons.labelFont':'Sans','icons.labelFontSize':9
        }
        # Match the real General schema, including newly mirrored Header,
        # Folders & Sections fields; preserve old tests' editing expectations.
        helper_spec=importlib.util.spec_from_file_location('cf_defaults_0514',
            base/'tools/cinnafences-config.py')
        helper_mod=importlib.util.module_from_spec(helper_spec)
        helper_spec.loader.exec_module(helper_mod)
        self.factory_global=helper_mod.default_style()
        self.global_settings.update(self.factory_global)
        self.configs = {folder:{
            'title':folder.name,'enabled':True,
            'appearance':{'background':'#202733','backgroundOpacity':.27,'iconOpacity':.45},
            'icons':{'size':48,'gridWidth':86,'gridHeight':88,
                     'positions':{'game.desktop':[1,3]}}
        } for folder in self.folders}
        self.writes = []
        self.global_writes = []
        self.hotkeys = {'hotkeys.enabled':False, 'hotkeys.toggle':'<Super>f'}
        self.profiles = {}
        self.restore_undo = None
        self.snapping_settings = {
            'snapping.enabled': False, 'snapping.fences': True,
            'snapping.screen': True, 'snapping.grid': False,
            'snapping.distance': 14, 'snapping.gridX': 20, 'snapping.gridY': 20}

    def list_layout_profiles(self):
        return [{'name':n,'monitors':len(p['monitors']),
                 'fences':len(p['fences']),'savedAt':'now'} for n,p in sorted(self.profiles.items())]
    def save_layout_profile(self,name,monitors):
        self.profiles[name]={'monitors':monitors,'fences':{str(f):dict(self.configs[f].get('geometry',
            {'x':50,'y':80,'width':350,'height':270})) for f in self.folders}}
        return len(self.folders)
    def restore_layout_profile(self,name,monitors):
        saved=self.profiles[name]['fences']
        self.restore_undo={f:dict(self.configs[f].get('geometry',
             {'x':50,'y':80,'width':350,'height':270})) for f in self.folders}
        for f in self.folders:self.configs[f]['geometry']=dict(saved[str(f)])
        return len(self.folders)
    def undo_layout_restore(self,monitors):
        for f in self.folders:self.configs[f]['geometry']=self.restore_undo[f]
        self.restore_undo=None
        return len(self.folders)
    def delete_layout_profile(self,name):
        del self.profiles[name]
    def desktop_mode_state(self):
        return {'enabled':True,'originalLayout':'true::false'} if self.state else None
    def nemo_layout(self):
        return self.layout
    def desktop_mode(self,mode):
        self.calls.append(mode)
        if self.fail:
            raise ValueError('gsettings failed')
        if mode=='on':
            self.state=True;self.layout=self.HIDDEN_LAYOUT
        else:
            self.state=False;self.layout='true::false'
    def read_unassigned_enabled(self):
        return getattr(self,'unassigned_enabled',False)
    def read_global_settings(self):
        return dict(self.global_settings)
    def default_style(self):
        return dict(self.factory_global)
    def default_snapping(self):
        return {'snapping.enabled':False,'snapping.fences':True,
                'snapping.screen':True,'snapping.grid':False,
                'snapping.distance':14,'snapping.gridX':20,'snapping.gridY':20}
    def read_snapping_settings(self):
        return dict(self.snapping_settings)
    def read_hotkey_settings(self):
        return dict(self.hotkeys)
    def update_general_settings(self,changes):
        if self.fail:
            raise ValueError('save failed')
        self.global_writes.append(changes)
        self.global_settings.update({k:v for k,v in changes.items() if k.startswith(('appearance.','icons.','header.','sections.','view.'))})
        self.snapping_settings.update({k:v for k,v in changes.items() if k.startswith('snapping.')})
        self.hotkeys.update({k:v for k,v in changes.items() if k.startswith('hotkeys.')})
        if 'unassigned.enabled' in changes:
            self.unassigned_enabled=changes['unassigned.enabled']
    def update_global_settings(self,changes):
        self.update_general_settings(changes)
    def managed_fences(self):
        return [(f,self.configs[f]) for f in self.folders]
    def active_fence_folders(self):
        return self.folders
    def read_fence_settings(self,folder):
        return self.configs[folder]
    def update_fence_settings(self,folder,changes):
        if self.fail:
            raise ValueError('save failed')
        self.writes.append((folder,changes))
        for key,value in changes.items():
            parts=key.split('.')
            if len(parts)==1:
                self.configs[folder][key]=value
            else:
                self.configs[folder].setdefault(parts[0],{})[parts[1]]=value


c=ConfigStub(state=True,layout='false::false')
w=ui.SettingsWindow(c)
assert w.wmclass==('cinnafences-settings','cinnafences-settings')
assert w.values['title']=='CinnaFences Settings'
ui.configure_application_identity()
assert identity_calls==[
    ('prgname','cinnafences-settings'),
    ('appname','CinnaFences Settings'),
    ('class','cinnafences-settings')]
# Both Reload buttons now convey their behavior without implying a restart.
ui_labels = [x for x in (base/'cinnafences@local/settings.py').read_text().splitlines()
             if 'Gtk.Button.new_with_label' in x]
assert all('Reload' not in x for x in ui_labels)
assert len([x for x in ui_labels if "'Revert Changes'" in x])==2
assert w.icon_path and Path(w.icon_path).suffix=='.svg'
assert w.switch.get_active()
assert not c.calls and not c.writes
assert len(w.tabs.children)==4
assert [lbl.text for _,lbl in w.tabs.children]==['General','Per Fence','Monitor Layouts','Manage Fences']
assert w.fence_picker.choices==['Games','3D']
assert w.fence_title.get_text()=='Games'
assert w.fence_controls['icons.size'].get_value_as_int()==48
assert set(w.global_controls)==set(ui.STYLE_KEYS)
assert all(w.global_controls[key].hexpand is False for key in ui.TOGGLES)
assert all(w.fence_controls[key].hexpand is False for key in ui.TOGGLES)
w.switch.set_active(False)
assert c.calls==['off'] and not w.switch.get_active()
w.switch.set_active(True)
assert c.calls[-1]=='on' and w.switch.get_active()
w._restore(None)
assert c.calls[-1]=='restore' and not w.switch.get_active()

# Unassigned is explicitly opt-in and is saved with General defaults.
assert not w.unassigned_switch.get_active()
w.unassigned_switch.set_active(True)
w._apply_general()
assert c.unassigned_enabled is True
w.unassigned_switch.set_active(False)
w._apply_general()
assert c.unassigned_enabled is False
c.global_writes.clear()

# Palette and font selection with separate font-size control.
w.global_controls['appearance.background'].set_rgba(ui.rgba_from_hex('#ab34fe'))
w.global_controls['appearance.labelColor'].set_rgba(ui.rgba_from_hex('#001122'))
w.global_controls['icons.labelFont'].set_font_name('DejaVu Sans 10')
w.global_controls['icons.labelFontSize'].set_value(11)
w.global_controls['appearance.hoverEnabled'].set_active(False)
w._apply_general()
assert len(c.global_writes)==1
assert c.global_settings['appearance.background']=='#ab34fe'
assert c.global_settings['appearance.labelColor']=='#001122'
assert c.global_settings['icons.labelFont']=='DejaVu Sans'
assert c.global_settings['icons.labelFontSize']==11
assert c.global_settings['appearance.hoverEnabled'] is False
w._apply_general()
assert len(c.global_writes)==1

# Existing Fences retain their own settings; inheritance explicitly enabled.
assert not w.inherit_globals.get_active()
w.inherit_globals.set_active(True)
assert not w.fence_controls['icons.size'].sensitive
assert w.fence_controls['appearance.background'].get_rgba().red==int('ab',16)/255
w.fence_title.set_text('Games & VR')
w.lock_geometry.set_active(True)
w._apply_fence()
assert len(c.writes)==1
folder, changes=c.writes[0]
assert folder==c.folders[0]
assert changes=={'title':'Games & VR','geometryLocked':True,'inheritGlobals':True}
assert c.configs[folder]['icons']['positions']=={'game.desktop':[1,3]}
w._apply_fence()
assert len(c.writes)==1

# Switch back from general to local styling, respecting original local values.
w.inherit_globals.set_active(False)
assert w.fence_controls['icons.size'].sensitive
w.fence_controls['icons.size'].set_value(72)
w.fence_controls['appearance.labelColor'].set_rgba(ui.rgba_from_hex('#12aabb'))
w._apply_fence()
assert c.writes[-1][1]=={'inheritGlobals':False,'icons.size':72,'appearance.labelColor':'#12aabb'}
assert c.configs[folder]['icons']['positions']=={'game.desktop':[1,3]}

# On-demand selection and no autosave on focus change.
w.fence_picker.set_active(1)
assert w.fence_title.get_text()=='3D'
x=ui.SettingsWindow(c,c.folders[1])
assert x.fence_picker.get_active()==1
x.fence_title.set_text('Unsaved')
x._on_focus()
assert x.fence_title.get_text()=='Unsaved'

# Errors leave mode and global settings unchanged.
c.fail=True
x.switch.set_active(False)
assert x.switch.get_active()==False or c.state==False
x.global_controls['icons.size'].set_value(65)
x._apply_general()
assert len(c.global_writes)==1

# Hidden Nemo configuration outside CinnaFences isn't incorrectly claimed.
d=ConfigStub(state=False,layout='false::false')
y=ui.SettingsWindow(d)
assert not y.switch.get_active()
assert 'already hidden' in y.status.text
meta=json.loads((base/'cinnafences@local/metadata.json').read_text())
assert meta['external-configuration-app']=='settings.py'
assert (base/'cinnafences@local/settings.py').stat().st_mode & 0o111
assert (base/'tools/cinnafences-config.py').read_bytes()==(base/'cinnafences@local/tools/cinnafences-config.py').read_bytes()
print('OK: English GUI, compact checks, palettes, label fonts, General inheritance, Window icon/WM_CLASS')


# v0.2.5: Reset General is deliberately staged and never touches Nemo mode.
reset_cfg = ConfigStub(state=True, layout='false::false')
reset_cfg.global_settings['icons.size'] = 64
reset_cfg.global_settings['appearance.background'] = '#ff1122'
reset_window = ui.SettingsWindow(reset_cfg)
reset_window._reset_general()
assert reset_window.global_controls['icons.size'].get_value_as_int() == 48
assert reset_window.global_controls['appearance.background'].get_rgba().red == int('20',16)/255
assert reset_cfg.global_settings['icons.size'] == 64  # Nothing saved without Apply.
assert reset_cfg.state and reset_cfg.layout == 'false::false'
assert 'Click Apply' in reset_window.global_status.text
reset_window._apply_general()
assert reset_cfg.global_settings['icons.size'] == 48
assert reset_cfg.global_settings['appearance.background'] == '#202733'
assert reset_cfg.state and reset_cfg.layout == 'false::false'

# v0.2.5: Snapshot General into editable independent settings, never positions.
copy_cfg = ConfigStub()
copy_folder = copy_cfg.folders[0]
copy_cfg.configs[copy_folder]['inheritGlobals'] = True
copy_cfg.global_settings['icons.labelFont'] = 'DejaVu Sans Bold'
copy_cfg.global_settings['appearance.background'] = '#aabbcc'
copy_cfg.global_settings['icons.size'] = 64
copy_window = ui.SettingsWindow(copy_cfg)
assert copy_window.inherit_globals.get_active()
before = dict(copy_cfg.configs[copy_folder]['icons']['positions'])
copy_window._copy_general_to_fence()
assert not copy_window.inherit_globals.get_active()
assert copy_window.fence_controls['icons.size'].sensitive
assert copy_window.fence_controls['appearance.background'].get_rgba().red == int('aa',16)/255
assert copy_window.fence_controls['icons.labelFont'].get_font_name() == 'DejaVu Sans Bold 10'
assert copy_cfg.writes == []  # Copy only stages a local style.
copy_window.fence_controls['icons.size'].set_value(72)
copy_window._apply_fence()
assert copy_cfg.writes
saved = copy_cfg.writes[-1][1]
assert saved['inheritGlobals'] is False
assert saved['icons.size'] == 72
assert saved['appearance.background'] == '#aabbcc'
assert saved['icons.labelFont'] == 'DejaVu Sans Bold'
assert copy_cfg.configs[copy_folder]['icons']['positions'] == before
assert copy_cfg.configs[copy_folder]['inheritGlobals'] is False
print('OK: v0.2.5 staged General reset and editable General-to-Fence snapshot')

# v0.2.7: Geometry controls do not inherit from General and are staged until
# Apply is pressed, including when the Fence's geometry is mouse-locked.
geo_cfg=ConfigStub()
geo_folder=geo_cfg.folders[0]
geo_cfg.configs[geo_folder]['geometry']={'x':50,'y':80,'width':521,'height':370}
geo_w=ui.SettingsWindow(geo_cfg)
assert geo_w.fence_width.get_value_as_int()==521
assert geo_w.fence_height.get_value_as_int()==370
geo_w.fence_width.set_value(800)
geo_w.fence_height.set_value(630)
geo_w.lock_geometry.set_active(True)
assert geo_cfg.writes==[]
geo_w._apply_fence()
assert geo_cfg.writes[-1][1]=={'geometry.width':800,'geometry.height':630,'geometryLocked':True}
assert geo_cfg.configs[geo_folder]['geometry']=={'x':50,'y':80,'width':800,'height':630}
assert geo_cfg.configs[geo_folder]['icons']['positions']=={'game.desktop':[1,3]}
geo_w.fence_width.set_value(900)
geo_w._on_fence_changed()
assert geo_w.fence_width.get_value_as_int()==800
geo_w.inherit_globals.set_active(True)
assert geo_w.fence_width.sensitive is True
assert geo_w.fence_height.sensitive is True
print('OK: v0.2.7 GTK Fence width/height staged, editable when locked or inherited')

# v0.3.2: General snapping staged, saved atomically, reset never changes Nemo.
snap_cfg=ConfigStub(state=True,layout='false::false')
snap_window=ui.SettingsWindow(snap_cfg)
assert set(snap_window.snap_controls)==set(ui.SNAP_KEYS)
assert snap_window.snap_controls['snapping.enabled'].get_active() is False
assert snap_window.snap_controls['snapping.fences'].get_active() is True
assert all(snap_window.snap_controls[k].hexpand is False for k in ui.SNAP_TOGGLES)
snap_window.snap_controls['snapping.enabled'].set_active(True)
snap_window.snap_controls['snapping.grid'].set_active(True)
snap_window.snap_controls['snapping.gridX'].set_value(32)
snap_window.snap_controls['snapping.distance'].set_value(12)
assert snap_cfg.global_writes == []
snap_window._apply_general()
assert snap_cfg.global_writes[-1] == {'snapping.enabled':True,
                                      'snapping.grid':True,
                                      'snapping.gridX':32,
                                      'snapping.distance':12}
assert snap_cfg.snapping_settings['snapping.gridX']==32
snap_window._reset_general()
assert snap_window.snap_controls['snapping.enabled'].get_active() is False
assert snap_cfg.snapping_settings['snapping.enabled'] is True
assert snap_cfg.state is True and snap_cfg.layout=='false::false'
snap_window._apply_general()
assert snap_cfg.snapping_settings == snap_cfg.default_snapping()
print('OK: v0.3.2 General snapping UI, defaults, Apply/Reset, no Nemo changes')

# v0.4.0: opt-in shortcut settings and stable GUI behavior.
hot_cfg=ConfigStub()
hot=ui.SettingsWindow(hot_cfg)
assert hot.hotkey_enable.get_active() is False
assert hot.hotkey_toggle.get_text() == '<Super>f'
assert not hot_cfg.global_writes
hot.hotkey_enable.set_active(True)
hot.hotkey_toggle.set_text('<Control><Alt>g')
hot._apply_general()
assert hot_cfg.hotkeys == {'hotkeys.enabled':True,'hotkeys.toggle':'<Control><Alt>g'}
assert hot_cfg.global_writes[-1] == {'hotkeys.enabled':True,'hotkeys.toggle':'<Control><Alt>g'}
hot._reset_general()
assert hot.hotkey_enable.get_active() is True  # Reset style, not keyboard controls.
hot.hotkey_toggle.set_text('<Super>f')
hot._reload_global()
assert hot.hotkey_toggle.get_text() == '<Control><Alt>g'
assert hot.hotkey_enable.get_active() is True
print('OK: v0.4.0 opt-in show/hide shortcut, staged editing and Revert Changes')

# v0.4.1 Monitor Layouts UI: save, confirm/restore, undo, delete.
assert w.layout_picker.choices==[]
w.layout_name.set_text('Workstation')
w._save_layout_profile()
assert list(c.profiles)==['Workstation']
assert w.layout_picker.get_active()==0
assert w.layout_names==['Workstation']
c.configs[c.folders[0]]['geometry']={'x':300,'y':400,'width':500,'height':300}
w._restore_layout_profile()
assert c.configs[c.folders[0]]['geometry']['x']==50
w._undo_layout_restore()
assert c.configs[c.folders[0]]['geometry']['x']==300
w._delete_layout_profile()
assert w.layout_picker.choices==[] and not c.profiles
print('OK: v0.4.1 Monitor Layouts settings save/restore/undo/delete controls')

# v0.5.1: Small per-Fence category tabs, styled title/section bars, and
# staging semantics. Applying must never modify general settings or icon cells.
view_cfg=ConfigStub()
view_folder=view_cfg.folders[0]
view_win=ui.SettingsWindow(view_cfg)
assert [label.text for _,label in view_win.fence_detail_tabs.children]==[
    'Fence & Layout','Header','Appearance','Folders & Sections','Icons & Labels']
assert view_win.view_mode.get_active()==0
assert view_win.header_controls['header.show'].get_active() is True
assert view_win.section_controls['sections.height'].get_value_as_int()==30
view_win.view_mode.set_active(2)
view_win.header_controls['header.show'].set_active(False)
view_win.header_controls['header.opacity'].set_value(48)
view_win.header_controls['header.background'].set_rgba(ui.rgba_from_hex('#aabbcc'))
view_win.section_controls['sections.height'].set_value(38)
assert view_cfg.writes==[]
view_win._apply_fence()
changes=view_cfg.writes[-1][1]
assert changes=={'view.mode':'rolodex','header.show':False,
                'header.opacity':.48,'header.background':'#aabbcc',
                'sections.height':38},changes
assert view_cfg.configs[view_folder]['icons']['positions']=={'game.desktop':[1,3]}
assert view_cfg.global_writes==[]
view_win.view_mode.set_active(1)
view_win._on_fence_changed()
assert view_win.view_mode.get_active()==2
print('OK: v0.5.1 GTK per-Fence tabs, view mode, header/section style, Apply/Revert')

# v0.5.2: matching navigation categories, section formatting and idle/hover
# titlebar options are staged without losing old Fence values.
opts=ConfigStub()
window=ui.SettingsWindow(opts)
assert [label.text for _,label in window.general_detail_tabs.children]==[
    'Desktop','Header','Appearance','Folders & Sections','Icons & Labels','Positioning','Shortcuts']
assert [label.text for _,label in window.fence_detail_tabs.children]==[
    'Fence & Layout','Header','Appearance','Folders & Sections','Icons & Labels']
assert set(window.global_controls)==set(ui.STYLE_KEYS)
assert set(window.fence_controls)==set(ui.STYLE_KEYS)
assert 'sections.fontFamily' in window.section_controls
assert 'view.tabsInHeader' in window.section_controls
assert 'header.hoverOpacity' in window.header_controls
window.view_mode.set_active(1)
window.section_controls['view.tabsInHeader'].set_active(True)
window.section_controls['sections.alignment'].set_active(0)
window.section_controls['sections.showCollapseButton'].set_active(False)
window.section_controls['sections.fontFamily'].set_font_name('DejaVu Sans 10')
window.section_controls['sections.hoverBackground'].set_rgba(ui.rgba_from_hex('#abcd12'))
window.section_controls['sections.hoverOpacity'].set_value(67)
window.header_controls['header.fontFamily'].set_font_name('Liberation Sans 10')
window.header_controls['header.hoverTextColor'].set_rgba(ui.rgba_from_hex('#fedcba'))
window.header_controls['header.hoverOpacity'].set_value(29)
window._apply_fence()
changed=opts.writes[-1][1]
assert changed['view.mode']=='tabs'
assert changed['view.tabsInHeader'] is True
assert changed['sections.alignment']=='left'
assert changed['sections.showCollapseButton'] is False
assert changed['sections.fontFamily']=='DejaVu Sans'
assert changed['sections.hoverBackground']=='#abcd12'
assert changed['sections.hoverOpacity']==.67
assert changed['header.fontFamily']=='Liberation Sans'
assert changed['header.hoverTextColor']=='#fedcba'
assert changed['header.hoverOpacity']==.29
assert opts.global_writes==[]
window._on_fence_changed()
assert window.section_controls['sections.alignment'].get_active()==0
assert window.section_controls['view.tabsInHeader'].get_active()
print('OK: v0.5.2 General categories, Per Fence Folders & Sections, idle/hover, font, alignment and tab-header settings')

# v0.5.3: Rolodex auto-height has staged and validated GUI fields; it does not
# mutate the manual Fence dimensions or files until Apply.
autocfg=ConfigStub()
autogui=ui.SettingsWindow(autocfg)
assert not autogui.section_controls['view.autoFitHeight'].get_active()
assert autogui.section_controls['view.autoFitMaxHeight'].get_value_as_int()==720
autogui.view_mode.set_active(2)
autogui.section_controls['view.autoFitHeight'].set_active(True)
autogui.section_controls['view.autoFitMaxHeight'].set_value(570)
assert autocfg.writes==[]
autogui._apply_fence()
autochange=autocfg.writes[-1][1]
assert autochange['view.mode']=='rolodex' and autochange['view.autoFitHeight'] is True
assert autochange['view.autoFitMaxHeight']==570
assert 'geometry.height' not in autochange
assert autocfg.global_writes==[]
autogui._on_fence_changed()
assert autogui.section_controls['view.autoFitHeight'].get_active()
assert autogui.section_controls['view.autoFitMaxHeight'].get_value_as_int()==570
print('OK: v0.5.3 GTK staged Rolodex auto-fit, max height and preserving manual height')

# v0.5.4: The form remains staged, but layout fields are inside a category,
# the Header is second and the icon settings are last. Choices have equal width.
gui54=ui.SettingsWindow(ConfigStub())
assert [label.text for _,label in gui54.fence_detail_tabs.children] == [
    'Fence & Layout','Header','Appearance','Folders & Sections','Icons & Labels']
assert gui54.fence_title.get_text() == 'Games'
for key in ['sections.fontFamily','sections.fontSize','sections.alignment']:
    assert gui54.section_controls[key].requested_size == (158,-1)
assert gui54.header_controls['header.fontFamily'].requested_size == (158,-1)
assert gui54.view_mode.choices[2] == 'Rolodex (accordion)'
for control in [gui54.view_mode, gui54.section_controls['sections.fontSize'],
                gui54.section_controls['sections.alignment'],
                gui54.section_controls['sections.fontFamily'],
                gui54.header_controls['header.fontFamily']]:
    assert control in gui54._section_choice_group.children
print('OK: v0.5.4 Settings category order, staged layout, section/header controls')

# v0.5.5: All category pages have matching inset; the desktop toggle and
# monitor profile groups are aligned without altering saved actions.
polished=ui.SettingsWindow(ConfigStub(state=True,layout='false::false'))
for book in (polished.general_detail_tabs,polished.fence_detail_tabs):
    assert all(page.border_width==12 for page,label in book.children)
assert polished.switch.values['label']=='Hide regular desktop icons (Nemo)'
assert polished.restore_desktop_button.sensitive is True
assert 'hidden by CinnaFences' in polished.status.text
no_backup=ui.SettingsWindow(ConfigStub(state=False,layout='true::false'))
assert no_backup.restore_desktop_button.sensitive is False
assert 'visible' in no_backup.status.text
monitor_pane=polished.tabs.children[2][0]
assert monitor_pane.border_width==16
form=polished.layout_form
assert form.values['column_spacing']==14, 'Expected one uniformly aligned monitor layout grid' 
placements=form.children
assert any(w is polished.layout_picker and col==1 and row==2 for w,col,row,_,_ in placements)
assert any(w is polished.layout_name and col==1 and row==6 for w,col,row,_,_ in placements)
assert len([w for w,c,r,_,_ in placements if r in (1,5)])==2
print('OK: v0.5.5 padded categories, clear Desktop controls and aligned Monitor Layouts sections')

# 0.5.14: General and Per Fence presentation controls match one-to-one.
parity_cfg=ConfigStub()
parity_ui=ui.SettingsWindow(parity_cfg)
assert set(parity_ui.global_header_controls)==set(parity_ui.header_controls)
assert set(parity_ui.global_section_controls)==set(parity_ui.section_controls)
assert parity_ui.global_view_mode.get_active()==0
assert not parity_ui.inherit_advanced.get_active()
parity_ui.global_header_controls['header.background'].set_rgba(ui.rgba_from_hex('#aabbcc'))
parity_ui.global_section_controls['sections.height'].set_value(34)
parity_ui.global_section_controls['view.tabsInHeader'].set_active(True)
parity_ui.global_view_mode.set_active(1)
parity_ui._apply_general()
assert parity_cfg.global_settings['header.background']=='#aabbcc'
assert parity_cfg.global_settings['sections.height']==34
assert parity_cfg.global_settings['view.mode']=='tabs'
assert parity_cfg.global_settings['view.tabsInHeader'] is True
assert not parity_ui.inherit_globals.get_active()
parity_ui.inherit_advanced.set_active(True)
assert not parity_ui.header_controls['header.background'].sensitive
assert not parity_ui.section_controls['sections.height'].sensitive
assert parity_ui.view_mode.sensitive and parity_ui.view_mode.get_active()==0
assert parity_ui.header_controls['header.background'].get_rgba().blue==int('cc',16)/255
parity_ui._apply_fence()
assert parity_cfg.writes[-1][1]=={'inheritAdvancedGlobals':True}
parity_ui.inherit_advanced.set_active(False)
assert parity_ui.header_controls['header.background'].sensitive
parity_ui._apply_fence()
assert parity_cfg.writes[-1][1]=={'inheritAdvancedGlobals':False}
print('OK: 0.5.14 General-Per Fence category parity, scoped inheritance, original view unchanged')

# v0.5.16: Enabled virtual Desktop/Unassigned is a normal Per Fence choice.
virtual_cfg=ConfigStub()
virtual_cfg.DESKTOP=Path('/home/test/Desktop')
virtual_cfg.unassigned_enabled=True
virtual_cfg.folders.append(virtual_cfg.DESKTOP)
virtual_cfg.configs[virtual_cfg.DESKTOP]={
    'title':'Desktop / Unassigned','enabled':True,'view':{'mode':'icons'},
    'geometry':{'x':60,'y':410,'width':350,'height':270},
    'appearance':{'background':'#202733'},'icons':{'size':48},
}
virtual_ui=ui.SettingsWindow(virtual_cfg)
assert virtual_ui.fence_picker.choices[-1]=='Desktop / Unassigned'
virtual_ui._reload_fence_list(virtual_cfg.DESKTOP)
assert virtual_ui._selected_folder()==virtual_cfg.DESKTOP
assert virtual_ui.fence_title.get_text()=='Desktop / Unassigned'
assert virtual_ui.view_mode.get_active()==0 and not virtual_ui.view_mode.sensitive
virtual_ui.fence_title.set_text('Loose Desktop Files')
virtual_ui._apply_fence()
assert virtual_cfg.configs[virtual_cfg.DESKTOP]['title']=='Loose Desktop Files'
assert virtual_ui.view_mode.get_active()==0 and not virtual_ui.view_mode.sensitive
print('OK: 0.5.16 Unassigned appears in Per Fence with title/style/geometry and Icons-only view')

# v0.5.17: Manage Fences selector and create field are compact, and the
# actions are mutually exclusive/contextual (Remove vs. Reactivate).
manage_cfg=ConfigStub()
manage_ui=ui.SettingsWindow(manage_cfg)
assert manage_ui.manage_picker.requested_size==(280,-1)
assert manage_ui.manage_new_name.requested_size==(280,-1)
assert manage_ui.manage_picker.hexpand is False
assert manage_ui.manage_new_name.hexpand is False
assert manage_ui.manage_visibility_button.text=='Hide'
assert manage_ui.manage_lifecycle_button.text=='Remove from Desktop…'
assert manage_ui.manage_visibility_button.sensitive
first=manage_cfg.folders[0]
manage_cfg.configs[first]['hidden']=True
manage_ui._reload_managed_fences(first)
assert manage_ui.manage_visibility_button.text=='Show'
assert 'Hidden' in manage_ui.manage_details.text
manage_cfg.configs[first]['enabled']=False
manage_ui._reload_managed_fences(first)
assert manage_ui.manage_lifecycle_button.text=='Reactivate Fence'
assert not manage_ui.manage_visibility_button.sensitive
assert 'Removed' in manage_ui.manage_details.text
manage_cfg.configs[first]['enabled']=True
manage_cfg.configs[first]['hidden']=False
manage_ui._reload_managed_fences(first)
assert manage_ui.manage_lifecycle_button.text=='Remove from Desktop…'
assert manage_ui.manage_visibility_button.text=='Hide'
print('OK: 0.5.17 compact Manage Fences, contextual Hide/Show and Remove/Reactivate')

# v0.5.18: Both forms share exact GTK grid column positions; unlike a
# separate HBox for each row, the controls and buttons line up consistently.
select_columns=[(c,l,t) for c,l,t,w,h in manage_ui.manage_selector_grid.children]
create_columns=[(c,l,t) for c,l,t,w,h in manage_ui.manage_create_grid.children]
assert (manage_ui.manage_picker,1,0) in select_columns
assert (manage_ui.manage_details,1,1) in select_columns
assert (manage_ui.manage_new_name,1,0) in create_columns
assert (manage_ui.manage_existing,1,1) in create_columns
assert (manage_ui.manage_status,1,2) in create_columns
assert manage_ui.manage_picker.requested_size==manage_ui.manage_new_name.requested_size

# Rename in Manage Fences must also refresh the Per Fence chooser AND the
# editable title. Distinguish folder identity if the title is customized.
sync_cfg=ConfigStub()
sync_ui=ui.SettingsWindow(sync_cfg)
folder=sync_cfg.folders[0]
sync_cfg.configs[folder]['title']='Development'
sync_ui._reload_managed_fences(folder)
assert sync_ui.manage_picker.choices[0]=='Development'
assert sync_ui.fence_picker.choices[0]=='Development  [Games]'
assert sync_ui.fence_title.get_text()=='Development'
# A partially edited form must never be destroyed by a management refresh.
sync_ui.fence_width.set_value(567)
sync_cfg.configs[folder]['title']='Renamed again'
sync_ui._reload_managed_fences(folder)
assert sync_ui.fence_width.get_value_as_int()==567
assert sync_ui.fence_title.get_text()=='Renamed again'
assert sync_ui.fence_picker.choices[0]=='Renamed again  [Games]'
assert 'Unapplied edits kept' in sync_ui.fence_status.text
sync_ui._apply_fence()
assert sync_cfg.configs[folder]['title']=='Renamed again'
assert sync_cfg.configs[folder]['geometry']['width']==567
# And rename through Per Fence must update the Manage Fences selector too.
sync_ui.fence_title.set_text('Arcade')
sync_ui._apply_fence()
assert sync_ui.manage_picker.choices[0]=='Arcade'
assert sync_ui.fence_picker.choices[0]=='Arcade  [Games]'
print('OK: v0.5.18 aligned Manage Fences grids, renamed Per Fence titles and retained edits')
