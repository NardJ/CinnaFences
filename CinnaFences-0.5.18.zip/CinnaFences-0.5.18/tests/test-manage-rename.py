#!/usr/bin/env python3
"""New v0.5.13 regression tests, isolated temporary Desktop with fake Gio move."""
import importlib.util, json, os, sys, tempfile, types
from pathlib import Path

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cfg513',root/'tools/cinnafences-config.py')
conf=importlib.util.module_from_spec(spec);spec.loader.exec_module(conf)

class FakeFile:
    def __init__(self,path):self.path=Path(path)
    def move(self,target,flags,cancellable,progress):
        if target.path.exists() or target.path.is_symlink():
            raise FileExistsError('refusing overwrite')
        self.path.rename(target.path)
class FakeGio:
    class FileCopyFlags: NONE=0
    class File:
        @staticmethod
        def new_for_path(p):return FakeFile(p)
sys.modules['gi']=types.ModuleType('gi')
sys.modules['gi.repository']=types.SimpleNamespace(Gio=FakeGio)

with tempfile.TemporaryDirectory(prefix='cinnafences-513-') as tmp:
    conf.DESKTOP=Path(tmp)/'Desktop';conf.DESKTOP.mkdir()
    games=conf.create_managed_fence('Games')
    assert games.is_dir()
    assert games in conf.active_fence_folders()
    assert conf.create_managed_fence('Games') if False else True
    try:conf.create_managed_fence('Games')
    except ValueError:pass
    else:raise AssertionError('duplicate folder accepted')
    ordinary=conf.DESKTOP/'Existing';ordinary.mkdir()
    (ordinary/'files.txt').write_text('safe')
    try:conf.create_managed_fence('Existing')
    except ValueError:pass
    else:raise AssertionError('ordinary folder taken over without opt in')
    assert conf.create_managed_fence('Existing',True)==ordinary
    assert (ordinary/'files.txt').read_text()=='safe'
    conf.change_managed_fence(games,title='Arcade',hidden=True)
    managed=dict(conf.managed_fences())
    assert managed[games]['title']=='Arcade' and managed[games]['hidden'] is True
    conf.change_managed_fence(games,enabled=False)
    assert games not in conf.active_fence_folders()
    assert games in dict(conf.managed_fences())
    conf.change_managed_fence(games,enabled=True,hidden=False)
    assert games in conf.active_fence_folders() and not json.loads((games/conf.CONFIG).read_text())['hidden']
    assert (ordinary/'files.txt').read_text()=='safe'
    for name in ['../escape','Bad/Name','', '.private', 'bad\\folder']:
        try:conf.create_managed_fence(name)
        except ValueError:pass
        else:raise AssertionError('unsafe name accepted '+repr(name))
    target=Path(tmp)/'outside';target.mkdir()
    (conf.DESKTOP/'symlink').symlink_to(target,target_is_directory=True)
    try:conf.create_managed_fence('symlink',True)
    except ValueError:pass
    else:raise AssertionError('symlink folder accepted')
    cfgpath=games/conf.CONFIG
    existing=json.loads(cfgpath.read_text())
    existing['icons']['positions']={'sample.txt':[3,2]}
    cfgpath.write_text(json.dumps(existing))
    (games/'sample.txt').write_text('original bytes')
    (games/'taken.txt').write_text('unchanged')
    try:conf.rename_icon_file(games/'sample.txt','taken.txt')
    except FileExistsError:pass
    else:raise AssertionError('overwrite accepted')
    assert (games/'taken.txt').read_text()=='unchanged'
    for name in ['', '.cinnafence.json','a/b','../bad', 'bad\\name']:
        try:conf.rename_icon_file(games/'sample.txt',name)
        except ValueError:pass
        else:raise AssertionError('unsafe rename accepted '+repr(name))
    assert conf.rename_icon_file(games/'sample.txt','other.txt')
    assert not (games/'sample.txt').exists() and (games/'other.txt').read_text()=='original bytes'
    assert json.loads(cfgpath.read_text())['icons']['positions']['other.txt']==[3,2]
    assert 'sample.txt' not in json.loads(cfgpath.read_text())['icons']['positions']
    section=games/'Slicers';section.mkdir()
    (section/'cura.desktop').write_text('[Desktop Entry]\n')
    assert conf.rename_icon_file(section/'cura.desktop','cura-new.desktop')
    assert (section/'cura-new.desktop').exists()
    original=Path(tmp)/'outside'/'original'
    original.write_text('must stay')
    link=games/'shortcut'
    link.symlink_to(original)
    assert conf.rename_icon_file(link,'shortcut-new')
    assert original.read_text()=='must stay'
    assert (games/'shortcut-new').is_symlink() and not link.exists()
    for field,value in [('appearance.borderEnabled',False),('appearance.borderColor','#abcdef'),
                        ('appearance.borderWidth',4),('appearance.borderOpacity',.5)]:
        conf.update_fence_settings(games,{field:value})
    a=json.loads(cfgpath.read_text())['appearance']
    assert (a['borderEnabled'],a['borderColor'],a['borderWidth'],a['borderOpacity'])==(False,'#abcdef',4,.5)
    for field,value in [('appearance.borderColor','#nope'),('appearance.borderWidth',10),
                        ('appearance.borderOpacity',-1)]:
        try:conf.update_fence_settings(games,{field:value})
        except ValueError:pass
        else:raise AssertionError('invalid border accepted')
print('OK: v0.5.13 safe create/disable/restore, border, rename and no-overwrite')
