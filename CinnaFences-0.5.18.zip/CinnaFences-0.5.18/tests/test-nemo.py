#!/usr/bin/env python3
"""Test Nemo menu operations without modifying the real user's Desktop."""
import json
import shlex
import configparser
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent.parent
CLI = ROOT / 'tools' / 'cinnafences-config.py'
with tempfile.TemporaryDirectory(prefix='cinnafences-nemo-test-') as tmp:
    home = Path(tmp) / 'home'
    desk = home / 'Desktop'
    folder = desk / '3D'
    folder.mkdir(parents=True)
    (folder / 'file.desktop').write_text('[Desktop Entry]\nName=Test\n', encoding='utf-8')
    env = dict(os.environ, HOME=str(home))

    def run(command, *args):
        return subprocess.run([sys.executable, str(CLI), command, *map(str, args)],
                              check=True, text=True, capture_output=True, env=env)

    run('activate', folder)
    cfg_path = folder / '.cinnafence.json'
    assert cfg_path.exists()
    cfg = json.loads(cfg_path.read_text())
    cfg['appearance']['background'] = '#abcdef'
    cfg_path.write_text(json.dumps(cfg))
    run('disable', folder)
    assert not json.loads(cfg_path.read_text())['enabled']
    run('activate', folder)
    restored = json.loads(cfg_path.read_text())
    assert restored['enabled'] and restored['appearance']['background'] == '#abcdef'
    assert (folder / 'file.desktop').exists()
    outer = home / 'Documents'
    outer.mkdir()
    fail = subprocess.run([sys.executable, str(CLI), 'activate', str(outer)], env=env,
                          text=True, capture_output=True)
    assert fail.returncode and not (outer / '.cinnafence.json').exists()

    xdg = home / '.local/share'
    env['XDG_DATA_HOME'] = str(xdg)
    installer = subprocess.run(['bash', str(ROOT / 'install-nemo-actions.sh')], env=env,
                               text=True, capture_output=True)
    assert installer.returncode == 0, installer.stderr
    actions = xdg / 'nemo/actions'
    assert 'Conditions=desktop;' not in (actions / 'cinnafences-activate.nemo_action').read_text()
    assert (actions / 'cinnafences-move.nemo_action').exists()
    shortcut_action = (actions / 'cinnafences-shortcut.nemo_action').read_text()
    assert 'Exec=<cinnafences/create-shortcut.py %U>' in shortcut_action
    assert 'Selection=notnone' in shortcut_action
    assert 'Quote=double' in shortcut_action
    assert (actions / 'cinnafences/create-shortcut.py').is_file()
    assert os.access(actions / 'cinnafences/create-shortcut.py', os.X_OK)
    assert 'Name=Create symbolic link in CinnaFence...' in shortcut_action
    launcher_action = (actions / 'cinnafences-launcher.nemo_action').read_text()
    assert 'Exec=<cinnafences/create-launcher.py %U>' in launcher_action
    assert 'Selection=any' in launcher_action
    assert 'Dependencies=cinnamon-desktop-editor;' in launcher_action
    assert os.access(actions / 'cinnafences/create-launcher.py', os.X_OK)
    move_action = (actions / 'cinnafences-move.nemo_action').read_text()
    assert 'Exec=<cinnafences/send-to-fence.py %F>' in move_action
    assert 'Selection=s' in move_action
    assert (actions / 'cinnafences/send-to-fence.py').exists()
    dispatch = actions / 'cinnafences/dispatch.py'
    assert os.access(dispatch, os.X_OK), 'Nemo-helper moet uitvoerbaar zijn'

    # Simuleer de echte Nemo-parser (libnemo-private/nemo-action.c):
    # <...> werkt alleen wanneer het volledige Exec-veld ermee is omgeven.
    # De fout in 0.1.8 gebruikte <script> activate %F, waardoor de prefix
    # van de action-directory NIET werd toegevoegd en de klik niets deed.
    def run_installed_action(action_name, target):
        action_file = actions / f'cinnafences-{action_name}.nemo_action'
        parser = configparser.ConfigParser(interpolation=None)
        parser.read(action_file, encoding='utf-8')
        command = parser['Nemo Action']['Exec']
        assert command.startswith('<') and command.endswith('>'), command
        command = command[1:-1]
        command = str(actions / command.replace('%F', shlex.quote(str(target))))
        result = subprocess.run(shlex.split(command), env=env,
                                text=True, capture_output=True)
        assert result.returncode == 0, result.stderr

    spaced = desk / 'My Games & VR'
    spaced.mkdir()
    run_installed_action('activate', spaced)
    assert json.loads((spaced / '.cinnafence.json').read_text())['enabled']
    run_installed_action('disable', spaced)
    assert not json.loads((spaced / '.cinnafence.json').read_text())['enabled']
    run_installed_action('activate', spaced)
    assert json.loads((spaced / '.cinnafence.json').read_text())['enabled']
    subprocess.run([sys.executable, str(dispatch), 'disable', str(folder)], env=env, check=True)
    assert not json.loads(cfg_path.read_text())['enabled']
    subprocess.run(['bash', str(ROOT / 'uninstall-nemo-actions.sh')], env=env, check=True)
    assert not (actions / 'cinnafences-activate.nemo_action').exists()
    assert not (actions / 'cinnafences-move.nemo_action').exists()
    assert not (actions / 'cinnafences-shortcut.nemo_action').exists()
    assert not (actions / 'cinnafences-launcher.nemo_action').exists()
    assert not (actions / 'cinnafences/create-launcher.py').exists()
    assert not (actions / 'cinnafences/create-shortcut.py').exists()
    assert not (actions / 'cinnafences/send-to-fence.py').exists()
    assert cfg_path.exists()

print('Nemo Actions / veilige Desktop-configuratietests geslaagd')
