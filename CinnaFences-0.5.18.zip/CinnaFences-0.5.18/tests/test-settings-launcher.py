#!/usr/bin/env python3
"""No-GTK, no-X11 test for dock application registration and safe upgrades."""
import configparser
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ICON_SOURCE = ROOT / 'cinnafences@local/cinnafences-icon.svg'

with tempfile.TemporaryDirectory(prefix='cinnafences-dock-test-') as folder:
    home = Path(folder) / 'home with spaces'
    home.mkdir()
    data = home / '.local/share'
    script = data / 'cinnamon/extensions/cinnafences@local/settings.py'
    script.parent.mkdir(parents=True)
    shutil.copy2(ROOT / 'cinnafences@local/settings.py', script)
    env = {**os.environ, 'HOME': str(home), 'XDG_DATA_HOME': str(data)}
    launcher = data / 'applications/cinnafences-settings.desktop'
    icon = data / 'icons/hicolor/scalable/apps/cinnafences-settings.svg'
    def call(name):
        return subprocess.run(['bash', str(ROOT / name)], text=True,
                              capture_output=True, env=env)

    first = call('install-settings-launcher.sh')
    assert first.returncode==0, (first.stdout,first.stderr)
    assert launcher.is_file() and icon.read_bytes()==ICON_SOURCE.read_bytes()
    body=launcher.read_text()
    assert body.startswith('# CinnaFences managed launcher\n')
    parser=configparser.ConfigParser(interpolation=None)
    parser.read(launcher)
    entry=parser['Desktop Entry']
    assert entry['Name']=='CinnaFences Settings'
    assert entry['StartupWMClass']=='cinnafences-settings'
    assert entry['Icon']=='cinnafences-settings'
    assert entry['Exec']=='/usr/bin/python3 "'+str(script)+'"'
    assert entry['Terminal']=='false'
    assert call('install-settings-launcher.sh').returncode==0
    assert call('uninstall-settings-launcher.sh').returncode==0
    assert not launcher.exists() and not icon.exists()

    # Never trample a user's existing launcher during upgrade.
    launcher.write_text('[Desktop Entry]\nName=My custom launcher\n')
    conflict=call('install-settings-launcher.sh')
    assert conflict.returncode != 0
    assert 'My custom launcher' in launcher.read_text()
    assert call('uninstall-settings-launcher.sh').returncode==0
    assert launcher.exists()

    # A pre-existing custom icon must also survive an attempted install.
    launcher.unlink()
    icon.write_text('<svg>my modified icon</svg>')
    conflict_icon=call('install-settings-launcher.sh')
    assert conflict_icon.returncode != 0
    assert icon.read_text() == '<svg>my modified icon</svg>'
    assert not launcher.exists()

print('OK: CinnaFences dock launcher / app name / startup WM_CLASS / icon / safe cleanup')
