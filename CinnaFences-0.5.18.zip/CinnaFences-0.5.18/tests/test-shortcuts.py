#!/usr/bin/env python3
"""Isolated symlink shortcuts, no UI needed and no user Desktop mutations."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from pathlib import Path as _Path

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('shortcut_action', root/'nemo-actions/create-shortcut.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

with tempfile.TemporaryDirectory(prefix='cinnafences-shortcuts-') as tmp:
    home = Path(tmp)
    desk = home/'Desktop'; desk.mkdir()
    fence = desk/'3D'; fence.mkdir()
    (fence/'.cinnafence.json').write_text(json.dumps({'version':1,'enabled':True}))
    cad = fence/'CAD'; cad.mkdir()
    slicers = fence/'Slicers'; slicers.mkdir()
    (fence/'Disabled').mkdir()
    (fence/'Hidden').symlink_to(home, target_is_directory=True)
    (fence/'.private').mkdir()
    off = desk/'Disabled Fence'; off.mkdir()
    (off/'.cinnafence.json').write_text(json.dumps({'enabled':False}))
    assert [t[0] for t in a.destinations(fence)] == ['Main','CAD','Disabled','Slicers']
    docs = home/'Documents'; docs.mkdir()
    text = docs/'My Notes & Plans.txt'; text.write_text('Original remains intact!')
    app = docs/'demo.desktop'; app.write_text('[Desktop Entry]\nName=Demo\n')
    fld = docs/'Directory with spaces'; fld.mkdir()
    (fld/'keep.txt').write_text('keep')
    # Nemo passes URI tokens: protects spaces, shell metacharacters and quotes.
    assert a.local_nemo_uri(text.as_uri()) == str(text)
    assert a.local_nemo_uri('file:///tmp/a%20%22quoted%22%20%24file.txt') == '/tmp/a "quoted" $file.txt'
    for remote in ['smb://server/share/file', 'file://otherhost/a.txt', 'file:///tmp/foo?bar']:
        try: a.local_nemo_uri(remote)
        except ValueError: pass
        else: raise AssertionError('remote or unsafe URI accepted: ' + remote)
    # Main and Rolodex destination are both real paths, never copies.
    link = a.create_shortcuts([text],desk,fence,'Main')[0]
    assert link.is_symlink() and link.readlink()==text.resolve()
    assert text.read_text()=='Original remains intact!'
    assert link.read_text()==text.read_text()
    targets = a.create_shortcuts([app, fld],desk,fence,'CAD')
    assert len(targets)==2 and all(t.is_symlink() for t in targets)
    assert (cad/'demo.desktop').readlink()==app.resolve()
    assert (cad/fld.name).readlink()==fld.resolve()
    assert (fld/'keep.txt').read_text()=='keep'
    # Normal filename collision creates an explicitly named shortcut. Never overwrites.
    (slicers/'demo.desktop').write_text('EXISTING')
    out=a.create_shortcuts([app],desk,fence,'Slicers')[0]
    assert out.name=='demo (shortcut).desktop' and out.is_symlink()
    assert (slicers/'demo.desktop').read_text()=='EXISTING'
    def fail(items, destf, section):
        try:a.create_shortcuts(items,desk,destf,section)
        except (ValueError,OSError):pass
        else:raise AssertionError(f'accepted unsafe shortcut: {items}, {destf}, {section}')
    fail([app],fence,'CAD') # Duplicate pointing to the same source
    fail([app],fence,'Slicers')
    fail([app],off,'Main')
    fail([app],fence,'../Slicers')
    fail([app],fence,'Hidden')
    fail([app],fence,'.private')
    fail([app],fence,'Nonexistent')
    fail([],fence,'Main')
    fail([app]*33,fence,'Main')
    fail([app,app],fence,'Main')
    fail([fence],fence,'Main')
    # Symbolic-link *sources* are rejected: no endless link chains or broken aliases.
    alias=docs/'alias.txt'; alias.symlink_to(text)
    fail([alias],fence,'CAD')
    # Quotation marks, unicode and special shell characters are safe as argv values.
    weird=docs/'crazy "quoted" € & $file.txt'; weird.write_text('weird')
    weird_link=a.create_shortcuts([weird],desk,fence,'CAD')[0]
    assert weird_link.readlink()==weird.resolve()
    # Source in the same folder: suffix, not overwrite.
    own=fence/'same.txt'; own.write_text('same')
    own_link=a.create_shortcuts([own],desk,fence,'Main')[0]
    assert own_link.name=='same (shortcut).txt' and own.read_text()=='same'
    # Atomic rollback of only newly created shortcuts after partial failure.
    new1=docs/'A1.txt';new1.write_text('a')
    new2=docs/'A2.txt';new2.write_text('b')
    calls=[]
    def failing_symlink(source,name,fd):
        calls.append(name)
        if len(calls)==2: raise OSError('simulated disk failure')
        os.symlink(source,name,dir_fd=fd)
    try: a.create_shortcuts([new1,new2],desk,fence,'Slicers',symlink_creator=failing_symlink)
    except OSError:pass
    else:raise AssertionError('Expected failure')
    assert not (slicers/'A1.txt').exists() and not (slicers/'A1.txt').is_symlink()
    assert not (slicers/'A2.txt').exists() and not (slicers/'A2.txt').is_symlink()
    assert new1.read_text()=='a' and new2.read_text()=='b'
    # New link in another section can point to already linked original there.
    link_again=a.create_shortcuts([app],desk,fence,'Main')[0]
    assert link_again.is_symlink() and link_again.readlink()==app.resolve()
print('OK: shortcuts from Nemo, multi-select, sections, no overwrite, collision, rollback, local sources')
