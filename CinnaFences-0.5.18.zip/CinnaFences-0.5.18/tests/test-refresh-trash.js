'use strict';
// Regressions for external .desktop launchers added to an open Rolodex section,
// and right-click Trash of the launcher (without touching its AppImage target).
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const source=fs.readFileSync(__dirname+'/../cinnafences@local/extension.js','utf8');
const watchers=new Map(), trashed=[], scans=[], notices=[], errors=[];
const files=new Map([
  ['/Desktop/3D/Slicers/Repetier.desktop',{target:'/Apps/Repetier.AppImage'}],
  ['/Desktop/3D/Slicers/Slicer.desktop',{}],
  ['/Desktop/3D/CAD/FreeCAD.desktop',{}],
  ['/Apps/Repetier.AppImage',{}]
]);
const Gio={FileMonitorFlags:{NONE:0}, File:{new_for_path(p){return {
  monitor_directory(){const mon={path:p, cancelCount:0,
    connect(event,cb){assert.equal(event,'changed');this.changed=cb;},
    cancel(){this.cancelCount++}};watchers.set(p,mon);return mon;},
  trash(){if(!files.has(p))throw Error('No file found: '+p);
    if(p.includes('Slicer.desktop') && testFailure)throw Error('Permission denied');
    files.delete(p);trashed.push(p);}
}}}};
let testFailure=false;
const Main={notify:(...x)=>notices.push(x)};
const context=vm.createContext({Gio,Main,files,watchers,trashed,scans,notices,errors,
  imports:{gi:{St:{},Clutter:{ModifierType:{},EVENT_STOP:true,EVENT_PROPAGATE:false},Cinnamon:{},Gio,
   GLib:{build_filenamev:x=>x.join('/'),get_user_config_dir:()=>'/config'},Pango:{},Meta:{}},
   byteArray:{},ui:{main:Main,popupMenu:{}}},global:{logError:e=>errors.push(e)}});
vm.runInContext(source,context,{filename:'extension.js'});
const run=s=>vm.runInContext(s,context);
assert.equal(run(`watchedSectionPaths('/Desktop/3D','icons',['CAD','Slicers']).length`),0);
assert.equal(run(`watchedSectionPaths('/Desktop/3D','rolodex',['CAD','Slicers']).join('|')`),
  '/Desktop/3D/CAD|/Desktop/3D/Slicers');
assert.equal(run(`watchedSectionPaths('/Desktop/3D','tabs',['CAD','..','.private','Other/secret','Slicers']).join('|')`),
  '/Desktop/3D/CAD|/Desktop/3D/Slicers');
const manager=run('Object.create(FenceManager.prototype)');context.fakeManager=manager;
manager.sectionMonitors=new Map();manager.fences=new Map([['/Desktop/3D',{}]]);
manager.queueScan=path=>scans.push(path);manager.dead=false;
const wanted=new Map([['/Desktop/3D/CAD','/Desktop/3D'],['/Desktop/3D/Slicers','/Desktop/3D']]);
context.wanted=wanted;
run('fakeManager._syncSectionMonitors(wanted)');
assert.equal(manager.sectionMonitors.size,2);
const slicers=watchers.get('/Desktop/3D/Slicers');
slicers.changed();assert.deepEqual(scans,['/Desktop/3D']);
run('fakeManager._syncSectionMonitors(wanted)');assert.strictEqual(watchers.get('/Desktop/3D/Slicers'),slicers,'no duplicate monitor');
const reduced=new Map([['/Desktop/3D/CAD','/Desktop/3D']]);context.reduced=reduced;
run('fakeManager._syncSectionMonitors(reduced)');
assert.equal(slicers.cancelCount,1);assert.equal(manager.sectionMonitors.size,1);
// Gio stops sending changed events after cancellation; do not invoke its stale callback manually.
assert.equal(slicers.cancelCount,1);
manager.dead=true;watchers.get('/Desktop/3D/CAD').changed();assert.equal(scans.length,1);
console.log('OK: direct subfolder event schedules parent Fence refresh; monitor cleanup');

const fence=run('Object.create(Fence.prototype)');context.fence=fence;
fence._disposed=false;fence._drag=null;fence._itemContext=false;
fence.folder='/Desktop/3D';fence.manager={queueScan:path=>scans.push(path)};
fence.config={icons:{positions:{'Slicers/Repetier.desktop':[0,0], 'Slicers/Slicer.desktop':[1,0]},undoArrangement:{positions:{}}}};
fence._save=()=>{fence.saved=(fence.saved||0)+1;};
fence._clearItemStates=()=>{for(const it of fence.items)it.selected=false;};
fence._paintItem=()=>{};
const a={name:'Slicers/Repetier.desktop',path:'/Desktop/3D/Slicers/Repetier.desktop',selected:false};
const b={name:'Slicers/Slicer.desktop',path:'/Desktop/3D/Slicers/Slicer.desktop',selected:false};
fence.items=[a,b];fence._selectItem=it=>{a.selected=(it===a);b.selected=(it===b);};
fence.openMenu=(_event,fromItem)=>{fence._itemContext=fromItem;};
assert.equal(run(`fence._itemDown(fence.items[0],{get_button:()=>3,get_coords:()=>[34,56]})`),true);
assert.equal(fence._contextPending.itemContext,true);
// The actual item-context flag is set when the menu opens on right-button release.
fence._itemContext=fence._contextPending.itemContext;
assert.equal(a.selected,true);assert.equal(fence._itemContext,true);
assert.equal(run('fence._trashSelectedItems()'),true);
assert(!files.has(a.path) && files.has('/Apps/Repetier.AppImage'));
assert(trashed.includes(a.path));
assert(!('Slicers/Repetier.desktop' in fence.config.icons.positions));
assert.equal(fence.config.icons.undoArrangement,null);
assert(scans.includes('/Desktop/3D'));
assert.equal(fence.saved,1);
// A menu opened on the Fence background must not expose destructive action.
a.selected=true;fence._itemContext=false;
assert.equal(run('fence._trashSelectedItems()'),false);
assert(!trashed.includes(b.path));
// A filesystem error is reported, and failed entries retain their positions.
fence._itemContext=true;b.selected=true;testFailure=true;
assert.equal(run('fence._trashSelectedItems()'),false);
assert(files.has(b.path));
assert.deepEqual(trashed,[a.path]);
assert(notices.some(n=>n[1].includes('failed')));
console.log('OK: right-click item enables recoverable Trash, AppImage untouched, failures reported');
