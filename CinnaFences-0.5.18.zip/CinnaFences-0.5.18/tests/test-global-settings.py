#!/usr/bin/env python3
"""Validate General defaults in isolated folders, and preserve old Fences."""
import importlib.util
import json
from pathlib import Path
import tempfile

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cinnafences_test_globals',
                                              root / 'tools/cinnafences-config.py')
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)
with tempfile.TemporaryDirectory(prefix='cinnafences-general-test-') as directory:
    home = Path(directory)
    cli.GLOBAL_PATH = home / '.config/cinnafences/defaults.json'
    desktop = home / 'Desktop'
    desktop.mkdir()
    cli.DESKTOP = desktop
    old = desktop / 'Old Games'
    new = desktop / 'New Games'
    old.mkdir(); new.mkdir()
    default = cli.default_style()
    assert default['appearance.labelColor'] == '#ffffff'
    assert default['icons.labelFont'] == 'Sans'
    assert default['icons.labelFontSize'] == 9
    assert cli.read_global_settings() == default
    cli.update_global_settings({'appearance.background':'#fedcba',
                                'appearance.labelColor':'#1200ff',
                                'appearance.backgroundOpacity':0.4,
                                'icons.labelFont':'DejaVu Sans',
                                'icons.labelFontSize':12,
                                'icons.showLabels':False})
    parsed = json.loads(cli.GLOBAL_PATH.read_text())
    assert parsed['appearance']['labelColor'] == '#1200ff'
    assert parsed['icons']['labelFont'] == 'DejaVu Sans'
    assert cli.read_global_settings()['appearance.backgroundOpacity'] == 0.4
    assert not list(cli.GLOBAL_PATH.parent.glob('.defaults-*.tmp'))

    cli.create(new, 50, 80)
    cfg = json.loads((new / cli.CONFIG).read_text())
    assert cfg['inheritGlobals'] is True
    assert cfg['icons']['positions'] == {}
    # Old Fences keep their local values until inheritance is explicitly on.
    cfg['inheritGlobals'] = False
    (new / cli.CONFIG).write_text(json.dumps(cfg))
    cli.update_fence_settings(new, {'inheritGlobals':True, 'icons.labelFont':'Noto Sans',
                                    'appearance.labelColor':'#ff00ff'})
    updated = json.loads((new / cli.CONFIG).read_text())
    assert updated['inheritGlobals'] and updated['icons']['labelFont'] == 'Noto Sans'
    assert updated['appearance']['labelColor'] == '#ff00ff'
    assert updated['icons']['positions'] == {}
    for key, value in [('appearance.labelColor','red'),('icons.labelFont','A";evil'),
                       ('icons.labelFontSize',34),('icons.size',True),
                       ('icons.gridWidth',250),('geometryLocked',True)]:
        original = cli.GLOBAL_PATH.read_bytes()
        try:
            cli.update_global_settings({key:value})
        except ValueError:
            pass
        else:
            raise AssertionError('Unexpectedly accepted global ' + key)
        assert cli.GLOBAL_PATH.read_bytes() == original
    assert not (old / cli.CONFIG).exists()
    assert not cli.GLOBAL_PATH.is_symlink()
print('OK: global palette/font defaults, atomic saves, opt-in inheritance, validation, untouched files')

with tempfile.TemporaryDirectory(prefix='cinnafences-snapping-test-') as directory:
    cli.GLOBAL_PATH=Path(directory)/'.config/cinnafences/defaults.json'
    assert cli.read_snapping_settings()==cli.default_snapping()
    assert cli.read_snapping_settings()['snapping.enabled'] is False
    assert cli.update_general_settings({'snapping.enabled':True,'snapping.fences':True,
        'snapping.grid':True,'snapping.gridX':25,'snapping.gridY':40,
        'appearance.background':'#112233'})
    stored=json.loads(cli.GLOBAL_PATH.read_text())
    assert stored['snapping']['gridX']==25 and stored['snapping']['enabled'] is True
    assert stored['appearance']['background']=='#112233'
    cli.update_global_settings({'icons.size':54})
    assert cli.read_snapping_settings()['snapping.gridX']==25
    cli.update_snapping_settings({'snapping.screen':False})
    assert cli.read_global_settings()['icons.size']==54
    original=cli.GLOBAL_PATH.read_bytes()
    for key,value in [('snapping.gridX',0),('snapping.distance',50),
                      ('snapping.enabled',1),('snapping.gridY',False),
                      ('geometry.width',500)]:
        try:
            cli.update_general_settings({key:value})
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid snapping setting accepted: '+key)
        assert cli.GLOBAL_PATH.read_bytes()==original
    assert not list(cli.GLOBAL_PATH.parent.glob('.defaults-*.tmp'))
print('OK: v0.3.2 snapping persistence, validation, merged style & snapping, atomic writes')

with tempfile.TemporaryDirectory(prefix='cinnafences-shortcut-') as directory:
    cli.GLOBAL_PATH=Path(directory)/'.config/cinnafences/defaults.json'
    assert cli.read_hotkey_settings()=={'hotkeys.enabled':False,'hotkeys.toggle':'<Super>f'}
    cli.update_general_settings({'hotkeys.enabled':True,'hotkeys.toggle':'<Control><Alt>g'})
    assert cli.read_hotkey_settings()=={'hotkeys.enabled':True,'hotkeys.toggle':'<Control><Alt>g'}
    cli.update_general_settings({'snapping.gridX':25,'icons.size':57})
    assert cli.read_hotkey_settings()['hotkeys.enabled'] is True
    stored=cli.GLOBAL_PATH.read_bytes()
    for key,value in [('hotkeys.enabled',1),('hotkeys.toggle','f'),
                      ('hotkeys.toggle','<Super>'),('hotkeys.toggle',''),
                      ('hotkeys.toggle','<Control>Enter;rm -rf /')]:
        try: cli.update_general_settings({key:value})
        except ValueError: pass
        else: raise AssertionError('Invalid shortcut accepted: '+key+' '+str(value))
        assert cli.GLOBAL_PATH.read_bytes()==stored
    assert not list(cli.GLOBAL_PATH.parent.glob('.defaults-*.tmp'))
print('OK: v0.4.0 opt-in shortcut default, safe config merging and validation')
