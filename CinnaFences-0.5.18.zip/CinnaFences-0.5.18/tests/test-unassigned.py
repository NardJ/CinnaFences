#!/usr/bin/env python3
"""Virtual Desktop / Unassigned checkbox never mutates the Desktop."""
import importlib.util, json, tempfile
from pathlib import Path
r=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cf_unassigned',r/'tools/cinnafences-config.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp);c.GLOBAL_PATH=root/'settings'/'defaults.json';c.DESKTOP=root/'Desktop'
    c.DESKTOP.mkdir()
    source=c.DESKTOP/'Keep.txt';source.write_text('unmoved')
    folder=c.DESKTOP/'3D';folder.mkdir()
    cfg=folder/'.cinnafence.json';cfg.write_text('{"enabled":true}')
    assert c.read_unassigned_enabled() is False
    assert c.update_general_settings({'unassigned.enabled':True})
    assert c.read_unassigned_enabled() is True
    assert c.GLOBAL_PATH.exists()
    assert json.loads(c.GLOBAL_PATH.read_text())['unassigned']['enabled'] is True
    assert source.read_text()=='unmoved'
    assert cfg.read_text()=='{"enabled":true}'
    assert c.active_fence_folders() == [folder,c.DESKTOP]
    assert c.read_fence_settings(c.DESKTOP)['title']=='Desktop / Unassigned'
    virtual=c.unassigned_path()
    assert not virtual.exists(), 'Reading must not create settings'
    assert c.update_fence_settings(c.DESKTOP,{
        'title':'My Desktop','inheritGlobals':False,
        'appearance.borderColor':'#AABBCC','appearance.borderWidth':3,
        'appearance.backgroundOpacity':0.41,'icons.size':56,
        'geometry.width':430,'geometry.height':320,
        'header.show':False,'header.fontFamily':'Sans'})
    saved=json.loads(virtual.read_text())
    assert saved['title']=='My Desktop'
    assert saved['icons']['size']==56
    assert saved['appearance']['borderColor']=='#AABBCC'
    assert saved['geometry']=={'x':60,'y':410,'width':430,'height':320}
    assert saved['header']['show'] is False
    assert c.read_fence_settings(c.DESKTOP)['view']['mode']=='icons'
    before=virtual.read_bytes()
    for change in [{'view.mode':'rolodex'}, {'appearance.borderWidth':99},
                   {'title':''}]:
        try:c.update_fence_settings(c.DESKTOP,change)
        except ValueError:pass
        else:raise AssertionError('invalid virtual Fence edit accepted: '+repr(change))
        assert virtual.read_bytes()==before
    assert not (c.DESKTOP/'.cinnafence.json').exists()
    assert source.read_text()=='unmoved'
    assert cfg.read_text()=='{"enabled":true}'
    assert c.update_general_settings({'unassigned.enabled':False})
    assert c.active_fence_folders()==[folder]
    try:c.update_fence_settings(c.DESKTOP,{'title':'Disabled'})
    except ValueError:pass
    else:raise AssertionError('disabled Unassigned could be edited')
    assert c.read_unassigned_enabled() is False
    old=c.GLOBAL_PATH.read_bytes()
    for value in [0,1,'true',None,{},[]]:
        try:c.update_general_settings({'unassigned.enabled':value})
        except ValueError:pass
        else:raise AssertionError('invalid toggle accepted: '+repr(value))
        assert c.GLOBAL_PATH.read_bytes()==old
print('OK: Unassigned opt-in toggle, atomic General settings, no file moves or root Fence configuration')
