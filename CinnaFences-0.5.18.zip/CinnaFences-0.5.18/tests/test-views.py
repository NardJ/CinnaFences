#!/usr/bin/env python3
"""v0.5.1: structural view and bar style updates must not affect file contents."""
import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cf051', root/'tools/cinnafences-config.py')
cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
with TemporaryDirectory(prefix='cf-views-') as t:
    desktop=Path(t)/'Desktop'; folder=desktop/'3D';folder.mkdir(parents=True)
    slicers=folder/'Slicers';slicers.mkdir()
    original=slicers/'CR.desktop';original.write_text('desktop fixture',encoding='utf8')
    cli.DESKTOP=desktop
    cli.create(folder,100,120)
    target=folder/'.cinnafence.json'
    before=json.loads(target.read_text())
    before['icons']['positions']={'existing.desktop':[2,7]}
    target.write_text(json.dumps(before))
    assert cli.update_fence_settings(folder,{
        'view.mode':'rolodex',
        'header.show':False, 'header.background':'#123abc',
        'header.opacity':0.34,'header.fontSize':16,'header.height':40,
        'header.showCollapseButton':False,
        'sections.background':'#456789','sections.opacity':0.65,
        'sections.textColor':'#fedcba','sections.fontSize':12,'sections.height':36
    })
    new=json.loads(target.read_text())
    assert new['view']['mode']=='rolodex' and new['view']['active']==''
    assert not new['header']['show']
    assert new['sections']['height']==36
    assert new['geometry']==before['geometry']
    assert new['icons']==before['icons']
    assert original.read_text()=='desktop fixture'
    state=target.read_bytes()
    for key,value in (
        ('view.mode','other'),('header.opacity',1.1),('header.show','false'),
        ('header.height',0),('header.textColor','rgb(0,0,0)'),
        ('sections.background','#123'),('sections.fontSize',100)):
        try: cli.update_fence_settings(folder,{key:value})
        except ValueError:pass
        else:raise AssertionError(f'invalid {key} was accepted')
        assert target.read_bytes()==state
print('OK: v0.5.1 mode/bar persistence, colors, bounds, positions and real files preserved')

with TemporaryDirectory(prefix='cf-views052-') as t:
    desktop=Path(t)/'Desktop';folder=desktop/'3D';folder.mkdir(parents=True)
    cli.DESKTOP=desktop
    cli.create(folder,80,100)
    before=(folder/'.cinnafence.json').read_bytes()
    changed={
      'view.tabsInHeader':True,'header.hoverBackground':'#123456',
      'header.hoverOpacity':.33,'header.hoverTextColor':'#aabbcc',
      'header.fontFamily':'DejaVu Sans',
      'sections.hoverBackground':'#654321','sections.hoverOpacity':.88,
      'sections.hoverTextColor':'#112233','sections.fontFamily':'Liberation Sans',
      'sections.alignment':'right','sections.showCollapseButton':False}
    cli.update_fence_settings(folder,changed)
    updated=cli.read_fence_settings(folder)
    assert updated['view']['tabsInHeader'] is True
    assert updated['header']['hoverOpacity']==.33
    assert updated['sections']['alignment']=='right'
    assert updated['sections']['showCollapseButton'] is False
    original=(folder/'.cinnafence.json').read_bytes()
    for field,value in [('sections.alignment','between'),
       ('sections.showCollapseButton','no'),('view.tabsInHeader',1),
       ('header.hoverOpacity',-1),('header.fontFamily',''),('sections.fontFamily','<script>')]:
        try:cli.update_fence_settings(folder,{field:value})
        except ValueError:pass
        else:raise AssertionError(f'invalid {field} accepted')
        assert (folder/'.cinnafence.json').read_bytes()==original
    assert before!=original
print('OK: v0.5.2 configuration validates new styling, position and button fields atomically')

with TemporaryDirectory(prefix='cf-views053-') as t:
    desktop=Path(t)/'Desktop'; folder=desktop/'3D'; folder.mkdir(parents=True)
    cli.DESKTOP=desktop;cli.create(folder,100,120)
    target=folder/'.cinnafence.json'
    original=target.read_bytes()
    cli.update_fence_settings(folder,{'view.mode':'rolodex','view.autoFitHeight':True,
                                      'view.autoFitMaxHeight':610})
    cfg=cli.read_fence_settings(folder)
    assert cfg['view']['autoFitHeight'] is True
    assert cfg['view']['autoFitMaxHeight']==610
    assert cfg['geometry']['height']==270
    saved=target.read_bytes()
    for k,v in [('view.autoFitHeight',1),('view.autoFitHeight','yes'),
                ('view.autoFitMaxHeight',30),('view.autoFitMaxHeight',2000),
                ('view.autoFitMaxHeight',321.1)]:
        try:cli.update_fence_settings(folder,{k:v})
        except ValueError:pass
        else:raise AssertionError(f'invalid {k} allowed')
        assert target.read_bytes()==saved
    assert original!=saved
print('OK: v0.5.3 auto-fit config bounds and manual geometry preserved')
