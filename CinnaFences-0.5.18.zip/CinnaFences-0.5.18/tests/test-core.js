// Exercise pure logic from the actual extension without needing a Cinnamon session.
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const src=fs.readFileSync(path.join(__dirname,'../cinnafences@local/extension.js'),'utf8');
class MockActor {
  constructor(params={}) {this.handlers=new Map();this.next=1;this.destroyed=false;this.params=params;this.width=params.width||0;this.height=params.height||0;}
  set_position(x,y){this.x=x;this.y=y;}
  set_size(w,h){this.width=w;this.height=h;}
  raise_top(){this.raised=true;}
  connect(name,fn){const id=this.next++;this.handlers.set(id,{name,fn});return id;}
  disconnect(id){this.handlers.delete(id);}
  destroy(){this.destroyed=true;}
}
let modalPush=0, modalPop=0, activeModal=null, grabs=0, ungrabs=0;
const timers = new Map(); let nextTimer = 90;
const addTimer = fn => { const id=++nextTimer; timers.set(id,fn); return id; };
const testState={grabs:0,ungrabs:0,activeModal:null};
const testDeviceMock={grab:actor=>{testState.grabs++; if(actor!==testState.activeModal)throw Error('wrong grab actor');},ungrab:()=>testState.ungrabs++};
let trackedFence=null, untrackedFence=null;
const shortcuts=new Map();
const testShortcut={reg:0,rem:0};
const mainMock={
  keybindingManager:{addHotKey:(name,binding,fn)=>{testShortcut.reg++;if(binding==='<Super>x')return false;shortcuts.set(name,{binding,fn});return true;},
                     removeHotKey:(name)=>{testShortcut.rem++;shortcuts.delete(name)}},
  notify:()=>{},
  layoutManager:{
    trackChrome:(actor, opts)=>{trackedFence={actor, opts}},
    untrackChrome:actor=>{untrackedFence=actor;}
  },
  uiGroup:{add_actor:actor=>{actor.attached=true;}},
  pushModal:(actor)=>{modalPush++;activeModal=actor;testState.activeModal=actor;return true;},
  popModal:actor=>{assert.equal(actor,activeModal);modalPop++;activeModal=null;testState.activeModal=null;}
};
const mockClutter={Actor:MockActor,Clone:MockActor,ModifierType:{BUTTON1_MASK:256},PickMode:{REACTIVE:2},EventType:{MOTION:7,BUTTON_RELEASE:8,KEY_PRESS:9,BUTTON_PRESS:10},
  EVENT_STOP:true,EVENT_PROPAGATE:false};
const ctx=vm.createContext({
  imports:{gi:{St:{},Clutter:mockClutter,Cinnamon:{ActionMode:{NORMAL:1}},Gio:{},
    GLib:{build_filenamev:parts=>parts.join('/'),get_user_config_dir:()=>'/tmp/cinnafences-graphics-tests',path_get_basename:p=>path.basename(p),PRIORITY_DEFAULT:0,PRIORITY_DEFAULT_IDLE:200,SOURCE_REMOVE:false,SOURCE_CONTINUE:true,
      timeout_add_seconds:(priority,sec,fn)=>addTimer(fn), timeout_add:(priority,ms,fn)=>addTimer(fn),
      idle_add:(priority,fn)=>addTimer(fn),get_monotonic_time:()=>1000000,source_remove:id=>timers.delete(id)},Pango:{},Meta:{WindowType:{DESKTOP:100}}},
           byteArray:{},ui:{main:mainMock,popupMenu:{}}},
  global:{logError:()=>{},sync_pointer:()=>{},log:()=>{},
    get_pointer:()=>[200,230,256],stage:{get_actor_at_pos:()=>null}},
  testState, testDeviceMock,testTimers:timers,testShortcut,
});
vm.runInContext(src,ctx,{filename:'extension.js'});
const call=source=>vm.runInContext(source,ctx);
assert.equal(call('columns(350, 86)'),3);
assert.equal(call('columns(140, 86)'),1);
assert.equal(call('columns(520, 86)'),5);
const c=call(`normalizeConfig({version:1, appearance:{iconOpacity:0.45}, icons:{size:48}}, '/home/nard/Desktop/Internet')`);
assert.equal(c.title,'Internet');
assert.equal(c.icons.gridWidth,86);
assert.equal(c.appearance.iconOpacity,0.45);
assert.equal(c.enabled,true);
assert.equal(call(`normalizeConfig({enabled:false},'/home/nard/Desktop/A').enabled`),false);
assert.equal(call(`normalizeConfig({nofence:true},'/home/nard/Desktop/A').enabled`),false);
// General style: never override legacy Fences, geometry or icon positions.
const inherit = call(`normalizeConfig({inheritGlobals:true,geometry:{x:111,width:460},
   appearance:{background:'#112233'}, icons:{positions:{'file.desktop':[3,2]},size:48}},
   '/home/nard/Desktop/Games',
   {appearance:{background:'#aabbcc',labelColor:'#eeddcc'},
    icons:{size:64,labelFont:'DejaVu Sans',labelFontSize:11,gridWidth:100}})`);
assert.equal(inherit.appearance.background,'#aabbcc');
assert.equal(inherit.appearance.labelColor,'#eeddcc');
assert.equal(inherit.icons.size,64);
assert.equal(inherit.icons.labelFont,'DejaVu Sans');
assert.equal(inherit.icons.labelFontSize,11);
assert.equal(inherit.geometry.x,111);
assert.equal(inherit.geometry.width,460);
assert.equal(inherit.icons.positions['file.desktop'][0],3);
const legacy = call(`normalizeConfig({appearance:{background:'#112233'}},
   '/home/nard/Desktop/Games',{appearance:{background:'#aabbcc'}})`);
assert.equal(legacy.appearance.background,'#112233');
assert.equal(legacy.inheritGlobals,false);
console.log('OK: global defaults opt-in, existing Fences stable, geometry and icon positions retained');

// Header/Sections inheritance must never silently affect old Fences nor
// change an existing view mode/active section. Scoped flag is explicit.
const advancedDefaults=`{view:{mode:'tabs',tabsInHeader:true,autoFitHeight:true,autoFitMaxHeight:550},
    header:{background:'#123456',show:false},
    sections:{alignment:'right',background:'#aabbcc'}}`;
const oldStyle=call(`normalizeConfig({inheritGlobals:true,view:{mode:'rolodex',active:'CAD'},
    header:{background:'#fedcba'},sections:{alignment:'left'}},'/home/nard/Desktop/3D',${advancedDefaults})`);
assert.equal(oldStyle.view.mode,'rolodex');assert.equal(oldStyle.view.active,'CAD');
assert.equal(oldStyle.view.tabsInHeader,false);assert.equal(oldStyle.header.background,'#fedcba');
assert.equal(oldStyle.sections.alignment,'left');assert.equal(oldStyle.inheritAdvancedGlobals,false);
const advancedStyle=call(`normalizeConfig({inheritGlobals:true,inheritAdvancedGlobals:true,
    view:{mode:'rolodex',active:'CAD',tabsInHeader:false},
    header:{background:'#fedcba'},sections:{alignment:'left'}},
    '/home/nard/Desktop/3D',${advancedDefaults})`);
assert.equal(advancedStyle.view.mode,'rolodex');assert.equal(advancedStyle.view.active,'CAD');
assert.equal(advancedStyle.view.tabsInHeader,true);assert.equal(advancedStyle.view.autoFitMaxHeight,550);
assert.equal(advancedStyle.header.background,'#123456');assert.equal(advancedStyle.header.show,false);
assert.equal(advancedStyle.sections.alignment,'right');
console.log('OK: 0.5.14 opt-in header/section inheritance preserves legacy style, active Rolodex and local mode');
assert.equal(call(`normalizeConfig({geometry:{width:10,height:2}},'/home/nard/Desktop/A').geometry.width`),172);
assert.equal(call(`normalizeConfig({icons:{size:96,gridWidth:48,gridHeight:52}},'/home/nard/Desktop/A').icons.gridWidth`),104);
assert.throws(()=>call(`normalizeConfig({version:2},'/home/nard/Desktop/A')`));
const order=call(`canonicalOrder(['c.desktop','a.desktop','b.desktop'],
  {'a.desktop':[2,0],'b.desktop':[0,2],'c.desktop':[0,0]},3).map(x=>x.name).join(',')`);
assert.equal(order,'c.desktop,a.desktop,b.desktop');
const newOne=call(`canonicalOrder(['a','b','c'],{'a':[0,0],'b':[2,0]},3).map(x=>[x.name,x.col,x.row].join(':')).join(',')`);
assert.equal(newOne,'a:0:0,c:1:0,b:2:0');
console.log('OK: 11 core/raster/config-validaties');
// v0.1.1 regressions: cursor enum names, scroll bounds and pointer-grab lifetime.
assert.equal(call('CURSOR_FOR_EDGE.n'),'RESIZE_TOP');
assert.equal(call('CURSOR_FOR_EDGE.se'),'RESIZE_BOTTOM_RIGHT');
assert.equal(call('maxScrollPixels(5,218,88)'),310);
assert.equal(call('maxScrollPixels(1,218,88)'),0);
assert.equal(call('maxScrollPixels(-1,218,88)'),0);
assert.equal(call('columns(280,86)'),2); // scrollbar's reserved width
const pointerTest=call(`(() => {
    const device=testDeviceMock;
    const fake=Object.create(Fence.prototype);
    fake.config={geometry:{x:100,y:120,width:350,height:270}};
    fake.actor={connect:()=>{throw Error('No grab on movable Fence!')}};
    fake._style=()=>{};
    fake._setCursor=x=>fake.cursor=x;
    fake._clearCursor=()=>fake.cursor=null;
    fake._drag=null;fake._dragEventId=0;fake._dragDevice=null;
    fake._setPointerMode('move',{get_coords:()=>[200,230],get_device:()=>device,get_time:()=>42},null);
    const modal=fake._modalActor;
    const running=!!fake._drag && fake.cursor==='MOVE' &&
      testState.grabs===1 && modal.attached && modal===testState.activeModal && !!fake._dragEventId;
    fake._endPointer();
    return running && testState.ungrabs===1 && modal.destroyed && !fake._drag && !fake.cursor && !testState.activeModal;
})()`);
assert.equal(pointerTest,true);
assert.equal(modalPush,1);assert.equal(modalPop,1);
const borderTest=call(`(() => {
    const fake=Object.create(Fence.prototype);
    fake._drag=null; fake.config={collapsed:false};
    fake._edgeName=()=>"se";
    fake._setPointerMode=(mode)=>{fake.started=mode};
    fake._clearItemStates=()=>{};
    return fake._boundaryCapture({type:()=>Clutter.EventType.BUTTON_PRESS,get_button:()=>1})===Clutter.EVENT_STOP
        && fake.started==='resize:se';
})()`);
assert.equal(borderTest,true);
console.log('OK: v0.1.2 stabiele modal grab, cleanup en randprioriteit');
const selectTest=call(`(() => {
    const fake=Object.create(Fence.prototype);
    const a={actor:{set_style:s=>a.style=s}},b={actor:{set_style:s=>b.style=s}};
    fake.items=[a,b];
    fake._selectItem(a);
    const one=a.selected && !b.selected;
    fake._selectItem(b);
    const two=!a.selected && b.selected;
    fake._clearItemStates();
    return one && two && !a.selected && !b.selected && !fake.selectedItem;
})()`);
assert.equal(selectTest,true);
console.log('OK: v0.1.1 cursor/scroll/grab/select-regressies');
const moveTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    const geo={x:80,y:100,width:350,height:270};
    f.config={geometry:geo};
    let final;
    f.actor={set_position:(x,y)=>final=[x,y]};
    f._workAreaForPointer=()=>({x:0,y:32,width:1920,height:1048});
    f._drag={mode:'move',sx:200,sy:200,x:80,y:100,width:350,height:270,moved:false};
    f._endPointer=()=>{f._drag=null};
    const ev={type:()=>7,get_coords:()=>[200,0]};
    const ClutterBefore=Clutter.EventType;
    Clutter.EventType={MOTION:7,BUTTON_RELEASE:8,KEY_PRESS:9};
    Clutter.EVENT_STOP=true;
    const stopped=f._stageEvent(ev);
    return stopped && final[1]===32 && geo.y===32;
})()`);
assert.equal(moveTest,true);
console.log('OK: bovenste panelrand blijft bereikbaar bij slepen');

// v0.1.3: a lost button-release can no longer hold a modal for 30 seconds.
const watchdogTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f._drag=null; f._dragEventId=0;f._dragDevice=null;f._dragWatchId=0;
    f._dragSafetyTimer=0;f._modalActive=false;f._modalActor=null;f._disposed=false;
    f.config={geometry:{x:100,y:120,width:350,height:270}};
    f.actor={};f._style=()=>{};f._setCursor=()=>{};f._clearCursor=()=>{};
    f._setPointerMode('move',{get_coords:()=>[200,230],get_device:()=>testDeviceMock,get_time:()=>42},null);
    const timerId=f._dragWatchId;
    return [timerId,!!f._drag];
})()`);
assert(watchdogTest[0]>0 && watchdogTest[1]);
const fn=timers.get(watchdogTest[0]);
assert.equal(typeof fn,'function');
// global.get_pointer now says button 1 is released: require two consecutive checks.
ctx.global.get_pointer=()=>[200,230,0];
assert.equal(fn(),true);
assert.equal(fn(),false);
assert.equal(testState.activeModal,null);
assert.equal(testState.grabs,testState.ungrabs);
console.log('OK: v0.1.3 verloren button-release automatisch hersteld');
const hoverTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f.actor={visible:true,width:350,height:270,get_transformed_position:()=>[100,120]};
    f._disposed=false;f._drag=null;f.hovered=false;f.items=[];f.config={appearance:{hoverEnabled:true}};
    f._style=x=>f.currentOpacity=x;
    f._clearCursor=()=>{};f._clearItemStates=()=>{};
    f._syncHoverFromPointer(130,150, 'drag-end');
    const active=f.hovered&&f.currentOpacity;
    f._syncHoverFromPointer(10,10, 'drag-end');
    return active&&!f.hovered&&!f.currentOpacity;
})()`);
assert.equal(hoverTest,true);
console.log('OK: hover na modal grab vanuit coördinaten hersteld');

// v0.1.4: partial bottom rows are painted, with pixel-exact scrolling.
assert.equal(call('maxScrollPixels(2,190,88)'),74);
assert.equal(call('gridRowAtPointer(280,80,50,88)'),2); // header+padding+scroll
const partialRowTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f.config={collapsed:false,icons:{gridWidth:86,gridHeight:88}};
    f.content={height:190};f.scrollTrack={height:190,width:10,visible:false};
    f.scrollThumb={set_position:()=>{},set_size:()=>{}};
    f.items=[0,1,2].map(row=>({row,col:0,actor:{visible:false,set_position(x,y){this.x=x;this.y=y}}}));
    f.scroll=0;
    f._placeItems();
    const partial=f.items[2].actor.visible&&f.items[2].actor.y===176&&f._maxScroll===74&&f.scrollTrack.visible;
    f.scroll=74;f._placeItems();
    return partial&&f.items[2].actor.visible&&f.items[2].actor.y===102&&f.scroll===74;
})()`);
assert.equal(partialRowTest,true);
console.log('OK: v0.1.4 gedeeltelijk zichtbare onderste rij en volledige pixel-scroll');
const previewTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    const actor={width:86,height:88,opacity:255,get_transformed_position:()=>[120,130]};
    const item={actor};
    const d={item,sx:140,sy:150,preview:null};
    f._startItemPreview(d,210,220);
    if (!d.preview) return false;
    const move=d.preview.x===190&&d.preview.y===200&&d.preview.raised&&d.preview.params.source===actor;
    f._moveItemPreview(d,260,280);
    const follow=d.preview.x===240&&d.preview.y===260;
    f._drag=d;f._dragEventId=0;f._modalActive=false;f._modalActor=null;
    f._dragDevice=null;f._dragWatchId=0;f._dragSafetyTimer=0;f._disposed=true;
    f._clearCursor=()=>{};
    const preview=d.preview;
    f._endPointer();
    return move&&follow&&preview.destroyed&&!f._drag;
})()`);
assert.equal(previewTest,true);
console.log('OK: v0.1.4 icoonvoorbeeld volgt cursor, ruimt op bij loslaten');

// v0.1.6: hover must depend ONLY on pointer coordinates, not event target.
const stableHoverTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f.actor={visible:true,width:300,height:200,get_transformed_position:()=>[100,100]};
    f.config={appearance:{hoverEnabled:true}, debugHover:false};
    f.folder='/home/nard/Desktop/3D';
    f._disposed=false;f._drag=null;f.hovered=false;
    let calls=0,clears=0;
    f._style=x=>{f.current=x;calls++};
    f._clearCursor=()=>{};f._clearItemStates=()=>{clears++};
    // The stage reports a different actor even with the pointer inside;
    // source/pick must be irrelevant, including when crossing child actors.
    global.stage.get_actor_at_pos=()=>({get_parent:()=>null});
    f._syncHoverFromPointer(130,150,'stage');
    const entered=f.hovered&&f.current&&calls===1;
    f._syncHoverFromPointer(240,170,'crossing');
    f._syncHoverFromPointer(200,120,'stage');
    const noFlicker=f.hovered&&f.current&&calls===1;
    f._syncHoverFromPointer(99,170,'stage');
    const left=!f.hovered&&!f.current&&calls===2&&clears===1;
    f._syncHoverFromPointer(120,140,'crossing');
    const reentered=f.hovered&&f.current&&calls===3;
    f._drag={mode:'move'};
    f._syncHoverFromPointer(10,10,'stage');
    const dragFrozen=f.hovered&&calls===3;
    f._drag=null;
    f._syncHoverFromPointer(10,10,'drag-end');
    return entered&&noFlicker&&left&&reentered&&dragFrozen&&!f.hovered&&calls===4;
})()`);
assert.equal(stableHoverTest,true);
const hoverFallbackTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f.actor={visible:true,width:350,height:270,get_transformed_position:()=>[100,100]};
    f.config={appearance:{hoverEnabled:false},debugHover:false};
    f._disposed=false;f._drag=null;f.hovered=false;
    f._style=x=>{f.current=x};
    f._clearCursor=()=>{};f._clearItemStates=()=>{};
    f._syncHoverFromPointer(150,150,'test');
    const inside=f.hovered&&f.current;
    f._syncHoverFromPointer(5,5,'test');
    return inside&&!f.hovered&&f.current;
})()`);
assert.equal(hoverFallbackTest,true);
assert.equal(call(`normalizeConfig({appearance:{hoverEnabled:false}}, '/home/nard/Desktop/3D').appearance.hoverEnabled`), false);
assert.equal(call(`normalizeConfig({}, '/home/nard/Desktop/3D').appearance.hoverEnabled`), true);
console.log('OK: v0.1.6 geometrische hover, child-overgangen en optionele fallback');

// v0.3.0.1: X11 input tracking ONLY on uncovered Fence fragments.
const regionActor={destroy:()=>{}};
ctx.regionActor=regionActor;
call('registerFenceInput(regionActor)');
assert.equal(trackedFence.actor, regionActor);
assert.equal(trackedFence.opts.affectsInputRegion,true);
assert.equal(trackedFence.opts.affectsStruts,false);
call('unregisterFenceInput(regionActor)');
assert.equal(untrackedFence,regionActor);
// The constructor must attach to the desklet container, not uiGroup, so that
// normal windows continue to cover the Fence. Destroy must always untrack.
assert(src.includes('global.desklet_container.add_child(this.actor)'));
assert(src.includes('registerFenceInput(child)'));
assert(src.includes('this._clearInputPieces()'));
assert(!src.includes('registerFenceInput(this.actor)')); // no full-rectangle input
const disposeRegionTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f._disposed=false; f._inputPieces=[regionActor]; f._inputRegionKey='old'; f._hoverRecoveryId=0;
    f._allocationChangedId=0;
    f._drag=null; f._dragEventId=0;f._dragDevice=null;f._dragWatchId=0;
    f._dragSafetyTimer=0;f._modalActive=false;f._modalActor=null;
    f._clearCursor=()=>{};
    f.menu=null;
    f.actor=regionActor;
    f.actor.destroy=()=>{f.actorDestroyed=true};
    f.destroy();
    return f._disposed && !f._inputPieces.length && f.actor===null && f.actorDestroyed;
})()`);
assert.equal(disposeRegionTest,true);
assert.equal(untrackedFence,regionActor);
console.log('OK: desklet actor met aparte input-fragmenten en veilig opruimen');

const resizeHoverTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f.config={collapsed:false};f._drag=null;
    let cursor=null;
    f._setCursor=name=>{cursor=name};
    f.actor={width:350,height:270,get_transformed_position:()=>[100,120]};
    const motion=(x,y)=>({type:()=>Clutter.EventType.MOTION,get_coords:()=>[x,y]});
    f._boundaryCapture(motion(448,220));
    const right=cursor==='RESIZE_RIGHT';
    f._boundaryCapture(motion(220,388));
    const bottom=cursor==='RESIZE_BOTTOM';
    f._boundaryCapture(motion(448,388));
    const corner=cursor==='RESIZE_BOTTOM_RIGHT';
    f._boundaryCapture(motion(220,220));
    return right&&bottom&&corner&&cursor===null;
})()`);
assert.equal(resizeHoverTest,true);
console.log('OK: v0.1.7 resize-cursors voor rechts, onder en hoek zonder muisklik');

// v0.2.0: Nemo mode reads stored opt-in state; never alters unrelated layouts.
const fakeGio=ctx.imports.gi.Gio;
const fakeGLib=ctx.imports.gi.GLib;
const fakeByteArray=ctx.imports.byteArray;
let nemoState=JSON.stringify({enabled:true,originalLayout:'true::false',version:1});
let currentNemo='true::false';
let writes=[];
fakeGLib.get_user_config_dir=()=>'/home/nard/.config';
fakeGLib.build_filenamev=parts=>parts.join('/');
fakeGLib.file_test=()=>true;
fakeGLib.FileTest={EXISTS:1};
fakeGio.File={new_for_path:path=>({load_contents:()=>[true,nemoState]})};
fakeByteArray.toString=value=>value;
fakeGio.Settings=class {
  get_string(key){assert.equal(key,'desktop-layout');return currentNemo;}
  set_string(key,value){writes.push([key,value]);currentNemo=value;return true;}
};
call('syncNemoDesktopMode(true)');
assert.equal(currentNemo,'false::false');
call('syncNemoDesktopMode(true)');
assert.equal(writes.length,1); // repeated enable doesn't overwrite original
call('syncNemoDesktopMode(false)');
assert.equal(currentNemo,'true::false');
assert.equal(writes.length,2);
// Respect manual change by user; no blind restoration.
currentNemo='custom::layout';
call('syncNemoDesktopMode(false)');
assert.equal(currentNemo,'custom::layout');
assert.equal(writes.length,2);
nemoState=JSON.stringify({enabled:false,originalLayout:'true::false'});
currentNemo='true::false';
call('syncNemoDesktopMode(true)');
assert.equal(writes.length,2);
console.log('OK: v0.2.0 opt-in desktopmodus, herhaalde enable, veilige restore');

// v0.2.2: Cinnamon 6.6 expects (sourceActor, orientation) and must anchor
// the popup beside the actual click, not at an unmapped header's [0, 0].
const menuActors=[];
ctx.imports.gi.St.Side={LEFT:19, TOP:18};
ctx.imports.gi.St.Widget=class {
  constructor(props){this.props=props; this.destroyed=false;}
  set_position(x,y){this.x=x;this.y=y;}
  destroy(){this.destroyed=true;}
};
ctx.imports.ui.popupMenu.PopupMenu=class {
  constructor(sourceActor,orientation){
    assert.equal(arguments.length,2);
    assert.equal(orientation,ctx.imports.gi.St.Side.LEFT);
    assert.equal(sourceActor.props.reactive,false);
    this.sourceActor=sourceActor;
    this.actor={hide:()=>{}};
    this.isOpen=false;
    menuActors.push(this);
  }
  addAction(text,callback){
    const item={label:{text,set_text(next){this.text=next}},callback,actor:{visible:true},
      sensitive:true,setSensitive(next){this.sensitive=next},setShowDot(next){this.dot=next}};
    (this.actions ??= []).push(item);
    return item;
  }
  addMenuItem(){}
  open(animate){assert.equal(animate,false); this.isOpen=true;}
  close(animate){assert.equal(animate,false); this.isOpen=false;}
  destroy(){this.destroyed=true;}
};
ctx.imports.ui.popupMenu.PopupMenuManager=class {addMenu() {}};
ctx.imports.ui.popupMenu.PopupSeparatorMenuItem=class {};
ctx.imports.ui.popupMenu.PopupSubMenuMenuItem=class {
  constructor(text){this.label={text};this.menu={actions:[],addAction(text,callback){
    const item={label:{text},callback,setShowDot(next){this.dot=next}};
    this.actions.push(item);return item;
  }};}
};
ctx.imports.ui.main.uiGroup.add_child=actor=>{actor.attached=true;};
const clickMenuTest=call(`(() => {
   const f=Object.create(Fence.prototype);
   f.config={icons:{undoArrangement:null},geometryLocked:false,collapsed:false,view:{mode:'icons'}};
   f.manager={lastTransfer:null};
   f.items=[];
   f._createMenu();
   if(f.menu.actions.length!==16) return false;
   if(f.menu.actions[5].label.text!=='Undo Arrangement') return false;
   if(f._trashItemMenuItem.label.text!=='Move to Trash') return false;
   if(f._viewModeItems.icons.dot!==undefined) return false;
   const a=f._menuAnchor;
   if (!a.attached || f.menu.sourceActor!==a) return false;
   f.openMenu({get_coords:()=>[1543.3,784.7]});
   const first=f.menu.isOpen && a.x===1543 && a.y===785 &&
      f._undoMenuItem.sensitive===false &&
      f._lockMenuItem.label.text==='Lock Position and Size' &&
      f._trashItemMenuItem.actor.visible===false &&
      f._viewModeItems.icons.dot===true &&
      f._fileUndoMenuItem.label.text==='Undo File Transfer';
   f.openMenu({get_coords:()=>[1543,785]});
   const closed=!f.menu.isOpen;
   f.openMenu({get_coords:()=>[2218,1134]});
   const second=f.menu.isOpen && a.x===2218 && a.y===1134;
   f._disposed=false; f._inputPieces=[]; f._inputRegionKey=''; f._hoverRecoveryId=0;
   f._drag=null; f._dragEventId=0; f._dragDevice=null; f._dragWatchId=0;
   f._dragSafetyTimer=0; f._modalActive=false; f._modalActor=null;
   f._clearCursor=()=>{};
   f.actor={destroy:()=>{}};
   const menu=f.menu;
   f.destroy();
   return first && closed && second && menu.destroyed && a.destroyed && !f._menuAnchor;
})()`);
assert.equal(clickMenuTest,true);
const rightClickSources=src.match(/this\.openMenu\(e\)/g) || [];
assert.equal(rightClickSources.length,0, 'never open a popup during right-button press');
assert.equal((src.match(/this\._contextDown\(e\)/g)||[]).length,3);
assert.equal((src.match(/this\._contextDown\(e,true\)/g)||[]).length,1);
ctx.releaseEvents=[];
const releaseTest=call(`(() => {
  const f=Object.create(Fence.prototype);
  f._disposed=false;f._drag=null;f._contextPending=null;f._contextOpenIdle=0;
  const seen=releaseEvents;f.openMenu=(e,onItem)=>seen.push([e.get_coords(),onItem]);
  const down={get_coords:()=>[200,300]};
  f._contextDown(down,true);
  if(seen.length!==0 || !f._contextPending.itemContext)return false;
  const up={type:()=>Clutter.EventType.BUTTON_RELEASE,get_button:()=>3,get_coords:()=>[201,301]};
  if(f._contextCapture(up)!==Clutter.EVENT_STOP || seen.length!==0)return false;
  f._contextCapture(up); // never schedule duplicate after pending consumed
  return f._contextOpenIdle>0;
})()`);
assert.equal(releaseTest,true);
assert(timers.has(nextTimer), 'context-menu open scheduled after button release');
timers.get(nextTimer)();timers.delete(nextTimer);
assert.equal(ctx.releaseEvents.length,1);
assert.equal(ctx.releaseEvents[0][1],true);
assert.equal(ctx.releaseEvents[0][0][0],201);
assert.equal(ctx.releaseEvents[0][0][1],301);
console.log('OK: v0.2.2 contextmenu op klikpositie, Cinnamon 6.6 API en opruimen');
// v0.2.3 per-Fence UI: geometry lock, title refresh, label display.
const defaults023=call(`normalizeConfig({version:1}, '/home/nard/Desktop/Games')`);
assert.equal(defaults023.geometryLocked,false);
assert.equal(defaults023.icons.showLabels,true);
const locked023=call(`normalizeConfig({version:1,geometryLocked:true,icons:{showLabels:false}}, '/home/nard/Desktop/Games')`);
assert.equal(locked023.geometryLocked,true);
assert.equal(locked023.icons.showLabels,false);
assert.equal(call(`(() => {
   const f=Object.create(Fence.prototype);
   f.config={geometryLocked:true, collapsed:false};
   f.actor={width:350,height:270,get_transformed_position:()=>[100,120]};
   f._setPointerMode=()=>{throw Error('locked Fence moved!')};
   f._clearItemStates=()=>{};
   f.arrow={};f.arrowIcon={};
   const e={get_source:()=>null,get_button:()=>1,get_click_count:()=>1,get_coords:()=>[110,130]};
   const noEdge=f._edgeName(e)==='';
   const header=f._headerDown(e)===Clutter.EVENT_STOP;
   const boundary=f._boundaryCapture({...e,type:()=>Clutter.EventType.BUTTON_PRESS})===Clutter.EVENT_PROPAGATE;
   return noEdge&&header&&boundary;
})()`),true);
assert.equal(call(`(() => {
    const f=Object.create(Fence.prototype);
    f._drag=null;
    f.config={title:'Old'};
    let title, pos, refreshed=0;
    f.title={set_text:x=>{title=x}};
    f.actor={set_position:(x,y)=>{pos=[x,y]}};
    f.rebuild=()=>{refreshed++};
    f.updateConfig({title:'Mijn spellen',geometry:{x:20,y:30}});
    return title==='Mijn spellen' && pos[0]===20 && pos[1]===30 && refreshed===1;
})()`),true);
assert(src.includes('label.visible = this.config.icons.showLabels'));
console.log('OK: v0.2.3 per-Fence: vergrendelde geometrie, labelweergave en titelupdate');

// v0.2.4: runtime geometry save must not flatten inherited General styling.
// Fake Gio target returns on-disk local style values and records atomic output.
const persistence = call(`(() => {
    const folder='/tmp/cinnafences-test';
    const old={version:1,enabled:true,inheritGlobals:true,
        appearance:{background:'#112233',labelColor:'#ffccaa'},
        icons:{size:48,labelFont:'Sans',labelFontSize:9,positions:{a:[0,0]}},
        geometry:{x:1,y:2,width:350,height:270},collapsed:false,title:'Games'};
    const cfg=normalizeConfig(old,folder,{appearance:{background:'#abcdef'},icons:{size:70}});
    cfg.geometry.x=470; cfg.icons.positions={a:[1,2]}; cfg.collapsed=true;
    Gio.FileCopyFlags={OVERWRITE:1};
    Gio.File={new_for_path:path=>({
        load_contents:()=>[true,JSON.stringify(old)],get_path:()=>path,
        move:()=>{old.moved=true},delete:()=>{}
    })};
    GLib.uuid_string_random=()=> 'testuuid';
    GLib.file_set_contents=(path,text)=>{old.saved=JSON.parse(text)};
    writeConfig(folder,cfg);
    return old.saved;
})()`);
assert.equal(persistence.appearance.background,'#112233');
assert.equal(persistence.appearance.labelColor,'#ffccaa');
assert.equal(persistence.icons.size,48);
assert.equal(persistence.icons.labelFont,'Sans');
assert.equal(persistence.geometry.x,470);
assert.equal(persistence.icons.positions.a[1],2);
assert.equal(persistence.collapsed,true);
console.log('OK: geometry and icon moves preserve local style while General defaults are enabled');

// v0.2.5: icon glyphs and their labels must share the grid-cell center.
// A full-width label with Pango.CENTER is NOT sufficient: single-line St.Label
// text is often left-aligned inside the actor. Also verify Pango receives
// the selected font description (including Bold/Italic) before sizing.
const st2=ctx.imports.gi.St;
const pango2=ctx.imports.gi.Pango;
class IconCell extends MockActor {
    constructor(params={}){ super(params); this.children=[]; }
    add_child(child){this.children.push(child);}
    set_style(style){this.style=style;}
}
class IconActor extends IconCell {
    constructor(params){super(params);this.params=params;}
}
class LabelActor extends IconCell {
    constructor(params){
        super(params);this.text=params.text;
        this.clutter_text={
            set_ellipsize:()=>{}, set_line_alignment:()=>{},
            set_font_description:desc=>{this.description=desc;}
        };
    }
    get_preferred_width(){
        assert.ok(this.description, 'measure AFTER installing selected font');
        const charWidth=this.description.get_family()==='DejaVu Sans'?11:7;
        return [0,this.text.length*charWidth];
    }
    set_width(width){this.width=width;}
}
st2.Widget=IconCell;st2.Icon=IconActor;st2.Label=LabelActor;
ctx.imports.gi.Clutter.FixedLayout=class {};
pango2.EllipsizeMode={END:2};pango2.Alignment={CENTER:1};pango2.Style={NORMAL:0,ITALIC:2};
pango2.FontDescription={from_string:raw=>{
    const match=raw.match(/^(.*)\s+(\d+)$/);
    assert.ok(match,raw);
    const face=match[1];
    return {
        raw,
        get_family:()=>face.replace(/\s+(Bold|Italic|Bold Italic)$/,'').trim(),
        get_weight:()=>face.includes('Bold')?700:400,
        get_style:()=>face.includes('Italic')?2:0,
    };
}};
const labelGridTest=call(`(() => {
    const f=Object.create(Fence.prototype);
    f._disposed=false;f._drag=null; f.items=[];
    f.config=normalizeConfig({version:1,icons:{size:48,gridWidth:100,gridHeight:88,
        labelFont:'DejaVu Sans Bold',labelFontSize:13}},'/home/nard/Desktop/Games');
    f._sizeActors=()=>{};f._readItems=()=>['One','Much-longer-than-one-grid-cell-label'];
    f._layoutItems=()=>{};f._style=()=>{};
    f.content={children:[],add_child:function(actor){this.children.push(actor);}};
    Gio.File={new_for_path:()=>({query_info:()=>({get_icon:()=>null,get_display_name:()=>null})})};
    f.rebuild();
    if(f.items.length!==2) return false;
    for(const it of f.items){
        if (Math.abs((it.label.x + it.label.width / 2) - 50) > .5) return false;
        if (Math.abs((it.icon.x + 24) - 50) > .5) return false;
        if (it.label.description.raw!=='DejaVu Sans Bold 13') return false;
        if (!it.label.style.includes("font-family:'DejaVu Sans'")) return false;
        if (!it.label.style.includes('font-weight:700')) return false;
    }
    return f.items[0].label.width < 96 && f.items[1].label.width===96;
})()`);
assert.equal(labelGridTest,true);
console.log('OK: v0.2.5 grid-centred short/long icon labels, Pango font families and bold styles');

// v0.2.7: Sort/Compact must preserve exactly ONE reversible arrangement.
// The undo snapshot is layout state, not a temporary UI-only value; it must
// round-trip through normalizeConfig and the existing atomic config writer.
const organizationTest=call(`(() => {
  const f=Object.create(Fence.prototype);
  f.folder='/home/nard/Desktop/Games';
  f.config=normalizeConfig({version:1,icons:{positions:{
    'A.desktop':[2,1],'B.desktop':[0,0],'C.desktop':[1,1]},layoutColumns:3}},f.folder);
  f._names=['A.desktop','B.desktop','C.desktop'];
  f.items=f._names.map(name=>({name,label:{text:name},col:0,row:0}));
  f._disposed=false;f._drag=null; f.scroll=11;
  f._save=(persistLock=false)=>{f.saved=JSON.parse(JSON.stringify(f.config));f.saves=(f.saves||0)+1;f.lastPersistLock=persistLock;};
  f._layoutItems=()=>{
    const result=canonicalOrder(f._names,f.config.icons.positions,f.config.icons.layoutColumns);
    for(const item of f.items){const entry=result.find(q=>q.name===item.name);item.col=entry.col;item.row=entry.row;}
  };
  f._layoutItems();
  const original=JSON.stringify(f.config.icons.positions);
  if(!f.sortAlphabetically()) return 'sort returned false';
  if(f.items[0].col!==0 || f.items[0].row!==0) return 'sort not ordered';
  if(JSON.stringify(f.config.icons.undoArrangement.positions)!==original) return 'undo backup mismatch';
  const once=f.saves;
  if(f.sortAlphabetically()!==false || f.saves!==once) return 'repeated sort must be no-op';
  const persisted=normalizeConfig(f.saved,f.folder);
  if(JSON.stringify(persisted.icons.undoArrangement.positions)!==original) return 'undo does not survive reload';
  f.config=persisted;
  if(!f.restoreArrangement()) return 'restore failed';
  if(JSON.stringify(f.config.icons.positions)!==original) return 'positions not restored';
  if(f.config.icons.undoArrangement!==null || f.restoreArrangement()!==false) return 'undo not consumed';
  // Compaction retains current visual order and closes gaps; it should not
  // alphabetize existing manually positioned icons.
  f.config.icons.positions={'A.desktop':[2,3],'B.desktop':[0,0],'C.desktop':[1,2]};
  f._layoutItems();
  if(!f.compactIcons()) return 'compact returned false';
  const p=f.config.icons.positions;
  if(JSON.stringify(p['B.desktop'])!=='[0,0]' || JSON.stringify(p['C.desktop'])!=='[1,0]' ||
     JSON.stringify(p['A.desktop'])!=='[2,0]') return 'compact order changed';
  if(!f.restoreArrangement()) return 'compact undo failed';
  if(f.config.icons.positions['A.desktop'][1]!==3) return 'compact undo mismatch';
  // geometry locks don't interfere with icon ordering or file access.
  f.config.geometryLocked=false;
  f.toggleGeometryLock();
  if(!f.config.geometryLocked || !f.lastPersistLock) return 'lock not enabled/persisted';
  f.toggleGeometryLock();
  if(f.config.geometryLocked) return 'lock not disabled';
  return true;
})()`);
assert.equal(organizationTest,true);
// Reject malformed undo payloads instead of letting them reach the renderer.
assert.equal(call(`normalizeConfig({icons:{undoArrangement:{positions:{a:[-1,0]},layoutColumns:2}}},'/tmp/A').icons.undoArrangement`),null);
console.log('OK: v0.2.7 sort, compact, persistent one-step restore, repeated sort, lock');

const organizationPersist=call(`(() => {
  const folder='/tmp/cinnafences-organization-test';
  const old={version:1,enabled:true,icons:{positions:{a:[2,1]},layoutColumns:3},
    geometry:{x:1,y:2,width:460,height:310},geometryLocked:false};
  const cfg=normalizeConfig(old,folder);
  cfg.icons.positions={a:[0,0]};
  cfg.icons.undoArrangement={positions:{a:[2,1]},layoutColumns:3};
  Gio.FileCopyFlags={OVERWRITE:1};
  Gio.File={new_for_path:path=>({load_contents:()=>[true,JSON.stringify(old)],
    get_path:()=>path,move:()=>{},delete:()=>{}})};
  GLib.uuid_string_random=()=> 'unittest';
  GLib.file_set_contents=(p,data)=>{old.saved=JSON.parse(data)};
  cfg.geometryLocked=true;
  writeConfig(folder,cfg);
  const kept=old.saved.geometryLocked===false;
  writeConfig(folder,cfg,true);
  return {kept,config:old.saved};
})()`);
assert.equal(organizationPersist.kept,true);
assert.equal(organizationPersist.config.geometryLocked,true);
assert.equal(organizationPersist.config.icons.undoArrangement.positions.a[0],2);
assert.equal(organizationPersist.config.icons.positions.a[0],0);
assert.equal(organizationPersist.config.geometry.width,460);
console.log('OK: v0.2.7 atomic save includes Undo without overwriting geometry');

// v0.3.0: cross-Fence drop moves the REAL item without overwriting. Ordinary
// in-Fence grid sorting still uses the unchanged existing path.
const crossFenceTest = call(`(() => {
  const files = new Set(['/home/nard/Desktop/Games/game.desktop']);
  const pathOf = file=>file.path;
  const actions = [];
  Gio.FileCopyFlags={NONE:0};
  Gio.FileQueryInfoFlags={NOFOLLOW_SYMLINKS:1};
  Gio.FileType={REGULAR:1,DIRECTORY:2,SYMBOLIC_LINK:3,UNKNOWN:0};
  Gio.File={new_for_path:p=>({path:p,query_exists:()=>files.has(p),
    query_file_type:()=>files.has(p)?Gio.FileType.REGULAR:0,
    move:(to,flags)=>{if(flags!==0||!files.has(p)||files.has(to.path))throw Error('unsafe move');
      files.delete(p);files.add(to.path);actions.push('moved');}})};
  Main.notify=(title, message)=>actions.push(message);
  const src=Object.create(Fence.prototype);
  src.folder='/home/nard/Desktop/Games';src._disposed=false;
  src.config=normalizeConfig({icons:{positions:{'game.desktop':[1,0]}}},src.folder);
  src.items=[{name:'game.desktop',col:1,row:0}];
  src._save=()=>actions.push('source-saved');
  const dst=Object.create(Fence.prototype);
  dst.folder='/home/nard/Desktop/Coding';dst._disposed=false;
  dst.config=normalizeConfig({icons:{positions:{'other.desktop':[0,0]}}},dst.folder);
  dst.items=[{name:'other.desktop',col:0,row:0}];
  dst.actor={get_transformed_position:()=>[900,100]};
  dst.scroll=0; dst._save=()=>actions.push('dest-saved');
  const manager={queueScan:p=>actions.push('scan:'+p)};
  src.manager=manager;dst.manager=manager;
  const success=src._transferItemToFence({destination:dst,names:['game.desktop'],copy:false,x:920,y:155});
  const target='/home/nard/Desktop/Coding/game.desktop';
  if (!success || files.has('/home/nard/Desktop/Games/game.desktop') || !files.has(target)) return 'move failed';
  if (src.config.icons.positions['game.desktop']) return 'source position retained';
  if (JSON.stringify(dst.config.icons.positions['game.desktop'])==='[0,0]') return 'overwrote occupied grid cell';
  if (!actions.includes('source-saved')||!actions.includes('dest-saved')) return 'not saved';
  if (!actions.some(a=>a==='scan:'+src.folder)||!actions.some(a=>a==='scan:'+dst.folder)) return 'not refreshed';
  files.add('/home/nard/Desktop/Games/game.desktop');
  const count=actions.filter(a=>a==='moved').length;
  const blocked=src._transferItemToFence({destination:dst,names:['game.desktop'],copy:false,x:920,y:155});
  if(blocked!==false || actions.filter(a=>a==='moved').length!==count || !files.has(target)) return 'name collision overwrote';
  return true;
})()`);
assert.equal(crossFenceTest,true);
const releaseToOther = call(`(() => {
  const f=Object.create(Fence.prototype);
  const dest={_disposed:false};
  f._disposed=false;
  f.manager={fenceAtPoint:(x,y,source)=>(x===640 && y===700 && source===f)?dest:null};
  f._drag={mode:'item',moved:true,item:{name:'foo'}};
  f._endPointer=()=>{f._drag=null;};
  f._transferItemToFence=t=>{f.received=t;};
  f._finishItemMoveAt=()=>{throw Error('grid move instead of drop')};
  f._finishPointerAt(640,700);
  return !!f._drag===false && !!f._pendingTransfer===false;
})()`);
assert.equal(releaseToOther,true);
const pendingIdle=[...timers.values()].pop();
assert.equal(typeof pendingIdle,'function');
assert.equal(pendingIdle(),false);
const pointTest=call(`(() => {
   const man=Object.create(FenceManager.prototype);
   const a={config:{collapsed:false},_disposed:false,actor:{width:200,height:180,
     get_transformed_position:()=>[100,100]},_pointerInside:(x,y)=>x>=100&&x<300&&y>=100&&y<280};
   const b={config:{collapsed:true},_disposed:false,actor:{width:200,height:180,
     get_transformed_position:()=>[500,100]},_pointerInside:(x,y)=>x>=500&&x<700&&y>=100&&y<280};
   man.fences=new Map([['a',a],['b',b]]);
   return man.fenceAtPoint(125,150)===a && man.fenceAtPoint(125,120)===null &&
      man.fenceAtPoint(510,150)===null && man.fenceAtPoint(125,150,a)===null;
})()`);
assert.equal(pointTest,true);
console.log('OK: v0.3.0 cross-Fence move, collision avoidance, deferred drop, target hit testing');

// v0.3.0.1: plain application windows must not lose any clicks to Fences
// beneath them. Fragment math mirrors upstream Cinnamon's subtractRects().
const overlapGeometry = call(`visibleFenceInputBoxes(
    {x:100,y:100,width:300,height:200},
    [{x:200,y:150,width:300,height:150}])`);
assert.equal(overlapGeometry.length,2);
assert.equal(overlapGeometry.map(r=>r.width*r.height).reduce((a,b)=>a+b,0), 30000);
assert.equal(call(`visibleFenceInputBoxes({x:0,y:0,width:100,height:100},
    [{x:0,y:0,width:100,height:100}]).length`),0);
assert.equal(call(`visibleFenceInputBoxes({x:0,y:0,width:100,height:100},
    [{x:200,y:200,width:100,height:100}]).length`),1);
const overlapRects=call(`visibleFenceInputBoxes(
    {x:10,y:20,width:350,height:270},
    [{x:35,y:55,width:100,height:100},{x:210,y:180,width:60,height:80}])`);
for (const b of overlapRects) {
    for (const o of [{x:35,y:55,width:100,height:100},{x:210,y:180,width:60,height:80}]) {
        assert(b.x+b.width<=o.x || o.x+o.width<=b.x ||
               b.y+b.height<=o.y || o.y+o.height<=b.y);
    }
}
console.log('OK: v0.3.0.1 application overlap clipped, no window clicks intercepted');

// 6.6.9: input fragments are tracked, never the entire rendered Fence root.
ctx.imports.gi.St.Widget = class extends MockActor {
    constructor(props={}) { super(props); }
};
const fencePieceTest=call(`(() => {
  const f=Object.create(Fence.prototype);
  f._disposed=false;f._inputPieces=[];f._inputRegionKey='';
  const actor={width:300,height:200,children:[],
    get_transformed_position:()=>[100,100],
    add_child(child){this.children.push(child)}};
  f.actor=actor;
  f.updateInputRegions([{x:200,y:150,width:300,height:150}]);
  const first=f._inputPieces.slice();
  if(first.length!==2 || !first.every(ch=>ch.params.reactive===false && !ch.destroyed)) return false;
  if(first[0].x!==0 || first[0].y!==0 || first[0].width!==300 || first[0].height!==50) return false;
  f.updateInputRegions([{x:200,y:150,width:300,height:150}]);
  if(f._inputPieces[0]!==first[0]) return false; // idempotent, no extra churn
  f.updateInputRegions([{x:100,y:100,width:300,height:200}]);
  if(f._inputPieces.length!==0 || !first.every(ch=>ch.destroyed)) return false;
  f.updateInputRegions([]);
  if(f._inputPieces.length!==1) return false;
  f._clearInputPieces();
  return f._inputPieces.length===0;
})()`);
assert.equal(fencePieceTest,true);
console.log('OK: X11 chrome input pieces updated/removed without tracking the Fence root');

const windowGeometryTest=call(`(() => {
 const manager=Object.create(FenceManager.prototype);
 manager.dead=false; manager._inputRegionIdle=0;
 const w1={get_window_type:()=>100, showing_on_its_workspace:()=>true,
   get_buffer_rect:()=>({x:0,y:0,width:1920,height:1080})};
 const w2={get_window_type:()=>3, showing_on_its_workspace:()=>false,
   get_buffer_rect:()=>({x:0,y:0,width:1920,height:1080})};
 const w3={get_window_type:()=>3, showing_on_its_workspace:()=>true,
   get_buffer_rect:()=>({x:180,y:220,width:400,height:300})};
 global.workspace_manager={get_active_workspace:()=>({list_windows:()=>[w1,w2,w3]})};
 const regions=[];
 manager.fences=new Map([['fence',{updateInputRegions:boxes=>regions.push(boxes),_clearInputPieces:()=>{}}]]);
 manager._windowInputBoxes();
 const filtered=manager._windowInputBoxes();
 if(filtered.length!==1 || filtered[0].x!==180) return false;
 manager.queueInputRegions();
 manager.queueInputRegions();
 const timer=manager._inputRegionIdle;
 if(!timer) return false;
 testTimers.get(timer)();
 return regions.length===1 && regions[0][0].width===400 && manager._inputRegionIdle===0;
})()`);
assert.equal(windowGeometryTest,true);
console.log('OK: visible windows only, idle-coalesced input updates; desktop excluded');

// v0.3.0.2: regression for a Nemo window mapped AFTER a Fence is created.
// The initial region can be full; new visibility/allocation must trigger a
// recalculation and crop the old full-Fence region.
const lateMappedWindowTest=call(`(() => {
 const manager=Object.create(FenceManager.prototype);
 manager.dead=false;manager._inputRegionIdle=0;
 manager._windowActorWatch=new Map();
 manager.fences=new Map();
 const f=Object.create(Fence.prototype);
 f._disposed=false;f._inputPieces=[];f._inputRegionKey='';
 f.actor={width:348,height:311,children:[],
   get_transformed_position:()=>[169,36], add_child(child){this.children.push(child);}};
 manager.fences.set('3D',f);
 const nemo={title:'Russian',get_window_type:()=>0,
   showing_on_its_workspace:()=>true,
   get_buffer_rect:()=>({x:364,y:105,width:1310,height:876})};
 let mapped=false;
 global.workspace_manager={get_active_workspace:()=>({list_windows:()=>mapped?[nemo]:[]})};
 manager.queueInputRegions();
 testTimers.get(manager._inputRegionIdle)();
 if(f._inputPieces.length!==1 || f._inputPieces[0].width!==348) return false;
 const actor={handlers:new Map(),seq:0, connect(signal,fn){const n=++this.seq;this.handlers.set(n,{signal,fn});return n;},disconnect(n){this.handlers.delete(n)}};
 manager._watchWindowActor(actor);
 if(manager._windowActorWatch.size!==1) return false;
 mapped=true;
 const allocation=[...actor.handlers.values()].find(h=>h.signal==='notify::allocation');
 if(!allocation) return false;
 allocation.fn();
 if(!manager._inputRegionIdle) return false;
 testTimers.get(manager._inputRegionIdle)();
 if(f._inputPieces.length!==2) return false;
 const regions=f._inputPieces.map(a=>({x:a.x+169,y:a.y+36,width:a.width,height:a.height}));
 if(regions.some(r=>!(r.x+r.width<=364 || r.y+r.height<=105))) return false;
 manager._forgetWindowActor(actor);
 return manager._windowActorWatch.size===0 && actor.handlers.size===0;
})()`);
assert.equal(lateMappedWindowTest,true);
console.log('OK: v0.3.0.2 late Nemo map/allocation crops old full-Fence input region');

// v0.3.1: selection with Ctrl, Shift range, and group movement in the grid.
const multiSelectTest=call(`(() => {
 const f=Object.create(Fence.prototype);
 f._drag=null; f.selectedItem=null; f._selectionAnchor=null;
 f.items=['one','two','three','four'].map((name,i)=>({name,col:i%2,row:Math.floor(i/2),
   selected:false,actor:{set_style(){}},label:{}}));
 f._selectItem(f.items[0]);
 f._toggleSelectedItem(f.items[2]);
 if (!f.items[0].selected || !f.items[2].selected || f.items[1].selected) return false;
 f._selectRangeTo(f.items[3],false);
 if (f.items.filter(it=>it.selected).length!==2) return false;
 f._selectItem(f.items[0]);
 f._selectRangeTo(f.items[3],false);
 if (!f.items.every(it=>it.selected)) return false;
 f._clearItemStates();
 return f.items.every(it=>!it.selected) && f._selectionAnchor===null;
})()`);
assert.equal(multiSelectTest,true);
const groupMoveTest=call(`(() => {
 const f=Object.create(Fence.prototype);f._disposed=false;
 f.config=normalizeConfig({icons:{positions:{a:[0,0],b:[1,0],c:[2,0],d:[0,1]}}},'/home/nard/Desktop/Games');
 f.cells=new Map(); f.scroll=0;
 f.items=['a','b','c','d'].map((name,i)=>({name,col:i%3,row:Math.floor(i/3),selected:name==='a'||name==='c',
   actor:{opacity:0}}));
 f.actor={get_transformed_position:()=>[0,0]};
 f._layoutItems=()=>{}; f._save=()=>f.saved=true;
 f._finishItemMoveAt(160,235,f.items[0]);
 const pos=f.config.icons.positions;
 return f.saved && JSON.stringify(pos.b)==='[1,0]' && JSON.stringify(pos.d)==='[0,1]' &&
   JSON.stringify(pos.a)!=='[0,0]' && pos.a.join()!==pos.c.join();
})()`);
assert.equal(groupMoveTest,true);
console.log('OK: Ctrl multiselect, Shift range, group grid moves without overwriting cells');

const batchTransferTest=call(`(() => {
 const map=new Map();const trashed=[];
 const root='/home/nard/Desktop';const from=root+'/Games',to=root+'/Coding';
 const add=(p,text)=>map.set(p,{type:1,text,rev:0});
 add(from+'/alpha.txt','alpha');add(from+'/beta.txt','beta');
 Gio.FileCopyFlags={NONE:0};Gio.FileQueryInfoFlags={NOFOLLOW_SYMLINKS:1};
 Gio.FileType={REGULAR:1,DIRECTORY:2,SYMBOLIC_LINK:3,UNKNOWN:0};
 let failMove=false;
 const file=p=>({path:p,
   query_exists:()=>map.has(p),
   query_file_type:()=>map.get(p)?.type||0,
   query_info:()=>({get_file_type:()=>map.get(p)?.type||0,
      get_size:()=>map.get(p).text.length,
      get_attribute_uint64:()=>map.get(p).rev,
      get_attribute_uint32:()=>0,
      get_attribute_string:()=>null}),
   move(dst,flags){if(failMove&&p.endsWith('/beta.txt'))throw Error('injected failure');
     if(flags!==0||!map.has(p)||map.has(dst.path))throw Error('unsafe move');
     map.set(dst.path,map.get(p));map.delete(p);},
   copy(dst,flags){if(flags!==0||!map.has(p)||map.has(dst.path))throw Error('unsafe copy');
     map.set(dst.path,{...map.get(p)});},
   trash(){if(!map.has(p))throw Error('missing');trashed.push(p);map.delete(p)}
 });
 Gio.File={new_for_path:p=>file(p)};
 const movePlan=planFenceTransfer(from,to,['alpha.txt','beta.txt'],false);
 if(!executeFenceTransfer(movePlan,false).ok || map.has(from+'/alpha.txt'))return 'move failure';
 if(!undoFenceTransfer({entries:movePlan,copy:false}).ok || !map.has(from+'/alpha.txt') || !map.has(from+'/beta.txt')) return 'undo move failure';
 failMove=true;
 const rollback=executeFenceTransfer(planFenceTransfer(from,to,['alpha.txt','beta.txt'],false),false);
 if(rollback.ok || rollback.rollbackErrors.length || !map.has(from+'/alpha.txt') || map.has(to+'/alpha.txt')) return 'rollback failure';
 failMove=false;
 add(to+'/alpha.txt','existing');
 try {planFenceTransfer(from,to,['alpha.txt','beta.txt'],false);return 'collision allowed'} catch(_){}
 if(map.get(to+'/alpha.txt').text!=='existing')return 'collision overwrote';
 map.delete(to+'/alpha.txt');
 const copyPlan=planFenceTransfer(from,to,['alpha.txt','beta.txt'],true);
 if(!executeFenceTransfer(copyPlan,true).ok || !map.has(from+'/alpha.txt') || !map.has(to+'/alpha.txt'))return 'copy failure';
 map.get(to+'/beta.txt').rev++;
 try {undoFenceTransfer({entries:copyPlan,copy:true});return 'changed copy trashed'} catch(_){}
 if(!map.has(to+'/alpha.txt')||!map.has(to+'/beta.txt'))return 'changed copy modified';
 map.get(to+'/beta.txt').rev--;
 if(!undoFenceTransfer({entries:copyPlan,copy:true}).ok) return 'copy trash failure';
 if(!map.has(from+'/alpha.txt')||map.has(to+'/alpha.txt')||trashed.length!==2) return 'copy undo data loss';
 const bad=from+'/link';map.set(bad,{type:3,text:'',rev:0});
 try {planFenceTransfer(from,to,['link'],false);return 'symlink allowed'} catch(_){}
 return true;
})()`);
assert.equal(batchTransferTest,true);
console.log('OK: multi-file atomic preflight, collision/symlink rejection, move rollback, copy and recoverable Undo');

const pointerSelectionTest=call(`(() => {
 const f=Object.create(Fence.prototype);f._drag=null;f.selectedItem=null;f._selectionAnchor=null;
 const a={name:'a',selected:false,col:0,row:0,actor:{set_style(){}},label:{}};
 const b={name:'b',selected:false,col:1,row:0,actor:{set_style(){}},label:{}};
 f.items=[a,b];f._setPointerMode=(mode,event,item)=>{f._drag={mode,item,moved:false};};
 f._endPointer=()=>{f._drag=null;};
 const event=(mask)=>({get_button:()=>1,get_click_count:()=>1,get_state:()=>mask});
 Clutter.ModifierType.CONTROL_MASK=4;
 Clutter.ModifierType.SHIFT_MASK=1;
 f._itemDown(a,event(0));
 if(!a.selected || b.selected) return 'single click';
 f._endPointer();
 f._itemDown(b,event(4));
 if(!a.selected||!b.selected||!f._drag.copy||f._drag.names.length!==2) return 'Ctrl adds';
 f._endPointer();
 f._itemDown(b,event(4));
 f._finishPointerAt(5,5);
 if(!a.selected||b.selected) return 'Ctrl removes on release';
 f._itemDown(b,event(1));
 if(!a.selected||!b.selected||f._drag) return 'Shift range';
 return true;
})()`);
assert.equal(pointerSelectionTest,true);
console.log('OK: user Ctrl-click selection/release, Ctrl-drag source set and Shift range');

// v0.3.2: independent snapping; no X11 actor/input-registration changes.
const snappingTests=call(`(() => {
  const base=normalizeSnapSettings(null);
  if(base.enabled || !base.fences || !base.screen || base.grid || base.distance!==14) return 'defaults';
  const on=normalizeSnapSettings({enabled:true,screen:true,fences:true,grid:false,distance:14});
  const area={x:0,y:0,width:1200,height:800};
  const another=[{x:440,y:100,width:250,height:250}];
  const move=(x,y, opts=on, alt=false)=>snapMoveRect({x,y,width:200,height:150},area,another,opts,alt);
  if(move(3,5).x!==0 || move(3,5).y!==0) return 'screen left/top';
  if(move(998,645).x!==1000 || move(998,645).y!==650) return 'screen right/bottom';
  if(move(239,115).x!==240) return 'align end to other start';
  if(move(447,115).x!==440) return 'align start to start';
  if(move(510,115).x!==510) return 'no distant snapping';
  if(move(239,640).x!==239) return 'ignore far fence';
  if(move(239,115,on,true).x!==239) return 'Alt disabled';
  if(move(239,115,base).x!==239) return 'master disabled';
  const grid={enabled:true,screen:true,fences:false,grid:true,distance:12,gridX:25,gridY:40};
  if(move(47,62,grid).x!==50 || move(47,62,grid).y!==80) return 'grid';
  // Edge alignment outranks grid, including an EXACT edge coordinate.
  if(move(0,0,grid).x!==0 || move(0,0,grid).y!==0) return 'priority';
  const second={x:1300,y:50,width:500,height:600};
  const shift={enabled:true,fences:false,screen:false,grid:true,distance:12,gridX:50,gridY:50};
  const shifted=snapMoveRect({x:1399,y:124,width:200,height:150},second,[],shift);
  if(shifted.x!==1400 || shifted.y!==100) return 'monitor-relative grid';
  const west=snapResizeRect({x:242,y:115,width:358,height:210},'w',area,another,on);
  if(west.x!==242) return 'west far from candidates';
  const east=snapResizeRect({x:50,y:100,width:385,height:250},'e',area,another,on);
  if(east.width!==390) return 'right resize';
  const rightDisabled=snapResizeRect({x:50,y:100,width:385,height:250},'e',area,another,on,true);
  if(rightDisabled.width!==385) return 'Alt right resize';
  const snapEdge=snapResizeRect({x:10,y:20,width:1182,height:320},'e',area,[],on);
  if(snapEdge.width!==1190) return 'resize screen edge';
  // Moving a Fence never modifies its icon positions or geometry when disabled.
  const prev={x:100,y:120,width:350,height:270};
  if(snapMoveRect(prev,area,another,base).x!==100 || prev.x!==100) return 'pure';
  return true;
})()`);
assert.equal(snappingTests,true,'snapping failed: '+snappingTests);
// Alt gate uses the real state mask from Clutter motion-event, not a key poll.
mockClutter.ModifierType.MOD1_MASK=8;
const altTest=call(`(() => {const f=Object.create(Fence.prototype);
 return f._altDown({get_state:()=>8}) && !f._altDown({get_state:()=>0});})()`);
assert.equal(altTest,true);
console.log('OK: v0.3.2 magnetic Fence/screen edges, grid, monitor offsets, Alt and resize');

// Integration: the actual Fence motion handler consults Manager settings,
// while Alt bypasses snapping and a release keeps the old modal-grab handling.
const liveMotionSnapTest=call(`(() => {
 const f=Object.create(Fence.prototype);
 const geometry={x:100,y:100,width:350,height:270};
 f.config={geometry};
 let location=null;
 f.actor={set_position:(x,y)=>location=[x,y]};
 f.manager={snapSettings:{enabled:true,fences:true,screen:false,grid:false,distance:14,gridX:20,gridY:20},
     snapNeighbors:()=>[{x:520,y:100,width:300,height:270}]};
 f._workAreaForPointer=()=>({x:0,y:0,width:1200,height:800});
 f._drag={mode:'move',sx:10,sy:10,x:100,y:100,width:350,height:270,moved:false};
 const drag=(endX,mod)=>({type:()=>Clutter.EventType.MOTION,get_coords:()=>[endX,10],get_state:()=>mod});
 f._stageEvent(drag(76,0));
 const sn=(location && location[0]===170 && geometry.x===170);
 f._stageEvent(drag(76,Clutter.ModifierType.MOD1_MASK));
 const alt=(location && location[0]===166 && geometry.x===166);
 const noStyleChange=!('appearance' in f.config);
 return sn && alt && noStyleChange;
})()`);
assert.equal(liveMotionSnapTest,true);
console.log('OK: v0.3.2 real motion handler uses manager snapping, Alt bypass and preserved layout');

// v0.4.0: hide/show is session-only and releases the exact X11 input pieces.
const hotkeyTest=call(`(() => {
 const m=Object.create(FenceManager.prototype);
 m.dead=false;m._registeredHotkey=null;
 m.hotkeySettings=normalizeHotkeySettings({enabled:false});
 m.fencesVisible=true;
 let show=0,hide=0,clear=0,regions=0,close=0;
 const fake={_disposed:false,_drag:null,
   actor:{show:()=>show++,hide:()=>hide++},_clearInputPieces:()=>clear++,
   _clearCursor:()=>{},menu:{close:()=>close++}};
 m.fences=new Map([['one',fake]]);
 m.queueInputRegions=()=>regions++;
 m._bindToggleHotkey();
 if(m._registeredHotkey || testShortcut.reg!==0) return 'opt-in default';
 m.hotkeySettings=normalizeHotkeySettings({enabled:true,toggle:'<Super>f'});
 m._bindToggleHotkey();
 if(m._registeredHotkey!=='<Super>f') return 'register';
 m.toggleAllFences();
 if(m.fencesVisible || hide!==1 || clear!==1) return 'hide and untrack';
 m.toggleAllFences();
 if(!m.fencesVisible || show!==1 || regions<2) return 'show';
 m.hotkeySettings=normalizeHotkeySettings({enabled:false});
 m._bindToggleHotkey();
 if(m._registeredHotkey || testShortcut.rem<1) return 'remove';
 // A change while hidden must restore before the old key is released.
 m.hotkeySettings=normalizeHotkeySettings({enabled:true,toggle:'<Control><Alt>g'});
 m._bindToggleHotkey();m.toggleAllFences();
 m.hotkeySettings=normalizeHotkeySettings({enabled:true,toggle:'<Super>x'});
 m._bindToggleHotkey();
 if(!m.fencesVisible || m._registeredHotkey) return 'conflict safe and restore';
 if(close<3)return 'menus closed';
 return true;
})()`);
assert.equal(hotkeyTest,true,'shortcut test: '+hotkeyTest);
assert.equal(call('normalizeHotkeySettings({enabled:false}).toggle'),'<Super>f');
console.log('OK: v0.4.0 shortcut lifecycle, opt-in, conflict, hide/show and input release');
const monitorsTest=call(`(() => {
 const original={x:2200,y:150,width:350,height:270};
 const both=[{x:0,y:25,width:1920,height:1035},{x:1920,y:25,width:1920,height:1035}];
 const one=[{x:0,y:25,width:1920,height:1035}];
 if(recoverOffscreenFence(original,both)!==null)return 'both reachable';
 const moved=recoverOffscreenFence(original,one);
 if(!moved || moved.x!==1570 || moved.y!==150)return 'recover to first';
 if(original.x!==2200)return 'must not change saved position';
 if(recoverOffscreenFence({x:1800,y:100,width:350,height:270},one)!==null)return 'title partly visible';
 const shifted=[{x:-1920,y:0,width:1920,height:1080}];
 const recovered=recoverOffscreenFence({x:100,y:100,width:400,height:300},shifted);
 if(recovered.x!==-400)return 'negative monitor coordinate';
 if(recoverOffscreenFence(original,[])!==null)return 'no monitor fail safe';
 return true;
})()`);
assert.equal(monitorsTest,true,'monitor geometry: '+monitorsTest);
const monitorManagerTest=call(`(() => {
 const m=Object.create(FenceManager.prototype);
 const f={_disposed:false,_drag:null,config:{geometry:{x:2200,y:150,width:350,height:270},collapsed:false},
   actor:{x:2200,y:150,set_position(x,y){this.x=x;this.y=y;}}};
 m.fences=new Map([['a',f]]);let queued=0;m.queueInputRegions=()=>queued++;
 m._workAreas=()=>[{x:0,y:25,width:1920,height:1035}];
 m._applyMonitorLayout();
 if(f.actor.x!==1570 || f.config.geometry.x!==2200)return 'temporary';
 m._workAreas=()=>[{x:0,y:25,width:1920,height:1035},{x:1920,y:25,width:1920,height:1035}];
 m._applyMonitorLayout();
 if(f.actor.x!==2200 || queued!==2)return 'automatic return';
 return true;
})()`);
assert.equal(monitorManagerTest,true,'monitor manager: '+monitorManagerTest);
console.log('OK: v0.4.0 two-monitor geometry, negative coordinates, transient recovery, automatic return');

// v0.5.1: Sections originate from real immediate subdirectories. The closed
// Rolodex state creates no icon actors and switching never moves filesystem data.
const viewsTest=call(`(() => {
 const oldDir=directoryNames,oldTest=GLib.file_test;
 const names={
   '/desk/3D':['CAD Software','Slicers','Tools','Readme.txt'],
   '/desk/3D/CAD Software':['FreeCAD.desktop'],
   '/desk/3D/Slicers':['BS.desktop','CR.desktop','X1.desktop','X2.desktop','X3.desktop'],
   '/desk/3D/Tools':['MeshLab.desktop']
 };
 directoryNames=(folder,dirs)=>dirs?['CAD Software','Slicers','Tools']:names[folder]||[];
 GLib.file_test=(path,flag)=>['CAD Software','Slicers','Tools'].some(n=>path==='/desk/3D/'+n);
 try {
  const f=Object.create(Fence.prototype);
  f.folder='/desk/3D';f._disposed=false;f._drag=null;f.scroll=0;
  f.config=normalizeConfig({view:{mode:'rolodex',active:''}},f.folder);
  f.rebuild=()=>{f._readItemsResult=f._readItems();};f._saveView=()=>{f.saved=JSON.stringify(f.config.view)};
  let entries=f._readItems();
  if(entries.length!==0 || f._sections.length!==4)return 'initial closed';
  f._activeSection='';
  f._activateSection('Slicers');
  if(f._readItemsResult.length!==5 ||
     f._readItemsResult[0].name!=='Slicers/BS.desktop' ||
     f._readItemsResult[0].path!=='/desk/3D/Slicers/BS.desktop')return 'open subfolder';
  f._activeSection='Slicers';f._activateSection('Tools');
  if(f._readItemsResult.length!==1 || f._readItemsResult[0].name!=='Tools/MeshLab.desktop')return 'exclusive';
  f._activeSection='Tools';f._activateSection('Tools');
  if(f._readItemsResult.length!==0 || f.config.view.active!=='')return 'collapse same';
  f.config.view.mode='tabs';f.config.view.active='CAD Software';
  entries=f._readItems();
  if(entries.length!==1 || entries[0].name!=='CAD Software/FreeCAD.desktop')return 'tabs view';
  f.config.view.active='/';entries=f._readItems();
  if(entries.length!==1 || entries[0].name!=='Readme.txt')return 'root Main';
  if(normalizeConfig({view:{mode:'bad'},header:{height:100,background:'red'},sections:{fontSize:3}},f.folder).view.mode!=='icons')return 'safe defaults';
  return true;
 } finally {directoryNames=oldDir;GLib.file_test=oldTest;}
})()`);
assert.equal(viewsTest,true, 'v0.5.1 subfolder navigation: '+viewsTest);
console.log('OK: v0.5.1 real subfolders, Main root, Tabs, single-open Rolodex and all-closed state');

// v0.5.1: pixel-scrolling and the vertical accordion keep lower section bars
// accessible, even if the opened section contains many icons.
const viewLayoutTest=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({view:{mode:'rolodex',active:'Slicers'}},'/desk/3D');
 f._activeSection='Slicers';f._sections=[{key:'CAD',title:'CAD'},
    {key:'Slicers',title:'Slicers'},{key:'Tools',title:'Tools'}];
 f._navButtons=f._sections.map(z=>({key:z.key,actor:{set_position(x,y){this.x=x;this.y=y},
     set_size(w,h){this.width=w;this.height=h},visible:true}}));
 f.items=[0,1,2,3,4].map(i=>({col:i%3,row:Math.floor(i/3),icon:{},label:{},actor:{
     set_position(x,y){this.x=x;this.y=y},visible:false}}));
 f.content={width:300,height:125};f.scroll=0;
 f.scrollTrack={height:125,width:10,visible:false};
 f.scrollThumb={set_position(){},set_size(){}};
 f._style=()=>{};
 f._placeItems();
 const open=f._navButtons[1].y===32 && f._navButtons[2].y>210;
 const scrollable=f._maxScroll>0&&f.scrollTrack.visible;
 f.scroll=f._maxScroll;f._placeItems();
 return open&&scrollable&&f._navButtons[2].actor.visible;
})()`);
assert.equal(viewLayoutTest,true,'v0.5.1 accordion viewport');
console.log('OK: v0.5.1 Rolodex scroll, following sections remain reachable');
const perSectionOrderTest=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({view:{mode:'tabs',active:'Slicers'},icons:{
    positions:{'Slicers/BS.desktop':[1,1],'CAD/FreeCAD.desktop':[3,4],'Readme.txt':[2,2]},
    layoutColumns:3}},'/desk/3D');
 f.items=[{name:'Slicers/BS.desktop',col:1,row:1}];
 f._disposed=false;f._drag=null;
 f._save=()=>{};f._layoutItems=()=>{};f.scroll=0;
 if(!f._applyArrangement(['Slicers/BS.desktop']))return 'sort';
 return f.config.icons.positions['CAD/FreeCAD.desktop'].join(',')==='3,4' &&
    f.config.icons.positions['Readme.txt'].join(',')==='2,2';
})()`);
assert.equal(perSectionOrderTest,true,'per-section ordering');
console.log('OK: v0.5.1 sorting in one tab never erases positions in other sections');
const invisibleHeaderTest=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({header:{show:false},geometry:{width:350,height:270}},'/desk/3D');
 f.actor={width:350,height:270,get_transformed_position:()=>[100,100]};
 f._disposed=false;f._drag=null;
 f._clearItemStates=()=>{};
 f._setPointerMode=(mode)=>{f.lastMode=mode;};
 const event={get_coords:()=>[255,106],get_button:()=>1,get_click_count:()=>1,get_source:()=>null};
 const edge=f._edgeName(event);
 const regular=f._boundaryCapture({type:()=>Clutter.EventType.BUTTON_PRESS,
     get_coords:event.get_coords,get_button:()=>1,get_state:()=>0});
 const alt=f._boundaryCapture({type:()=>Clutter.EventType.BUTTON_PRESS,
     get_coords:event.get_coords,get_button:()=>1,get_state:()=>Clutter.ModifierType.MOD1_MASK});
 return f._headerHeight()===0 && edge==='' && regular===Clutter.EVENT_PROPAGATE &&
    alt===Clutter.EVENT_STOP && f.lastMode==='move';
})()`);
assert.equal(invisibleHeaderTest,true,'headerless Fence Alt+drag');
console.log('OK: v0.5.3 no blank header strip; Alt+drag moves without stealing sections');

// v0.5.2: all header tabs must fit, otherwise safely fall back to the content.
const headerTabs052=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({title:'3D',geometry:{width:460,height:280},
   header:{height:36},sections:{height:30},view:{mode:'tabs',tabsInHeader:true}},'/desk/3D');
 f.title={set_width(w){this.width=w}};f.arrow={visible:true};
 const makeContainer=()=>({add_child(a){a.parent=this},remove_child(a){a.parent=null}});
 f.content=makeContainer();f.content.width=440;
 f.header=makeContainer();
 f._sections=[{key:'CAD',title:'CAD'},{key:'Slicers',title:'Slicers'},
   {key:'Tools',title:'Tools'}];
 f._navButtons=f._sections.map(s=>{const actor={get_parent(){return this.parent}};
    f.content.add_child(actor);return {key:s.key,actor}});
 f._layoutNavigation();
 const fits=f._navButtons.every(a=>a.inHeader&&a.actor.get_parent()===f.header)&&
    f._gridOriginY===4&&f._navButtons[0].x>=72;
 const nav=f._navButtons[0];
 const press=f._headerDown.call(Object.assign(Object.create(Fence.prototype),{
    config:f.config,_navButtons:f._navButtons,arrow:null,arrowIcon:null}),
    {get_source:()=>nav.actor,get_button:()=>1});
 f.config.geometry.width=180;f.content.width=160;f._layoutNavigation();
 const fallback=f._navButtons.every(a=>!a.inHeader&&a.actor.get_parent()===f.content)&&
   f._gridOriginY>30;
 return fits&&press===Clutter.EVENT_PROPAGATE&&fallback;
})()`);
assert.equal(headerTabs052,true,'v0.5.2 safe header-tabs fit/overflow and no drag');
const style052=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({header:{background:'#112233',opacity:.1,hoverBackground:'#224466',hoverOpacity:.9,
    textColor:'#eeeeee',hoverTextColor:'#aabbcc'},
   sections:{background:'#333333',hoverBackground:'#445566',hoverOpacity:.8}},'/desk/3D');
 const a={set_style(s){this.style=s}};
 f.background=Object.create(a);f.header=Object.create(a);f.title=Object.create(a);
 f.items=[];f._navButtons=[{actor:Object.create(a),label:Object.create(a),hover:false}];
 f._style(false);
 const idle=f.header.style.includes('0.1')&&f.title.style.includes('#eeeeee');
 f._navButtons[0].hover=true;f._style(true);
 const hot=f.header.style.includes('0.9')&&f.title.style.includes('#aabbcc')&&
    f._navButtons[0].actor.style.includes('rgba(68,85,102,0.8)');
 return idle&&hot;
})()`);
assert.equal(style052,true,'v0.5.2 idle/hover header and section styling');
console.log('OK: v0.5.2 header-tab click protection/overflow and idle-hover styling');
const edgeNav052=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({view:{mode:'rolodex'},geometry:{x:100,y:110,width:350,height:270}},'/desk/3D');
 f.actor={get_transformed_position:()=>[100,110],width:350,height:270};
 f._drag=null;f._clearItemStates=()=>{};
 f._setPointerMode=mode=>{f.started=mode};
 const label={};const button={contains:s=>s===label};
 f._navButtons=[{actor:button,label}];
 const ev={type:()=>Clutter.EventType.BUTTON_PRESS,get_button:()=>1,
   get_source:()=>label,get_coords:()=>[104,170]};
 const a=f._boundaryCapture(ev),b=f._edgeDown(ev);
 return a===Clutter.EVENT_PROPAGATE && b===Clutter.EVENT_PROPAGATE && !f.started;
})()`);
assert.equal(edgeNav052,true,'v0.5.2 full-bleed Rolodex click on left edge does not resize');
console.log('OK: v0.5.2 full-width section headers do not trigger Fence resize');

// v0.5.3 automatic height has no geometry persistence and respects caps.
const fit053=call(`(() => {
 const c=normalizeConfig({geometry:{width:450,height:350},view:{mode:'rolodex',
    autoFitHeight:true,autoFitMaxHeight:600}},'/desk/3D');
 return c.geometry.height===350 && c.view.autoFitHeight && c.view.autoFitMaxHeight===600 &&
    rolodexFitHeight(0,126,0,600,1000)===129 &&
    rolodexFitHeight(32,132,312,600,1000)===347 &&
    rolodexFitHeight(0,210,900,600,1000)===600 &&
    rolodexFitHeight(0,210,900,700,250)===250 &&
    normalizeConfig({view:{mode:'tabs'}},'/desk/3D').view.autoFitHeight===false;
})()`);
assert.equal(fit053,true,'v0.5.3 rolodex height, cap and legacy geometry');
console.log('OK: v0.5.3 content-fit with limit and preserving manual height');
const layered053=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({appearance:{background:'#202733',backgroundOpacity:.27,hoverOpacity:.75},
    header:{background:'#202733',opacity:.27,hoverBackground:'#202733',hoverOpacity:.75}},'/desk/3D');
 const fake=()=>({set_style(style){this.style=style}});
 f.background=fake();f.header=fake();f.title=fake();f._navButtons=[];f.items=[];
 f._style(false);
 const idle=f.header.style.includes('rgba(32,39,51,0.27)') &&
    f.background.style.includes('rgba(32,39,51,0.27)') &&
    f.header.style.includes('border-bottom:0px') && f.background.style.includes('border-top:0px');
 f._style(true);
 return idle && f.header.style.includes('rgba(32,39,51,0.75)') &&
    f.background.style.includes('rgba(32,39,51,0.75)');
})()`);
assert.equal(layered053,true,'header and body are sibling alpha layers');
console.log('OK: v0.5.3 header/body visual opacity parity');
const fittedGeometry053=call(`(() => {
 const f=Object.create(Fence.prototype);
 f.config=normalizeConfig({geometry:{x:100,y:100,width:400,height:350},header:{show:false},
    view:{mode:'rolodex',autoFitHeight:true,autoFitMaxHeight:500}},'/desk/3D');
 f._activeSection='';f._sections=[{key:'Main',title:'Main'},
    {key:'CAD',title:'CAD'},{key:'Slicers',title:'Slicers'},{key:'Tools',title:'Tools'}];
 f._navButtons=f._sections.map(s=>({key:s.key,actor:{set_position(){},set_size(){},visible:true}}));
 f.items=[];f._gridOriginY=0;f._autoHeightPixels=null;f.scroll=0;
 f.actor={height:350,width:400,get_transformed_position:()=>[100,100]};
 f.content={width:398,height:349};f._limitAutoHeight=()=>450;
 f._sizeActors=()=>{f.actor.height=f._autoHeightPixels;f.content.height=f.actor.height-1};
 f._placeScrollbar=()=>{};
 f._placeItems();
 const closed=f.actor.height===129&&f._maxScroll===0&&f.config.geometry.height===350;
 f._activeSection='CAD';f.items=[{row:0,col:0,actor:{set_position(){}}},
    {row:1,col:0,actor:{set_position(){}}}];
 f._placeItems();
 const opened=f.actor.height>129&&f._maxScroll===0;
 f._limitAutoHeight=()=>170;f._placeItems();
 return closed&&opened&&f.actor.height===170&&f._maxScroll>0&&f.config.geometry.height===350;
})()`);
assert.equal(fittedGeometry053,true,'live _placeItems recomputes fitted height and scroll');
console.log('OK: v0.5.3 layout grows/shrinks with Rolodex and caps viewport');

// v0.5.4: Rounded exposed Rolodex corners without changing unrelated tabs.
const corners054 = call(`({
  top:sectionCornerShape('rolodex',false,0,0,30,128,0,12),
  bottom:sectionCornerShape('rolodex',false,3,96,30,128,0,12),
  header:sectionCornerShape('rolodex',true,0,0,30,128,0,12),
  middle:sectionCornerShape('rolodex',false,2,64,30,128,0,12),
  fixed:sectionCornerShape('rolodex',false,3,96,30,280,0,12),
  tabs:sectionCornerShape('tabs',false,0,0,30,30,0,12)
})`);
assert.equal(corners054.top,'border-radius:11px 11px 0px 0px;');
assert.equal(corners054.bottom,'border-radius:0px 0px 11px 11px;');
assert.equal(corners054.header,'border-radius:0px;');
assert.equal(corners054.middle,'border-radius:0px;');
assert.equal(corners054.fixed,'border-radius:0px;');
assert.equal(corners054.tabs,'border-radius:0px;');
console.log('OK: v0.5.4 exposed headerless Rolodex corners and fixed-height bars');
// Exercise the *real* navigation builder, not just a source-string check.
// Its St.Button child must stretch, with symmetric expanding spacers only for
// the centered alignment. A naturally sized label cannot align by itself.
const navigation054=call(`(() => {
    const St=imports.gi.St;
    if (!Clutter.ActorAlign) Clutter.ActorAlign={CENTER:1};
    const Saved={Label:St.Label,Widget:St.Widget,BoxLayout:St.BoxLayout,Button:St.Button};
    class Actor {
        constructor(params={}) {this.params=params;this.children=[];this.handlers=[];this.destroyed=false;}
        add_child(child){this.children.push(child)}
        connect(name,fn){this.handlers.push(name);return this.handlers.length;}
        destroy(){this.destroyed=true;}
    }
    St.Label=class extends Actor {};
    St.Widget=class extends Actor {};
    St.BoxLayout=class extends Actor {};
    St.Button=class extends Actor {};
    const result=[];
    for(const align of ['left','center','right']) {
        const f=Object.create(Fence.prototype);
        f.config={view:{mode:'rolodex'},sections:{alignment:align,showCollapseButton:true}};
        f._navButtons=[];
        f._sections=[{key:'CAD',title:'CAD'}];f._activeSection=null;
        f.content=new Actor();
        f._rebuildNavigation();
        const b=f._navButtons[0].actor;
        const child=b.params.child;
        result.push([align,b.params.x_fill,child.params.x_expand,
            child.children.map(x=>x.params.x_expand===true)]);
    }
    Object.assign(St,Saved);
    return result;
})()`);
assert.equal(JSON.stringify(navigation054), JSON.stringify([
  ['left',true,true,[false,false,true]],
  ['center',true,true,[true,false,true]],
  ['right',true,true,[true,false,false]]
]));
console.log('OK: v0.5.4 actual section title left/center/right uses stretching bar layout');
