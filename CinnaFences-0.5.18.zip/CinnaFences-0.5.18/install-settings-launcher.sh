#!/usr/bin/env bash
# Install an application identity for the on-demand GTK settings window.
# No services, daemons, or modifications to system desktop files.
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
APP_DIR="$DATA_HOME/applications"
ICON_DIR="$DATA_HOME/icons/hicolor/scalable/apps"
TARGET="$APP_DIR/cinnafences-settings.desktop"
ICON="$ICON_DIR/cinnafences-settings.svg"
SCRIPT="$DATA_HOME/cinnamon/extensions/cinnafences@local/settings.py"
if [[ ! -f "$SCRIPT" ]]; then
    echo "Niet geïnstalleerd: $SCRIPT" >&2
    exit 1
fi
if [[ -L "$APP_DIR" || -L "$ICON_DIR" || -L "$TARGET" || -L "$ICON" ]]; then
    echo 'Symlink bij desktop launcher/icon geweigerd.' >&2
    exit 1
fi
if [[ -f "$TARGET" ]] && ! grep -Fxq '# CinnaFences managed launcher' "$TARGET"; then
    echo "Bestaande niet-CinnaFences launcher geweigerd: $TARGET" >&2
    exit 1
fi
if [[ -f "$ICON" ]] && ! cmp -s "$ICON" "$BASE/cinnafences@local/cinnafences-icon.svg"; then
    echo "Bestaand aangepast icon geweigerd: $ICON" >&2
    exit 1
fi
mkdir -p "$APP_DIR" "$ICON_DIR"
install -m 0644 "$BASE/cinnafences@local/cinnafences-icon.svg" "$ICON"
# Generate a spec-compliant double-quoted Exec argument for unusual home paths.
python3 - "$SCRIPT" "$TARGET" <<'PY'
from pathlib import Path
import os
import sys
path, target = sys.argv[1:]

def quote_exec_arg(s):
    # Desktop Entry specification: quoted arguments escape \\, $, ` and ".
    escaped = (s.replace('\\', '\\\\')
                .replace('"', '\\"')
                .replace('$', '\\$')
                .replace('`', '\\`'))
    return '"' + escaped + '"'

text = '''# CinnaFences managed launcher
[Desktop Entry]
Type=Application
Name=CinnaFences Settings
Comment=Configure CinnaFences desktop groups
Exec=/usr/bin/python3 {script}
TryExec=/usr/bin/python3
Icon=cinnafences-settings
StartupWMClass=cinnafences-settings
StartupNotify=false
Terminal=false
Categories=Settings;Utility;
'''.format(script=quote_exec_arg(path))
p=Path(target)
tmp=p.with_name(p.name+'.new.'+str(os.getpid()))
try:
    tmp.write_text(text,encoding='utf-8')
    tmp.chmod(0o644)
    os.replace(tmp,p)
finally:
    if tmp.exists(): tmp.unlink()
PY
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true
fi
echo "CinnaFences instellingen-app geregistreerd in: $TARGET"
