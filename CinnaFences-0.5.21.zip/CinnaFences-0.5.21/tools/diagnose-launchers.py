#!/usr/bin/env python3
"""Read-only diagnostics for .desktop icons in a CinnaFences folder.

Prints metadata and whether an icon source is available. Does not execute
applications, change configuration, follow arbitrary icon search paths, or
make any network connections.
"""
import configparser
import os
from pathlib import Path
import sys


def main() -> int:
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else '~/Desktop/Midi').expanduser()
    if not folder.is_dir():
        print(f'Not a directory: {folder}', file=sys.stderr)
        return 2
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk
        theme = Gtk.IconTheme.get_default()
    except Exception:
        theme = None
    count = 0
    for item in sorted(folder.iterdir(), key=lambda p: p.name.lower()):
        if not item.name.lower().endswith('.desktop'):
            continue
        count += 1
        cfg = configparser.ConfigParser(interpolation=None, strict=False)
        cfg.optionxform = str
        try:
            with item.open('r', encoding='utf-8-sig') as reader:
                cfg.read_file(reader)
            section = cfg['Desktop Entry']
            icon = section.get('Icon', '').strip()
            name = section.get('Name', item.stem)
            if not icon:
                status = 'NO Icon= field (CinnaFences will try theme fallbacks)'
            elif icon.startswith('/') or icon.startswith('~/'):
                path = Path(icon).expanduser()
                status = ('file exists' if path.is_file() else 'ICON FILE MISSING')
            elif theme is None:
                status = 'theme lookup unavailable'
            else:
                candidates = [icon, icon.removesuffix('.png').removesuffix('.svg').removesuffix('.xpm')]
                status = 'theme icon available' if any(theme.has_icon(i) for i in candidates) else 'ICON THEME NAME NOT FOUND'
        except (OSError, UnicodeError, configparser.Error, KeyError) as error:
            name, icon, status = item.stem, '', f'INVALID desktop file: {error}'
        print(f'{item.name} -> {name}\n  Icon={icon or "(empty)"}\n  {status}')
        if item.is_symlink():
            print(f'  symlink -> {os.readlink(item)}')
    print(f'\n{count} .desktop file(s) inspected; no changes made.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
