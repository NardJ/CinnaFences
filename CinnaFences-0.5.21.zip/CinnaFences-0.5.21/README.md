# CinnaFences v0.5.21 — Iconen en dynamische verticale layout

Vervolgupdate op basis van v0.5.20; de v0.5.19-functionaliteit blijft behouden. **Punt 1 (iconen) en optie 2A
(verticale verplaatsing)** zijn verder verbeterd na de screenshots van de
3D/Coding/Werk- en Admin/Other/Midi-fences. De verder voorgestelde
punten 3 en 4 zijn niet toegevoegd. Alle bestaande instellingen en
Desktop-bestanden blijven behouden.

## 1. Iconen

- Symlinks worden gevolgd bij het bepalen van het icoon, zodat bijvoorbeeld
  een snelkoppeling naar een map het mapicoon kan tonen in plaats van uitsluitend
  een symlink-embleem.
- `.desktop`-bestanden gebruiken het applicatie-icoon en de applicatienaam
  wanneer die beschikbaar zijn. Daarnaast lezen we `Name=` en `Icon=`
  rechtstreeks uit `.desktop`-bestanden, ook wanneer Gio de launcher niet
  als applicatie herkent. Ook ondersteund: bestaande absolute `Icon=`-paden,
  bestandssymlinks en extra themanamen uit launcher-/programmanaam.
- Voor alle iconen wordt een vaste weergavegrootte gebruikt, ook wanneer het
  thema een andere natuurlijke grootte voorstelt.
- Iconinformatie wordt opnieuw gelezen bij een Fence-rebuild; er is bewust
  **geen permanente cache** die na bestandwijzigingen een oud icoon toont.

**Beperking:** Als een applicatie een ongeldig icoonbestand of een niet geïnstalleerd
icoonthema heeft, kan CinnaFences dat bronicoon niet herstellen; het toont dan
waar mogelijk een standaardicoon. Uitvoer is getest via geautomatiseerde tests; echte icoonbestanden moeten op je Linux Mint-systeem
wel bestaan. Wanneer Midi nog een generiek icoon toont, gebruik dan de
meegeleverde diagnose hieronder.

## 2A. Automatische verticale herindeling

- Fences die horizontaal overlappen, vormen dynamische verticale stapels.
- Bij uitklappen schuiven lagere Fences naar beneden; bij inklappen weer omhoog.
- Voor iedere stapel geldt **exact 16 px verticale tussenruimte**, óók bij
  het inklappen en uitklappen van Rolodex-secties. De vorige versie gebruikte
  soms de handmatig opgeslagen oude afstand (bijvoorbeeld 39 px).
- De berekening start altijd vanaf de opgeslagen basiscoördinaten, niet vanaf
  de vorige tijdelijke verplaatsing. Daardoor treedt geen positioneringsdrift op.
- Verticale groepen op andere horizontale posities of monitoren beïnvloeden
  elkaar niet.
- Aan de onderrand wordt een stapel zo nodig als geheel omhoog geschoven,
  zolang er boven ruimte is. Is een stapel hoger dan het werkgebied, dan kan
  niet alles tegelijk zichtbaar zijn zonder hoogte/inhoud te veranderen.
- Handmatig verplaatsen/verslepen legt een nieuwe basispositie vast; een
  automatische herindeling schrijft geen verschuivingen naar `.cinnafence.json`.
- Dit werkt ook met **Rolodex Auto Fit Height** en na verversing van instellingen.

## Installatie / upgrade

Schakel CinnaFences eerst uit onder **Systeeminstellingen → Extensies** en sluit
het instellingenvenster. Pak de ZIP uit (bijvoorbeeld onder `~/Downloads`):

```bash
cd ~/Downloads
unzip CinnaFences-0.5.21.zip
cd CinnaFences-0.5.21
bash upgrade.sh
```

Zet daarna de extensie weer aan. `upgrade.sh` maakt eerst een back-up van de
oude extensie onder `~/.local/share/cinnafences-backups/`. Bestaande
`~/Desktop`-bestanden en `.cinnafence.json`-bestanden worden niet aangepast.

## Testen

1. Zet `3D` boven `Coding`, beide geopend. Klap `3D` in en uit en controleer
   of de tussenruimte gelijk blijft en er geen overlap ontstaat.
2. Test een Rolodex Fence met `Auto Fit Height` aan: open en sluit een sectie.
3. Kijk of mappen, symlinks naar mappen, `.desktop`-snelkoppelingen en gewone
   bestanden nu de verwachte iconen tonen.
4. Controleer dat horizontaal naast elkaar geplaatste Fences blijven staan.
5. Sleep een Fence naar een nieuwe plek en controleer in-/uitklappen en
   opnieuw aanmelden, zodat de handmatig gekozen basispositie behouden blijft.

De tests draaien zonder een Cinnamon-sessie:

```bash
bash tests/run-tests.sh
```

De nieuwe `tests/test-reflow-icons.js` controleert de vaste afstand,
inklap-/uitklaptransities, multi-monitoropstelling, herstel zonder drift en de
GIcon-aanpak voor symlinks en launchers. Echte compositor-/desktop-interactie
kan alleen op Linux Mint zelf gecontroleerd worden.

## Controle van Midi-iconen (alleen als nodig)

Wanneer na upgraden Ardour, Bitwig Studio of SunVox nog steeds het generieke
bestandicoon heeft, kan `Icon=` verwijzen naar een ontbrekende afbeelding of
ontbrekend icoonthema. Controleer de betreffende `.desktop`-bestanden zonder
iets te wijzigen:

```bash
python3 tools/diagnose-launchers.py ~/Desktop/Midi
```

Je kunt de tekstuitvoer delen om precies te zien welk icoonbestand of welke
themanaam ontbreekt. De tool voert launchers **niet** uit.

## Onderliggende v0.5.19-verbeteringen

De About-tab met on-demand CPU-/geheugen-/diskgegevens en de gerichte
performance-optimalisaties uit v0.5.19 zijn behouden. De About-tab meet het
Cinnamon-proces en de computer; zijn CPU/I/O-waarden zijn niet exclusief aan
CinnaFences toe te schrijven.
