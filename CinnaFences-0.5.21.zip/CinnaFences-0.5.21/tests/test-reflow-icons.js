// Focused v0.5.21 regression: reversible vertical reflow and reliable GIcon lookup.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'../cinnafences@local/extension.js'),'utf8');
const iconLookups=[];
class ThemedIcon {
  constructor(props){this.names=props.names || (props.name ? [props.name] : []);}
  get_names(){return this.names;}
}
const mockEntries={
  '/desk/ardour.desktop':{Name:'Ardour',Icon:'ardour',Exec:'/usr/bin/ardour8'},
  '/desk/BitwigStudio.desktop':{Name:'Bitwig Studio',Icon:'/opt/bitwig/icon.png',Exec:'/opt/bitwig/bitwig-studio'},
  '/desk/SunVox.desktop':{Name:'SunVox',Icon:'/missing/sunvox.png',Exec:'/opt/sunvox/sunvox'},
  '/desk/fallback.desktop':{Name:'Hydrogen',Exec:'/usr/bin/hydrogen'}
};
class KeyFile {
  load_from_file(p){if (!mockEntries[p]) throw Error('not keyfile'); this.data=mockEntries[p];}
  get_string(section,key){if (!this.data[key]) throw Error('missing');return this.data[key];}
  get_locale_string(section,key){return this.get_string(section,key);}
}
class FileIcon {
  constructor({file}){this.file=file;}
  get_file(){return this.file;}
}
const gio={
  ThemedIcon,FileIcon,
  FileQueryInfoFlags:{NONE:0,NOFOLLOW_SYMLINKS:1},
  File:{new_for_path:p=>({query_exists:()=>p==='/opt/bitwig/icon.png',query_info:(names,flags)=>{
    iconLookups.push({p,names,flags});
    if (p.includes('dangling')) throw Error('broken link');
    return {get_display_name:()=>p.endsWith('/folder-link')?'Models':path.basename(p),
      get_icon:()=>new ThemedIcon({name:p.endsWith('/folder-link')?'folder':'text-x-generic'})};
  }})},
  DesktopAppInfo:{new_from_filename:p=>mockEntries[p] ? null : ({get_name:()=>p==='broken.desktop'?'Broken':'Blender',get_icon:()=>new ThemedIcon({name:'org.blender.Blender'})})}
};
const ctx=vm.createContext({imports:{gi:{St:{},Clutter:{},Cinnamon:{},Gio:gio,
  GLib:{KeyFile,KeyFileFlags:{NONE:0},build_filenamev:a=>a.join('/'),path_get_basename:path.basename,get_user_config_dir:()=>'/tmp/cinnafences-reflow-test',get_home_dir:()=>'/home/test'},Pango:{},Meta:{}},byteArray:{},ui:{main:{},popupMenu:{}}},
  global:{logError:()=>{}},});
vm.runInContext(src,ctx,{filename:'extension.js'});
const run=code=>vm.runInContext(code,ctx);
const A=[{x:0,y:25,width:1920,height:1055}];
const base=[{x:50,y:80,width:350,height:200}, {x:55,y:170,width:350,height:280},
  {x:60,y:520,width:350,height:80}];
const expanded=run(`reflowFenceRects(${JSON.stringify(base)},${JSON.stringify(A)})`);
assert.deepEqual(expanded.map(r=>r.y),[80,296,592]);
const folded=[{...base[0],height:32,expandedHeight:200},base[1],base[2]];
const collapsed=run(`reflowFenceRects(${JSON.stringify(folded)},${JSON.stringify(A)})`);
assert.deepEqual(collapsed.map(r=>r.y),[80,128,424]);
const restored=run(`reflowFenceRects(${JSON.stringify(base)},${JSON.stringify(A)})`);
assert.deepEqual(restored.map(r=>r.y),expanded.map(r=>r.y));
assert.deepEqual(base.map(r=>r.y),[80,170,520],'baseline never mutated');
// Different horizontal columns never shift each other.
const columns=run(`reflowFenceRects(${JSON.stringify([
  {x:30,y:90,width:300,height:500},{x:600,y:110,width:300,height:100},
  {x:35,y:140,width:300,height:75},{x:605,y:130,width:300,height:80}
])},${JSON.stringify(A)})`);
assert.deepEqual(columns.map(r=>r.y),[90,110,606,226]);
// A historically large 39px saved gap must not recur when changing sections.
const savedGap=run(`reflowFenceRects(${JSON.stringify([
  {x:5,y:68,width:380,height:221,expandedHeight:270},
  {x:5,y:328,width:380,height:262,expandedHeight:262},
  {x:5,y:609,width:380,height:270,expandedHeight:270}
])},${JSON.stringify(A)})`);
assert.deepEqual(savedGap.map(r=>r.y),[68,305,583]);
const openedSection=run(`reflowFenceRects(${JSON.stringify([
  {x:5,y:68,width:380,height:299,expandedHeight:270},
  {x:5,y:328,width:380,height:262,expandedHeight:262},
  {x:5,y:609,width:380,height:270,expandedHeight:270}
])},${JSON.stringify(A)})`);
assert.deepEqual(openedSection.map(r=>r.y),[68,383,661]);
assert.equal(openedSection[1].y-openedSection[0].y-299,16);
assert.equal(openedSection[2].y-openedSection[1].y-262,16);
// Independent monitors: a tall fence on one screen never shifts another screen.
const dual=run(`reflowFenceRects(${JSON.stringify([
  {x:30,y:100,width:300,height:400},{x:35,y:110,width:300,height:90},
  {x:2000,y:110,width:300,height:80}
])},${JSON.stringify([A[0],{x:1920,y:25,width:1920,height:1055}])})`);
assert.deepEqual(dual.map(r=>r.y),[100,516,110]);
// When there is space above a stack, pull the entire group up so the
// bottommost fence remains reachable, preserving a 16px gap.
const edge=run(`reflowFenceRects(${JSON.stringify([
  {x:40,y:700,width:320,height:200},{x:45,y:750,width:320,height:250}
])},${JSON.stringify(A)})`);
assert.equal(edge[0].y,614);assert.equal(edge[1].y,830);
assert.equal(edge[1].y-edge[0].y-200,16);
// If the stack is physically taller than a monitor, avoid overlap instead of
// compressing the actor height (that would hide its clickable content).
const tooTall=run(`reflowFenceRects(${JSON.stringify([
  {x:50,y:25,width:330,height:800},{x:52,y:120,width:330,height:800}
])},${JSON.stringify([{x:0,y:25,width:1920,height:1000}])})`);
assert.equal(tooTall[1].y-tooTall[0].y,816);
// The manager applies ephemeral actor positions without writing geometry.
const state=run(`(() => {
  const m=Object.create(FenceManager.prototype);
  m.dead=false;m._fenceLayoutIdle=0;m.fencesVisible=true;
  const a={x:50,y:80,width:350,height:200},b={x:55,y:170,width:350,height:280};
  const mk=(geometry)=>({config:{geometry,hidden:false,collapsed:false},_drag:null,_disposed:false,
    actor:{x:geometry.x,y:geometry.y,height:geometry.height,set_position(x,y){this.x=x;this.y=y;}}});
  const f1=mk(a),f2=mk(b);m.fences=new Map([['3D',f1],['Coding',f2]]);
  m._workAreas=()=>[{x:0,y:25,width:1920,height:1055}];m.queueInputRegions=()=>{};
  m._applyMonitorLayout();const expanded=f2.actor.y===296 && b.y===170;
  f1.actor.height=32;m._applyMonitorLayout();const closed=f2.actor.y===128 && b.y===170;
  f1.actor.height=200;m._applyMonitorLayout();
  return expanded&&closed&&f2.actor.y===296;
})()`);
assert.equal(state,true,'runtime reflow updates actors but not JSON');
// Icon lookup follows symlinks and uses thematic fallback on an unknown .desktop icon.
const link=run(`resolveFenceItemIcon('/desk/folder-link','folder-link')`);
assert.equal(link.label,'Models');assert(link.gicon.get_names().includes('folder'));
assert.equal(iconLookups[0].flags,0,'FOLLOW symlink target, not NOFOLLOW_SYMLINKS');
const launcher=run(`resolveFenceItemIcon('/desk/blender.desktop','blender.desktop')`);
assert.equal(launcher.label,'Blender');
assert(launcher.gicon.get_names().includes('org.blender.Blender'));
assert(launcher.gicon.get_names().includes('application-x-executable'));
const dangling=run(`resolveFenceItemIcon('/desk/dangling','dangling')`);
assert(dangling.gicon.get_names().includes('text-x-generic'));
// GDesktopAppInfo may return null for untrusted/broken launchers even when
// the .desktop file has valid Name/Icon fields. Recover their real icon names.
const ardour=run(`resolveFenceItemIcon('/desk/ardour.desktop','ardour.desktop')`);
assert.equal(ardour.label,'Ardour');
assert(ardour.gicon.get_names().includes('ardour'));
assert(ardour.gicon.get_names().includes('ardour8'));
const bitwig=run(`resolveFenceItemIcon('/desk/BitwigStudio.desktop','BitwigStudio.desktop')`);
assert.equal(bitwig.label,'Bitwig Studio');
assert.equal(bitwig.gicon.get_file().query_exists(),true);
const sunvox=run(`resolveFenceItemIcon('/desk/SunVox.desktop','SunVox.desktop')`);
assert.equal(sunvox.label,'SunVox');
assert.equal(sunvox.gicon.get_names()[0],'SunVox'); // real icon names before generic .desktop icon
assert(sunvox.gicon.get_names().includes('sunvox'));
const hydrogen=run(`resolveFenceItemIcon('/desk/fallback.desktop','fallback.desktop')`);
assert.equal(hydrogen.label,'Hydrogen');
assert(hydrogen.gicon.get_names().includes('hydrogen'));
console.log('OK: constant 16px gap, reversible layout, MIDI desktop launchers, file icons, multi-monitors, geometry');
