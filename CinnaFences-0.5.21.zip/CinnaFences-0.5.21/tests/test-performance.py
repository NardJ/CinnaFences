#!/usr/bin/env python3
"""Synthetic /proc test for the About page, no GTK or privileged access."""
from pathlib import Path
import importlib.util
import tempfile

spec = importlib.util.spec_from_file_location('cf_perf',
    Path(__file__).resolve().parents[1] / 'cinnafences@local' / 'performance.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.parse_process_ticks('42 (Cinnamon (shell)) S ' + ' '.join(
    str(x) for x in [0]*10+[120,80]+[0]*25)) == 200
assert module.parse_cpu_times('cpu 100 0 100 100 0 0 0 0 0 0') == (300,100)
assert module.format_rate(1024)=='1.0 KiB/s'
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp)/'proc';root.mkdir()
    pid=234; process=root/str(pid);process.mkdir()
    (process/'comm').write_text('cinnamon\n')
    def stat(cpu):
        return f'{pid} (cinnamon) S ' + ' '.join(str(n) for n in [0]*10+[cpu,0]+[0]*25)
    (process/'stat').write_text(stat(100))
    (process/'status').write_text('Name: cinnamon\nVmRSS: 512000 kB\n')
    (process/'io').write_text('read_bytes: 1000\nwrite_bytes: 500\n')
    (root/'stat').write_text('cpu 100 0 100 100 0 0 0 0 0 0\n')
    (root/'meminfo').write_text('MemTotal: 8388608 kB\nMemAvailable: 4194304 kB\n')
    now=[0.0]
    sampler=module.PerformanceSampler(root,desktop=Path(temp),clock=lambda:now[0])
    first=sampler.sample()
    assert first['pid']==pid and first['cpu'] is None
    assert first['rss_mib']==500 and first['ram_used_mib']==4096
    now[0]=2.0
    (process/'stat').write_text(stat(100+sampler.hz))
    (process/'io').write_text('read_bytes: 3048\nwrite_bytes: 4596\n')
    (root/'stat').write_text('cpu 200 0 200 200 0 0 0 0 0 0\n')
    second=sampler.sample()
    assert abs(second['cpu'] - 50) < 0.1, second
    assert second['disk_read_rate']==1024 and second['disk_write_rate']==2048
    assert abs(second['system_cpu']-66.66667)<0.1, second
    assert second['disk_total_gib']>0
    (process/'comm').write_text('notcinnamon\n')
    now[0]=4
    third=sampler.sample()
    assert third['pid'] is None and third['cpu'] is None
print('OK: CPU, RSS, RAM, disk I/O, filesystem capacity and process disappearance')
