'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const code=fs.readFileSync(path.join(__dirname,'../cinnafences@local/extension.js'),'utf8');
const start=code.indexOf('function syncStageFenceHover(');
const end=code.indexOf('\nclass FenceManager',start);
assert(start>0 && end>start);
const test=vm.createContext({});
vm.runInContext(code.slice(start,end),test);
const sync=(f,x,y)=>vm.runInContext('syncStageFenceHover(f,x,y)',Object.assign(test,{f,x,y}));
const f={config:{hidden:false},actor:{visible:true},hovered:false,calls:[],
  _pointerInside:(x,y)=>x>=50&&x<200&&y>=50&&y<200,
  _setHovered(v){this.calls.push(v);this.hovered=v;}};
assert.equal(sync([f],500,500),false);
assert.deepEqual(f.calls,[],'off-Fence motion must do no work');
assert.equal(sync([f],100,100),true);
assert.deepEqual(f.calls,[true]);
assert.equal(sync([f],500,500),false);
assert.deepEqual(f.calls,[true,false],'leaving Fence clears hover once');
assert.equal(sync([f],500,500),false);
assert.deepEqual(f.calls,[true,false],'off-Fence motion must not repaint');
f.config.hidden=true;
assert.equal(sync([f],100,100),false);
assert.deepEqual(f.calls,[true,false]);
console.log('OK: pointer inside triggers overlap check, outside skips, hover cleared once');
