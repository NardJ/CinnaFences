"""Lightweight Linux /proc metrics for the on-demand CinnaFences About tab.

Nothing runs in the background: SettingsWindow samples only while About is open.
Numbers describe the WHOLE Cinnamon process, not only the CinnaFences extension.
"""
from pathlib import Path
import os
import time


def parse_process_ticks(stat):
    # The comm field is enclosed in parentheses and can contain spaces/round brackets.
    rest = stat.rsplit(') ', 1)[1].split()
    return int(rest[11]) + int(rest[12])  # /proc/<pid>/stat utime + stime


def parse_cpu_times(line):
    numbers = [int(n) for n in line.split()[1:]]
    return (sum(numbers), numbers[3] + (numbers[4] if len(numbers) > 4 else 0))


def format_rate(value):
    if value is None:
        return 'Measuring…'
    if value < 1024:
        return f'{value:.0f} B/s'
    if value < 1024 ** 2:
        return f'{value / 1024:.1f} KiB/s'
    return f'{value / 1024 ** 2:.2f} MiB/s'


class PerformanceSampler:
    def __init__(self, proc_root='/proc', desktop=None, clock=None):
        self.root = Path(proc_root)
        self.desktop = Path(desktop) if desktop else Path.home() / 'Desktop'
        self.clock = clock or time.monotonic
        self.pid = None
        self.previous = None
        self.hz = os.sysconf('SC_CLK_TCK')

    def _read(self, file):
        return Path(file).read_text(encoding='utf-8', errors='replace')

    def _find_cinnamon(self):
        uid = os.getuid()
        for entry in self.root.iterdir():
            if not entry.name.isdecimal():
                continue
            try:
                if entry.stat().st_uid == uid and self._read(entry / 'comm').strip() == 'cinnamon':
                    return int(entry.name)
            except (OSError, ValueError):
                continue
        return None

    def sample(self):
        current_time = self.clock()
        result = {'pid': None, 'cpu': None, 'rss_mib': None, 'pss_mib': None,
                  'disk_read_rate': None, 'disk_write_rate': None,
                  'system_cpu': None, 'ram_used_mib': None, 'ram_total_mib': None,
                  'disk_used_gib': None, 'disk_total_gib': None, 'disk_free_gib': None}
        ticks, io = None, {}
        try:
            pid = self.pid or self._find_cinnamon()
            if pid is not None:
                if self._read(self.root / str(pid) / 'comm').strip() != 'cinnamon':
                    pid = self._find_cinnamon()
                if pid != self.pid:
                    self.previous = None
                self.pid = pid
                if pid is not None:
                    result['pid'] = pid
                    ticks = parse_process_ticks(self._read(self.root / str(pid) / 'stat'))
                    status = self._read(self.root / str(pid) / 'status')
                    for line in status.splitlines():
                        if line.startswith('VmRSS:'):
                            result['rss_mib'] = int(line.split()[1]) / 1024
                            break
                    # PSS is deliberately optional: reading smaps_rollup costs
                    # work in Cinnamon; RSS is sufficient for the live panel.
                    io = {}
                    try:
                        for line in self._read(self.root / str(pid) / 'io').splitlines():
                            key, _, value = line.partition(':')
                            if key in ('read_bytes', 'write_bytes'):
                                io[key] = int(value.strip())
                    except (OSError, ValueError):
                        pass
            else:
                ticks, io = None, {}
        except (OSError, ValueError, IndexError):
            self.pid = None
            self.previous = None
            ticks, io = None, {}
        try:
            cpu_total, cpu_idle = parse_cpu_times(self._read(self.root / 'stat').splitlines()[0])
        except (OSError, ValueError, IndexError):
            cpu_total = cpu_idle = None
        if self.previous:
            prev = self.previous
            elapsed = current_time - prev['time']
            if elapsed > 0 and self.pid == prev['pid'] and ticks is not None and prev['ticks'] is not None:
                result['cpu'] = max(0.0, (ticks - prev['ticks']) / self.hz / elapsed * 100)
                for key, result_key in [('read_bytes','disk_read_rate'),('write_bytes','disk_write_rate')]:
                    if key in io and key in prev['io']:
                        result[result_key] = max(0.0, (io[key] - prev['io'][key]) / elapsed)
            if (cpu_total is not None and prev['cpu_total'] is not None and
                    cpu_total > prev['cpu_total']):
                delta = cpu_total - prev['cpu_total']
                result['system_cpu'] = max(0, min(100, 100 * (1 - (cpu_idle - prev['cpu_idle']) / delta)))
        self.previous = {'time':current_time,'pid':self.pid,'ticks':ticks,'io':io,
                         'cpu_total':cpu_total,'cpu_idle':cpu_idle}
        try:
            memory = {}
            for line in self._read(self.root / 'meminfo').splitlines():
                key, _, value = line.partition(':')
                if key in ('MemTotal', 'MemAvailable'):
                    memory[key] = int(value.split()[0])
            if 'MemTotal' in memory and 'MemAvailable' in memory:
                result['ram_total_mib'] = memory['MemTotal'] / 1024
                result['ram_used_mib'] = (memory['MemTotal'] - memory['MemAvailable']) / 1024
        except (OSError, ValueError, IndexError):
            pass
        try:
            info = os.statvfs(self.desktop if self.desktop.is_dir() else Path.home())
            block = info.f_frsize
            result['disk_total_gib'] = info.f_blocks * block / 1024**3
            result['disk_used_gib'] = (info.f_blocks - info.f_bfree) * block / 1024**3
            result['disk_free_gib'] = info.f_bavail * block / 1024**3
        except OSError:
            pass
        return result
